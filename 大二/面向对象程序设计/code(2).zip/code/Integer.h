#ifndef _INTEGER_HEAD_
#define _INTEGER_HEAD_

struct Integer {
  int i;
  init(int i);
  Integer* bigger(Integer* r);
};

#endif
