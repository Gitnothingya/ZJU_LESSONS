#include <iostream>
using namespace std;

class A {
  int i;
 public:
  virtual void f() {cout << "f" << endl;}
};

class B {
  int i;
  public:
  virtual void g() {cout << "g" << endl; }
  //virtual void f() {}
  //virtual void g() {}
};

int main() {
  cout << "Class A" << sizeof(A) <<endl;
  cout << "Class B" << sizeof(B) <<endl;
  B b;
  B* p = &b;
  int *pb = (int*)p;
  A a;
  int *pa = (int*)&a;
  *pa = *pb;
  A* pp = &a;
  pp->f();
  return 0;
}
