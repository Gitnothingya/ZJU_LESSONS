#include"Auxiliary.h"

const string Auxiliary::WHITESPACE = " \t\n\r";

char Auxiliary::to_lower(char c)
{
    return tolower(c);
}

string Auxiliary::LowerCase(const string& str)
{
    string lowstr = str;
    transform(lowstr.begin(),lowstr.end(),lowstr.begin(),to_lower);
    return lowstr;
}

//�ִ�
string Auxiliary::ParseWord(const string& str, int index)
{
    int wss = str.find_first_not_of(WHITESPACE, wss);
    while(index > 0)
    {
        index--;
        wss = str.find_first_of(WHITESPACE, wss);
        wss = str.find_first_not_of(WHITESPACE, wss);
    }

    int wse = str.find_first_of(WHITESPACE, wss);

    if(wss == string::npos)
    {
        wss = 0;
        wse = 0;
    }

    return str.substr(wss, wse - wss);
}

//�ж��Ƿ񲿷�ƥ��
bool Auxiliary::PartMatch(const string& partname, const string& fullname)
{
    if(partname.length() == 0)
    {
        cout << "����б����׸�ʵ��" << endl;
        return true;
    } 

    string Lpart = Auxiliary::LowerCase(partname);
    string Lfull = Auxiliary::LowerCase(fullname);
    size_t pos = Lfull.find(Lpart);
    while(pos != string::npos)
    {
        if(pos == 0 || fullname[pos - 1] == ' ')
            return true;
        pos = Lfull.find(Lpart, pos + 1);
    }
    return false;
}

int Auxiliary::NormalDis(int init_value)
{
    double mean = init_value;
    double sigma = mean/5;
    unsigned seed = time(0) + rand();
    srand(seed);
    
    std::normal_distribution<> norm{mean, sigma};
    std::default_random_engine ren{unsigned(rand())};

    return norm(ren);
}