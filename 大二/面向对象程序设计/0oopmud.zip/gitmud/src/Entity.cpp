#include "Entity.h"


Entity::Entity(const string& name, const entityid& id, const string& description)
    :name(name), id(id), description(description)
    {}

Entity::Entity()
{}

Entity::~Entity()
{
}

entityid& Entity::ID()
{
    return id;
}

string& Entity::Name()
{
    return name;
}

string Entity::GetDescription() const
{
    return description;
}

string Entity::LowerName() const
{
    return Auxiliary::LowerCase(name);
}

//full match, ignore upper/lower case
bool Entity::FullMatch(const string& str) const
{
    return LowerName() == Auxiliary::LowerCase(str);
}

//part match
bool Entity::Match(const string& str) const
{
    if(str.size() == 0) return true; //???��?????????????????
    string Lname = LowerName();
    string target = Auxiliary::LowerCase(str);
    size_t pos = Lname.find(target);
    while(pos != string::npos)
    {
        if(pos == 0 || name[pos - 1] == ' ')
            return true;
        pos = Lname.find(target, pos + 1);
    }
    return false;
}







