#include"Neutral.h"

Neutral::Neutral(const string& name, const entityid& id, const string& description, int& exp, list<pair<entityid, int>>& dropitems, list<entityid>& tokens)
    : Npc(name, id, description, exp, dropitems), tokens(tokens)
    {}

Neutral::Neutral(){}

Neutral::~Neutral(){}

list<entityid>& Neutral::GetToken()
{
    return tokens;
}