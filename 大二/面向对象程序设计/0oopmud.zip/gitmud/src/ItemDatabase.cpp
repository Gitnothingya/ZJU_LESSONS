#include"ItemDatabase.h"
using namespace std;

ItemDatabase::~ItemDatabase()
{
    for(auto elem: entity)
    {
        delete elem.second;
    }
}

bool ItemDatabase::Load(const char* filename)
{
    ifstream file_in(filename);
    if(!file_in.good()) return false;

    string temp;

    entityid id;
    int type;
    string name;
    string description;
    money price;
    AttributeSet bonus;    //bonus

    while(file_in.good())
    {
        file_in >> temp >> id;
        file_in >> temp >> type;
        file_in >> temp;
        //get name, ȥ��ǰ���ո�
        getline(file_in, name);
        name.erase(0, name.find_first_not_of(" "));

        file_in >> temp;
        getline(file_in, description);
        description.erase(0, description.find_first_not_of(" "));

        file_in >> temp >> price;
        file_in >> bonus;

        Item* item = new Item(name, id, description, ItemType(type), price, bonus);
        entity[id] = item;
        name_id[name] = id;

    }
    
    file_in.close();
    return true;
}

bool ItemDatabase::Store(const char* filename)
{
    ofstream file_out(filename);
    if(!file_out.good()) return false;

    for(auto elem : entity)
    {
        file_out << "[ID] " << elem.second->ID() << "\n"
                 << "[TYPE] " << elem.second->Type() << "\n"
                 << "[NAME] " << elem.second->Name() << "\n"
                 << "[DESCRIPTION] " << elem.second->GetDescription() << "\n"
                 << "[PRICE]" << elem.second->Price() << "\n";
        
        file_out << elem.second->GetAttrSet();    
    }

    
    file_out.close();
    return true;
}

