#include"EnemyDatabase.h"
using namespace std;

EnemyDatabase::~EnemyDatabase()
{
    for(auto elem: entity)
    {
        delete elem.second;
    }
}

bool EnemyDatabase::Load(const char* filename)
{
    ifstream file_in(filename);
    if(!file_in.good()) return false;

    string temp;
    entityid id;
    string name;
    int HP;             //����ֵ
    int accurary;       //��ȷ��
    int dodging;        //�����
    int damage;         //�˺�
    int defense;        //����ֵ
    int exp;            //��ɱ���ȡ�ľ���ֵ
    string description;
    int booty_num;
    entityid dropid;
    int probability;

    while(file_in.good())
    {
        //��ʱ����
        list<pair<entityid, int>> dropitems; //������Ʒ��int��ʾ�������

        file_in >> temp >> id;

        file_in >> temp;
        //get name, ȥ��ǰ���ո�
        getline(file_in, name);
        name.erase(0, name.find_first_not_of(" "));    
         
        file_in >> temp >> HP
                >> temp >> accurary
                >> temp >> dodging
                >> temp >> damage
                >> temp >> defense
                >> temp >> exp;

        file_in >> temp;
        getline(file_in, description);
        description.erase(0, description.find_first_not_of(" "));

        file_in >> temp >> booty_num;
        
        for(int i = 0; i < booty_num; i++)
        {
            file_in >> temp >> dropid >> probability;
            dropitems.push_back(make_pair(dropid, probability));

        }

        Enemy* enemy = new Enemy(name, id, HP, accurary, dodging, damage, defense, exp, description, dropitems);
        entity[id] = enemy;
        name_id[name] = id;

    }

    file_in.close();
    return true;
}

bool EnemyDatabase::Store(const char* filename)
{
    ofstream file_out(filename);
    if(!file_out.good()) return false;

    for(auto elem : entity)
    {
        file_out << "[ID] " << elem.second->ID() << "\n"
                 << "[NAME] " << elem.second->Name() << "\n"
                 << "[HP] "  << elem.second->GetHP() << "\n"
                 << "[ACCURACY] " << elem.second->GetAccur() << "\n"
                 << "[DODGING] " << elem.second->GetDodging() << "\n"
                 << "[DAMAGE] " << elem.second->GetDamage() << "\n"
                 << "[DEFENSE] " << elem.second->GetDefense() << "\n"
                 << "[EXP] " << elem.second->GetExp() << "\n"
                 << "[DESCRIPTION] " << elem.second->GetDescription() << "\n"
                 << "[BOOTY_NUM] " << elem.second->GetBooty().size() << "\n";

        
        auto dropitems = elem.second->GetBooty();
        for(auto item : dropitems)
        {
            file_out << "[DROPITEM] " << item.first << " " << item.second << "\n";
        }
                 
    }
    
    file_out.close();
    return true;
}