#include"Item.h"

Item::Item(string name, entityid id, string description, ItemType type, money price, AttributeSet bonus)
    :Entity(name, id, description), type(type), Proficiency(0), Durability(100), price(price), bonus(bonus)
    {}

Item::Item()
{

}

Item::~Item()
{

}

ItemType& Item::Type()
{
    return type;
}

money& Item::Price()
{
    return price;
}

int& Item::GetAttr(int attr)
{
    return bonus[attr];
}

AttributeSet& Item::GetAttrSet()
{
    return bonus;
}

void Item::ShowInf()
{
    cout << "[ID]   " << id << endl;
    cout << "[TYPE] ";
    switch (type)
    {
    case WEAPON:
        cout << "WEAPON";
        break;
    case HAT:
        cout << "HAT";
        break;
    case CLOTH:
        cout << "CLOTH";
        break;
    case TROUSER:
        cout << "TROUSER";
        break;
    case SHOE:
        cout << "SHOE";
        break;
    case POTION:
        cout << "POTION";
        break;
    default:
        break;
    }

    cout << endl;
    cout << "[NAME] " << name << endl
         << "[DESCRIPTION]" << description << endl
         << "[PRICE]   " << price << endl
         << GetAttrSet();
}






