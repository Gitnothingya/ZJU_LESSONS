#include"Scene.h"
using namespace std;
Scene::Scene(entityid id, SceneType type, string name, string description, map<string, entityid>& adjscenes, map<entityid, string>& itemsid, map<entityid, string>& enemysid, map<entityid, string>& neutralid, money m_money)
    :Entity(name, id, description), type(type), adjscenes(adjscenes), m_money(m_money), itemsid(itemsid), enemysid(enemysid), neutralid(neutralid)
{}

Scene::Scene()
{
    
}

Scene::~Scene()
{

}

/**
 * @brief �жϵ�ǰ�����Ƿ���ڴ���Ʒ
 * @param id
 * @return true means found
 */
bool Scene::FindItem(const entityid id)
{
    for(auto& elem : itemsid)
    {
        if(elem.first == id) return true;
    }
    return false;
}

void Scene::AddItem(const entityid id, const string name)
{
    itemsid[id] = name;
}

void Scene::RemoveItem(const entityid id)
{
    itemsid.erase(id);
}

bool Scene::FindEnemy(const entityid id)
{
    for(auto& elem : enemysid)
    {
        if(elem.first == id) return true;
    }
    return false;
}

void Scene::AddEnemy(const entityid id, const string name)
{
    enemysid[id] = name;
}

void Scene::RemoveEnemy(const entityid id)
{
    itemsid.erase(id);
}

SceneType Scene::GetType()
{
    return type;
}

money& Scene::GetMoney()
{
    return m_money;
}

entityid Scene::GetScene(const string& dire)
{
    if(adjscenes.count(dire))
    {
        return adjscenes[dire];
    }
    return INVALID_ID;
}

map<entityid, string>& Scene::GetAllItems()
{
    return itemsid;
}

map<entityid, string>& Scene::GetEnemies()
{
    return enemysid;
}

map<entityid, string>& Scene::GetNeutrals()
{
    return neutralid;
}

map<string, entityid>& Scene::GetAdjs()
{
    return adjscenes;
}
