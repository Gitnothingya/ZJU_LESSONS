#include"SceneDatabase.h"
using namespace std;

SceneDatabase::~SceneDatabase()
{
    for(auto elem: entity)
    {
        delete elem.second;
    }
}

bool SceneDatabase::Load(const char* filename)
{
    ifstream file_in(filename);
    if(!file_in.good()) return false;

    string temp;
    int num;
    string dire_;
    entityid adj_id_;
    entityid item_id_;
    entityid enemy_id_;
    entityid neutral_id_;

    entityid sceneid;  
    int type; 
    string name;
    string description; //�����ı�������
    money m_money;
    string item_name_;
    string enemy_name_;
    string neutral_name;

    while(file_in.good())
    {
        //fix, ��ʱ����, ÿ�����ڼ����³���ʱ���ǿ�����
        map<string, entityid> adjscenes;  //�ڽӳ���������+�÷���ĳ���ID��ֻ��4������
        map<entityid, string> itemsid; //��ǰ�����е���Ʒ
        map<entityid, string> enemysid; //��ǰ�����еĵ���
        map<entityid, string> neutralsid;

        file_in >> temp >> sceneid
                >> temp >> type;
        file_in >> temp;
        getline(file_in, name);
        name.erase(0, name.find_first_not_of(" "));
        file_in >> temp;
        getline(file_in, description);
        description.erase(0, description.find_first_not_of(" "));

        file_in >> temp >> num;

        for(int j = 0; j < num; j++)
        {
            file_in >> temp >> dire_ >> adj_id_;
            adjscenes[dire_] = adj_id_;
        }

        file_in >> temp >> num;
        for(int j = 0; j < num; j++)
        {
            file_in >> temp >> item_id_;
            file_in >> temp;
            getline(file_in, item_name_);
            item_name_.erase(0, item_name_.find_first_not_of(" "));

            itemsid[item_id_] = item_name_;
        }

        file_in >> temp >> num;
        for(int j = 0; j < num; j++)
        {
            file_in >> temp >> enemy_id_;

            file_in >> temp;
            getline(file_in, enemy_name_);
            enemy_name_.erase(0, enemy_name_.find_first_not_of(" "));

            enemysid[enemy_id_] = enemy_name_;
        }

        file_in >> temp >> num;
        for(int j = 0; j < num; j++)
        {
            file_in >> temp >> neutral_id_;
            file_in >> temp;

            getline(file_in, neutral_name);
            neutral_name.erase(0, neutral_name.find_first_not_of(" "));

            neutralsid[neutral_id_] = neutral_name;
        }

        file_in >> temp >> m_money;

        Scene* scene = new Scene(sceneid, (SceneType)type, name, description, adjscenes, itemsid, enemysid, neutralsid, m_money);
        entity[sceneid] = scene;
        name_id[name] = sceneid;

    }

    file_in.close();
    return true;
}

bool SceneDatabase::Store(const char* filename)
{
    ofstream file_out(filename);
    if(!file_out.good()) return false;

    for(auto elem : entity)
    {
        file_out << "[ID] " << elem.second->ID() << "\n"
                 << "[TYPE] " << elem.second->GetType() << "\n"
                 << "[NAME] " << elem.second->Name() << "\n"
                 << "[DESCRIPTION] " << elem.second->GetDescription() << "\n";

        auto adjs = elem.second->GetAdjs();
        file_out << "[ADJNUM] " << adjs.size() << "\n";

        for(auto adj : adjs)
        {
            file_out << "[ADJSCENE] " << adj.first << " " << adj.second << "\n";
        }

        auto items = elem.second->GetAllItems();
        file_out << "[ITEMNUM] " << items.size() << "\n";

        for(auto item : items)
        {
            file_out << "[ITEM] " << item.first << "\n"
                     << "[ITEMNAME] " << item.second << "\n";
        }

        auto enemys = elem.second->GetEnemies();
        file_out << "[ENEMYNUM] " << enemys.size() << "\n";

        for(auto enemy : enemys)
        {
            file_out << "[ENEMY] " << enemy.first << "\n"
                     << "[ENEMYNAME] " << enemy.second << "\n";
        }

        auto neutrals = elem.second->GetNeutrals();
        file_out << "[NEUTRALNUM] " << neutrals.size() << "\n";

        for(auto neutral : neutrals)
        {
            file_out << "[NEUTRAL] " << neutral.first << "\n"
                     << "[NEUTRALNAME] " << neutral.second << "\n";
        }

        file_out << "[MONEY] " << elem.second->GetMoney() << "\n";
    }

    file_out.close();
    return true;
}