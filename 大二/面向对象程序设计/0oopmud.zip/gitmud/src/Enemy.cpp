#include"Enemy.h"

Enemy::Enemy(string name, entityid id, int HP, int accuracy, int dodging, int damage, int defense, int exp, string description, list<pair<entityid, int>> dropitems)
    :Npc(name, id, description, exp, dropitems), HP(HP), accurary(accuracy), dodging(dodging), damage(damage), defense(defense)
{}

Enemy::Enemy()
{}

Enemy::~Enemy()
{}



void Enemy::ShowInf()
{
    cout << "[ID]   " << id << endl
         << "[NAME] " << name << endl
         << "[HP]   " << HP << endl
         << "[ACCURACY] " << accurary << endl
         << "[DODGING]  " << dodging << endl
         << "[DAMAGE]   " << damage << endl
         << "[DEFENSE]  " << defense << endl
         << "[EXP]  " << exp << endl
         << "[DESCROPTION]  " << description << endl;
}

int& Enemy::GetHP()
{
    return HP;
}

int Enemy::GetAccur()
{
    return accurary;
}

int Enemy::GetDamage()
{
    return damage;
}

int Enemy::GetDefense()
{
    return defense;
}

int Enemy::GetDodging()
{
    return dodging;
}


