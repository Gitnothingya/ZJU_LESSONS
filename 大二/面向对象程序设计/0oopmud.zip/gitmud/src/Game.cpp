#include "Game.h"
#include <iomanip>

Game::Game():m_player("name",0, "������ʿ", "000",&itemDB,&sceDB,&enemyDB)
{

}

Game::~Game()
{
    //����ʱ���棬���л�
    string choose;
    cout << "[prompt] do you want to save? [enter yes or not]" << endl;
    while(cin >> choose)
    {
        if(choose == "yes")
		{
            if(itemDB.Store(ITEM_SAVE)) cout << "[prompt] items save success" << endl;
            if(sceDB.Store(SCENE_SAVE)) cout << "[prompt] scenes save success" << endl;
            if(enemyDB.Store(ENEMY_SAVE)) cout << "[prompt] enemys save success" << endl;
            if(neutralDB.Store(NEUTRAL_SAVE)) cout << "[prompt] neutral save success" << endl;
			
			cout << "[prompt] save success!" << endl;
			break;
		}
		else if(choose == "no") break;
		else 
		{
			cout << "[prompt] error, please enter yes or no" << endl;
		}
    }
    
    cout << "[prompt] quit sucess!!!" << endl;
}

bool Game::Init(const char* itemfile, const char* scenefile, const char* enemyfile, const char* neutralfile)
{
    commandFun["show"] = SHOW;
    commandFun["move"] = MOVE;
    commandFun["look"] = LOOK;
    commandFun["quit"] = QUIT;
    commandFun["buy"] = BUY;
    commandFun["pickmoney"] = PICKMONEY;
    commandFun["pick"] = PICKITEM;
    commandFun["run"] = RUNAWAY;
    commandFun["attack"] = ATTACK;
    commandFun["check"] = CHECK;
    commandFun["detect"] = DETECT;
    commandFun["use"] = USE;
    commandFun["remove"] = REMOVE;
    commandFun["drop"] = DROP;
    commandFun["give"] = GIVE;

    if(itemDB.Load(itemfile)) cout << "[prompt] items load success" << endl;
    if(sceDB.Load(scenefile)) cout << "[prompt] scenes load success" << endl;
    if(enemyDB.Load(enemyfile)) cout << "[prompt] enemys load success" << endl;
    if(neutralDB.Load(neutralfile)) cout << "[prompt] neutral load success" << endl;

    cur_scene_id = 1;
    cur_scene = sceDB[cur_scene_id];

    Plot();

    return true;
}


/**
 * @brief ��ʾ����
 */
void Game::Plot()
{
    cout << "���־�����������ŵɭ�£��������˵���ʿ������������սʤ������������" << endl;
    //����
}

/**
 * @brief ����������������
 * 
 * @param command
 */
GameState Game::Handle(string command)
{
    Player& p = m_player;

    command = Auxiliary::LowerCase(command); //�����������������Ӵ�Сд
    
    if(command == ".")
    {
        command = lastcommand;
    }
    else
    {
        lastcommand = command;
    }
    string tmp = Auxiliary::ParseWord(command,0); 
    int com = -1 ; 
    if(commandFun.find(tmp) != commandFun.end()){
        com = commandFun.find(tmp)->second;
    }
    //info->push_back(command);
    //info->push_back(to_string(com));
    //info->push_back(to_string(commandFun.size()));
    
    switch(com){
        case SHOW:{
            string content = Auxiliary::ParseWord(command,1);
            Show(content);
            break;
            }
        case LOOK: Look(cur_scene_id); break;
        case MOVE:{ 
            cout << "move now!" << endl;
            string position = Auxiliary::ParseWord(command,1);
            Move(position);
            break;
            }
        case BUY:{
            if(cur_scene->GetType() != Store)
            {
                cout << "����ǰ�����̵��У��޷�������Ʒ" << endl;
                break;
            }
            string good_name = Auxiliary::ParseWord(command,1);
            bool isbuy = Buy(good_name);
            if(isbuy) cout << "����ɹ�, ����ʣ " << m_player.Money() << "Ǯ" << endl;
            break;
        } 
        case PICKMONEY: PickMoney(); break;
        case PICKITEM:{
            if(cur_scene->GetType() == Store){
                cout << "�㲻�����̵궫�������ǲ����µģ�����"<<endl;
            }
            string thing_name = Auxiliary::ParseWord(command, 1);
            Pick(thing_name);
            break;
        } 
        case DETECT:{
            string target = Auxiliary::ParseWord(command, 1);
            DetectEnemy(target);
            break;
        } 
        case CHECK:{
            string target = Auxiliary::ParseWord(command, 1);
            CheckItem(target);
            break;
        }
        case ATTACK:{
            cout << "attck now!" << endl;
            string target = Auxiliary::ParseWord(command, 1);
            CombatRes res = CombatCycle(target);
            switch (res)
            {
            case CWIN:{
                cout << "==========================================ս��ʤ��==========================================" << endl;
                //�ѵ���ɾ��
                entityid id = INVALID_ID;
                for(auto elem : enemyDB.name_id){
                    if(Auxiliary::PartMatch(target, elem.first)){
                        id = elem.second;
                    }
                }
                list<pair<entityid, int>> thrown = enemyDB[id]->GetBooty();
                for(auto elem : thrown){
                    string name = enemyDB[elem.first]->Name();
                    cur_scene->AddItem(elem.first, name);
                }
                delete enemyDB[id];
                cur_scene->RemoveEnemy(id);
                break;
                }
            case CLOST:
                cout << "==========================================ս��ʧ��==========================================" << endl;
                cout << "������˹��½Ʈ���˴�ѩ, ��ʿ�ĺ��Ǿʹ˳����޾�֮��....." << endl;
                return SQUIT;
                break;
            case CRUN:
                cout << "����ս��!" << endl;
                break;
            case CERROR:
                cout << "�����ڴ˵���" << endl;
                break;
            }
            break;
        }
        case USE: {
            string item_name = Auxiliary::ParseWord(command, 1);
            Use(item_name);
            break;
        }
        case REMOVE: {
            string item_name = Auxiliary::ParseWord(command, 1);
            Remove(item_name);
            break;
        }
        case DROP: {
            string item_name = Auxiliary::ParseWord(command, 1);
            Drop(item_name);
            break;
        }
        case GIVE: {
            
        }
        case QUIT: return SQUIT;
        default:cout<<"�������\n"; break;
    }

    return SRUN;
}

/**
 * @brief 
 * 
 * @param command 
 */
void Game::Look(entityid id)//��ʾ������Ϣ
{
    cout << sceDB.entity.size() << endl;
    cout << "---------" << sceDB[id]->Name() << "---------" << endl;
    cout << cur_scene->GetDescription() <<endl;
    cout << "�����ǰ���ķ���" << "up: " << cur_scene->GetScene("up") << " ,"
                                << "down: " << cur_scene->GetScene("down") << " ,"
                                << "left: " << cur_scene->GetScene("left") << " ,"
                                << "right: " << cur_scene->GetScene("right") << endl;

    //չʾ��Ʒ
    cout << "�ɼ���Ʒ��";
    map<entityid, string>::iterator scene_itr=cur_scene->GetAllItems().begin();
    cout<<cur_scene->GetAllItems().size()<<endl;
    for(;scene_itr!=cur_scene->GetAllItems().end();scene_itr++){
        cout<<itemDB[scene_itr->first]->Name()<<"("<<itemDB[scene_itr->first]->ID()<<") ,";
    }
    cout<<endl;

    //չʾ����
    cout<<"��Ҫ����ĵ��ˣ�"<<endl;
    auto enemys = cur_scene->GetEnemies();
    for(auto elem: enemys)
    {
        ASSERT(enemyDB.entity.count(elem.first), "����δ���صĵ���!");
        cout << enemyDB[elem.first]->Name() << "(" << enemyDB[elem.first]->ID() << ") ,";
    } 
    cout << endl;

    //չʾ����NPC
    cout<<"����NPC��"<<endl;
    auto neutrals = cur_scene->GetNeutrals();
    for(auto elem: neutrals)
    {
        ASSERT(neutralDB.entity.count(elem.first), "����δ���ص�NPC!");
        cout << neutralDB[elem.first]->Name() << "(" << neutralDB[elem.first]->ID() << ") ,";
    } 
    cout << endl;

    cout<<"����Ի�ȡ�Ľ�Ǯ����"<<cur_scene->GetMoney()<<endl;
    cout<<"-------------------------------"<<endl;
}


/**
 * @brief 
 * 
 * @param command 
 */
void Game::Move(string position)//�����ƶ�
{
    //Scene &old = *sceDB[cur_scene_id];
    entityid newid;
    newid = cur_scene->GetScene(position); //old.GetScene(position);

    cout << "newid: " << newid << endl;

    if(newid != INVALID_ID){
        cur_scene_id = newid;
        cur_scene = sceDB[newid];
        Look(newid);
        return;
    } 
    else
    {
        cout << "error!!!" << endl;
    }
}

void Game::Show(string content)
{
    Player& p = m_player;
    if(content == "state"){
        string level = to_string(p.GetLevel())+"("+to_string(p.GetExp())+"/100)";
        cout<<"| ���� |  "<<p.GetName()<<"   | "<<"�ȼ� | "<<level<<" | ��Ǯ |  "<<p.GetMoney()<<" |"<<endl;
        cout<<"| ���� |   "<<setw(2)<<to_string(p.GetHealth())<<"    |"<<" ���� |    "<<p.GetStrenth()<<"    | ���� |  "<<p.GetAgility()<<"  |"<<endl;
        cout<<"|����ֵ| "<<m_player.HitPoints()<<"/"<<m_player.GetRealAttr(MaxHP)<< " | �ָ� |    "<<m_player.GetRealAttr(REGEN)<<"    |"<<endl;
        cout<<"| �˺� |   " << m_player.GetRealAttr(DAMAGE) << "    | ���� |    "<<m_player.GetRealAttr(DEFENSE)<<"    |"<<endl;
        cout<<"| ���� |   " << m_player.GetRealAttr(ACCURACY) << "    | ���� |    "<<m_player.GetRealAttr(DODGING)<<"    |"<<endl;
        
    } else if(content == "bag"){
        cout<<"��������"<<endl;
        for(auto one : m_player.MyBag()){
            string name = itemDB[one]->Name();
            cout<<"    "<< name << endl;
        }
    } else if(content == "equip"){

    }
}
bool Game::Pick(string p_items)
{
    for(auto elem : cur_scene->GetAllItems()){
        if(Auxiliary::PartMatch(p_items, elem.second)){
            if(Pick( elem.second )){
                cout << "��ɹ������Ʒ "<< p_items<<endl;
                return true;
            }
        }
    }
    cout << "��ǰ���������ڸ���Ʒ����"<<endl;
    return false;
}
bool Game::Pick(const entityid thing_id)
{
    Item* thing = itemDB[thing_id];

    cur_scene->RemoveItem(thing_id);
    m_player.PickUpItem(thing_id);
    return true;

}

bool Game::Use(string p_item)
{
    //�������ݿ�
    entityid id = 0;
    for(auto elem : itemDB.name_id){
        if(Auxiliary::PartMatch(p_item, elem.first)){
            id = elem.second;
        }
    }
    if(id==0){
        cout << "ѹ���������ⶫ��?????"<<endl;
        return false;
    }

    vector<entityid> bag = m_player.MyBag();
    bool flag = false;
    for(auto have : bag){
        if(have == id){
            flag = true;
        }
    }

    if(flag == false){
        cout<<" ������ʲô??�����û���������!!!"<<endl;
        return flag;
    }
    
    Item* thing = itemDB[id];
    ItemType type = thing->Type();
    switch (type)
    {
    case WEAPON:{
        m_player.UseWaeapon(id);
        break;
        }
    case HAT:{
        m_player.UseHat(id);
        break;
        }
    case CLOTH:{
        m_player.UseCloth(id);
        break;
        }
    case TROUSER:{
        m_player.UseTrouser(id);
        break;
        }
    case SHOE:{
        m_player.UseShoe(id);
        break;
        }
    case POTION:{
        m_player.UsePotion(id);
        break;
        }
    default:
        break;
    }
    return flag;
}

bool Game::Remove(string p_item)
{
    //�������ݿ�
    entityid id = 0;
    for(auto elem : itemDB.name_id){
        if(Auxiliary::PartMatch(p_item, elem.first)){
            id = elem.second;
        }
    }
    if(id==0){
        cout << "ѹ���������ⶫ��?????"<<endl;
        return false;
    }

    vector<entityid> bag = m_player.MyBag();
    bool flag = false;
    for(auto have : bag){
        if(have == id){
            flag = true;
        }
    }

    if(flag == false){
        cout<<" ������ʲô??�����û���������!!!"<<endl;
        return flag;
    }
    
    Item* thing = itemDB[id];
    ItemType type = thing->Type();
    switch (type)
    {
    case WEAPON:{
        if(id == m_player.Weapon())
            m_player.RemoveWeapon();
        else {
            cout << "��û��װ���������Ŷ������ "<<endl;
        }
        break;
        }
    case HAT:{
        if(id == m_player.MyHat())
            m_player.RemoveHat();
        else {
            cout << "��û��װ�����ñ��Ŷ������ "<<endl;
        }
        break;
        }
    case CLOTH:{
        if(id == m_player.MyCloth())
            m_player.RemoveCloth();
        else {
            cout << "��û��װ������·�Ŷ������ "<<endl;
        }
        break;
        }
    case TROUSER:{
        if(id == m_player.MyTrouser())
            m_player.RemoveTrouser();
        else {
            cout << "��û��װ���������Ŷ������ "<<endl;
        }
        break;
        }
    case SHOE:{
        if(id == m_player.MyShoe())
            m_player.RemoveShoe();
        else {
            cout << "��û��װ�����Ь��Ŷ������ "<<endl;
        }
        break;
        }
    default:
        cout << "��ȷ������װ��������"<<endl;
        break;
    }
    return flag;
}
bool Game::Drop(string p_item)    //������Ʒ
{   
    entityid id = 0;
    for(auto elem : itemDB.name_id){
        if(Auxiliary::PartMatch(p_item, elem.first)){
            id = elem.second;
        }
    }
    if(id==0){
        cout << "ѹ���������ⶫ��?????"<<endl;
        return false;
    }

    vector<entityid> bag = m_player.MyBag();
    bool flag = false;
    for(auto have : bag){
        if(have == id){
            flag = true;
        }
    }

    if(flag == false){
        cout<<" ������ʲô??�����û���������!!!"<<endl;
        return flag;
    }
    m_player.DropItem(id);

    return flag;
}
bool Game::Give()
{

    return false;
}


bool Game::Buy(const string& goodname)
{
    for(auto elem: cur_scene->GetAllItems())
    {
        if(Auxiliary::PartMatch(goodname, elem.second))
        {
            return Buy(elem.first);
        }
    }

    cout << "��Ʒ������!" << endl;
    return false;    
}

/**
 * @brief �����̵��е���Ʒ����ǰ�Ƿ����̵���Game�жϣ��˺���ֻ���ع���Ľ��(�Ƿ�ɹ�)
 * @param item 
 * @return true ����ɹ�
 * @return false ����ʧ��
 */
bool Game::Buy(entityid goodid)
{
    cout << goodid << endl;
    Item* good = itemDB[goodid];

    cout << m_player.Money() << endl;
    if(good->Price() > m_player.Money())
    {
        cout << "��Ǯ����!" << endl; 
        return false;
    }
    else
    {
        cout << m_player.Money() << " " << good->Price() << endl;
        m_player.Money() -= good->Price();
        cur_scene->RemoveItem(goodid);
        m_player.PickUpItem(goodid); //��ûд
        return true;
    }
    return true;
}

void Game::PickMoney()
{
    m_player.Money() += cur_scene->GetMoney();
    cur_scene->GetMoney() = 0;
    cout << "�ɹ�ʰ����ϵ�Ǯ������ǰӵ�� " << m_player.Money() << "���" << endl;
}

void Game::DetectEnemy(const string& enemy)
{
    entityid enemy_id = INVALID_ID;
    for(auto elem: enemyDB.name_id)
    {
        //����ƥ�伴��
        if(Auxiliary::PartMatch(enemy, elem.first))
        {
            enemy_id = elem.second;
        }
    }

    DetectEnemy(enemy_id);

    return;
}

void Game::DetectEnemy(const entityid enemy_id)
{
    if(enemy_id == INVALID_ID) 
    {
        cout << "���ҵĶ��󲻴���" << endl;
        return;
    }
    else if(cur_scene->FindEnemy(enemy_id))
    {
        enemyDB[enemy_id]->ShowInf();
    }
    else
    {
        cout << "��ǰ���������ڴ˶���" << endl;
    }
    return;
}

void Game::CheckItem(const string& item)
{
    entityid item_id = INVALID_ID;
    for(auto elem: itemDB.name_id)
    {
        //����ƥ�伴��
        if(Auxiliary::PartMatch(item, elem.first))
        {
            item_id = elem.second;
        }
    }

    CheckItem(item_id);

    return;
}

void Game::CheckItem(const entityid item_id)
{
    if(item_id == INVALID_ID) 
    {
        cout << "���ҵĶ��󲻴���" << endl;
        return;
    }
    else if(cur_scene->FindItem(item_id))
    {
        itemDB[item_id]->ShowInf();
    }
    else
    {
        cout << "��ǰ���������ڴ˶���" << endl;
    }
    return;
}

CombatRes Game::CombatCycle(const string& enemy)
{
    string command;
    int round = 1;

    entityid enemy_id = INVALID_ID;
    for(auto elem: enemyDB.name_id)
    {
        //����ƥ�伴��
        if(Auxiliary::PartMatch(enemy, elem.first))
        {
            enemy_id = elem.second;
        }
    }

    if(enemy_id == INVALID_ID)
    {
        return CERROR;
    }
    else if(cur_scene->FindEnemy(enemy_id))
    {
        auto t_enemy = enemyDB[enemy_id];
        cout << "==========================================����ս��==========================================" << endl;

        while(1)
        {
            cout << "--------------------------��ǰ�غ�: Round " << round << "--------------------------" << endl;
            getline(cin, command);
            command = Auxiliary::LowerCase(command);
            string tmp = Auxiliary::ParseWord(command,0); 
            int com = -1 ; 
            if(commandFun.find(tmp) != commandFun.end()){
                com = commandFun.find(tmp)->second;
            }

            switch(com){
            case ATTACK:
                cout << "����˺� " << m_player.GetRealAttr(DAMAGE) << endl;
                t_enemy->GetHP() -= Auxiliary::NormalDis(m_player.GetRealAttr(DAMAGE));
                if(t_enemy->GetHP() <= 0) return CWIN;
                cout << "��������ֵ" << t_enemy->GetHP() << endl;
                break;
            case RUNAWAY:
                cout << "==========================================����ս��==========================================" << endl;
                return CRUN;
                break;
            default:cout<<"�������\n"; break;
            }

            //������
            m_player.HitPoints() -= Auxiliary::NormalDis(t_enemy->GetDamage());
            if(m_player.HitPoints() <= 0) return CLOST;
            cout << "��ǰ����ֵ " << m_player.HitPoints() << endl;

            round++;
        }
    }
    else
    {
        return CERROR;
    }
}