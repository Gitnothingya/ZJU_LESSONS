#include"Attributes.h"

vector<string> AttributeSet::attrname={};

AttributeSet::AttributeSet()
{
    initattrname();
    attributes[REGEN] = 0;
    attributes[ACCURACY] = 0;
    attributes[DODGING] = 0;
    attributes[DAMAGE] = 0;
    attributes[DEFENSE] = 0;
    attributes[MaxHP] = 0;

}

void AttributeSet::initattrname()
{
    attrname.push_back("MaxHP");
    attrname.push_back("REGEN");
    attrname.push_back("ACCURACY");
    attrname.push_back("DODGING");
    attrname.push_back("DAMAGE");
    attrname.push_back("DEFENSE");
}

int& AttributeSet::operator[](int attr)
{
    return attributes[attr];
}

ostream& operator<<(ostream& stream, const AttributeSet& a)
{
    for(int i = 0; i < ATTRNUM; i++)
    {
        stream << "[" << a.attrname[i] << "] " << a.attributes[i] << endl;
    }
    return stream;
}

ifstream& operator>>(ifstream& stream, AttributeSet& a)
{
    string temp;
    for(int i = 0; i < ATTRNUM; i++)
    {
        stream >> temp >> a.attributes[i];
    }
    return stream;
}