#include"Npc.h"

Npc::Npc(const string& name, const entityid& id, const string& description, int& exp, list<pair<entityid, int>>& dropitems)
    : Entity(name, id, description), exp(exp), dropitems(dropitems)
    {}

Npc::Npc()
{}

int Npc::GetExp()
{
    return exp;
}

list<pair<entityid, int>>& Npc::GetBooty()
{
    //��ûд��Ӧ���ݸ��ʷ���
    return dropitems;
}