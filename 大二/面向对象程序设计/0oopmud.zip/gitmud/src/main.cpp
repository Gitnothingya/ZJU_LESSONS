#include "Game.h"
#include<iostream>

using namespace std;

int main()
{
	Game GameRun;
	GameState state;
	string command;
	string mode;
	cout << "[prompt] restart or load?" << endl;
	while(cin >> mode)
	{
		if(mode == "restart")
		{
			GameRun.Init(ITEM_FILE, SCENE_FILE, ENEMY_FILE, NEUTRAL_FILE);
			cout << "[prompt] restart success!" << endl;
			break;
		}
		else if(mode == "load")
		{
			GameRun.Init(ITEM_SAVE, SCENE_SAVE, ENEMY_SAVE, NEUTRAL_SAVE);
			cout << "[prompt] load success!" << endl;
			break;
		}
		else 
		{
			cout << "[prompt] error, please enter restart or load" << endl;
		}
	}

	while(1)
	{
		cout<<"command >>> ";
		getline(cin,command);
		state = GameRun.Handle(command);
		if(state == SQUIT)
		{
			break;
		}
	}
}