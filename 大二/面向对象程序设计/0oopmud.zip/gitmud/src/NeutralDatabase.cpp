#include"NeutralDatabase.h"
using namespace std;

NeutralDatabase::~NeutralDatabase()
{
    for(auto elem: entity)
    {
        delete elem.second;
    }
}

bool NeutralDatabase::Load(const char* filename)
{
    ifstream file_in(filename);
    if(!file_in.good()) return false;

    string temp;
    entityid id;
    string name;
    int exp;            //��ɱ���ȡ�ľ���ֵ
    string description;
    int num;
    entityid dropid;
    entityid tokenid;
    int probability;

    while(file_in.good())
    {
        //��ʱ����
        list<pair<entityid, int>> dropitems; //������Ʒ��int��ʾ�������
        list<entityid> tokens;

        file_in >> temp >> id;

        file_in >> temp;
        //get name, ȥ��ǰ���ո�
        getline(file_in, name);
        name.erase(0, name.find_first_not_of(" "));    
         
        file_in >> temp >> exp;

        file_in >> temp;
        getline(file_in, description);
        description.erase(0, description.find_first_not_of(" "));

        file_in >> temp >> num;
        
        for(int i = 0; i < num; i++)
        {
            file_in >> temp >> dropid >> probability;
            dropitems.push_back(make_pair(dropid, probability));
        }

        file_in >> temp >> num;
        for(int i = 0; i < num; i++)
        {
            file_in >> temp >> tokenid;
            tokens.push_back(tokenid);
        }

        Neutral* neutral = new Neutral(name, id, description, exp, dropitems, tokens);

        entity[id] = neutral;
        name_id[name] = id;

    }

    file_in.close();
    return true;
}

bool NeutralDatabase::Store(const char* filename)
{
    ofstream file_out(filename);
    if(!file_out.good()) return false;

    for(auto elem : entity)
    {
        file_out << "[ID] " << elem.second->ID() << "\n"
                 << "[NAME] " << elem.second->Name() << "\n"
                 << "[EXP] " << elem.second->GetExp() << "\n"
                 << "[DESCRIPTION] " << elem.second->GetDescription() << "\n"
                 << "[BOOTY_NUM] " << elem.second->GetBooty().size() << "\n";

        
        auto dropitems = elem.second->GetBooty();
        for(auto item : dropitems)
        {
            file_out << "[DROPITEM] " << item.first << " " << item.second << "\n";
        }

        auto tokens = elem.second->GetToken();
        file_out << "[TOKENNUM] " << tokens.size() << "\n";
        for(auto tok : tokens)
        {
            file_out << "[TOKEN] " << tok << "\n";
        }
                 
    }

    file_out.close();
    return true;
}