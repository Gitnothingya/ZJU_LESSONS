## 玩家�?
### 基本属�?
Strength 影响基础伤害和防�?
Health 影响恢复能力和总生命�?
Agility 敏捷，影响精确度和躲避率
EXP 经验，建议设定指数经验曲�?
Level 等级，随等级提升三个核心属性会增强，其余属性随之增�?
Money 
HP 生命�?
Regen 恢复能力
Accuracy 精确�?
Dodging 躲避�?
Damage 伤害，基础伤害+装备加成
Defense 防御
MaxHP 最大生命�?