## Weapon
### 基本属�?
min
max
Speed
Proficiency 熟练�?
Durability 耐久�?
需要随机数生成伤害

## Armor




## Potion
一次性用�?
治疗药剂
毒药