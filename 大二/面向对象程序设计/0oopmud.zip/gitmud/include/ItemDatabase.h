#ifndef _ITEMDATABASE_H_
#define _ITEMDATABASE_H_
#include"EntityDatabase.h"
#include"Item.h"
#include<fstream>

class ItemDatabase;

class ItemDatabase : public EntityDatabase<Item*>
{
public:
    ~ItemDatabase();
    bool Load(const char* filename);
    bool Store(const char* filename);
};

#endif