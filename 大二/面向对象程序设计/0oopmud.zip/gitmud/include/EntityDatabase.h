#ifndef _ENTITYDATABASE_H_
#define _ENTITYDATABASE_H_
#include<map>
#include"Entity.h"
using namespace std;
template<class datatype> //
class EntityDatabase
{
public:
    datatype operator[](entityid id)
    {
        if(entity.count(id))
            return entity[id];
        else return nullptr;
    }

    virtual ~EntityDatabase(){}

public:
    map<entityid, datatype> entity; //容器，真正存储实体的地方
    map<string, entityid> name_id;
};

#endif