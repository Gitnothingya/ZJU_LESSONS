#ifndef NEUTRAL_H_
#define NEUTRAL_H_
#include"Npc.h"

class Neutral : public Npc
{
public:
    Neutral(const string& name, const entityid& id, const string& description, int& exp, list<pair<entityid, int>>& dropitems, list<entityid>& tokens);
    Neutral();
    ~Neutral();

    list<entityid>& GetToken();

private:
    list<entityid> tokens; //��Ҫ������id
};





#endif