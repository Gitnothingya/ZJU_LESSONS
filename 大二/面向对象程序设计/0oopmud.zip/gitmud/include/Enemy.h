#ifndef _ENEMY_H_
#define _ENEMY_H_
#include"Npc.h"

class Enemy : public Npc
{
public:
    Enemy(string name, entityid id, int HP, int accuracy, int dodging, int damage, int defense, int exp, string description, list<pair<entityid, int>> dropitems);
    Enemy();
    ~Enemy();

    void ShowInf();

    //����

    int& GetHP();
    int GetAccur();
    int GetDamage();
    int GetDefense();
    int GetDodging();

private:
    int HP;             //����ֵ
    int accurary;       //��ȷ��
    int dodging;        //�����
    int damage;         //�˺�
    int defense;        //����ֵ
};

#endif
