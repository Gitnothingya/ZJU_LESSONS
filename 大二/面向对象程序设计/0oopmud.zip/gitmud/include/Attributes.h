#ifndef _ATTRIBUTES_H_
#define _ATTRIBUTES_H_

#define MaxHP       0
#define REGEN       1
#define ACCURACY    2
#define DODGING     3
#define DAMAGE      4
#define DEFENSE     5
#define ATTRNUM 6

#include<iostream>
#include<vector>
#include<fstream>
using namespace std;
class AttributeSet
{
public:
    AttributeSet();
    static void initattrname();
    int& operator[](int attr);

    friend ostream& operator<<(ostream& stream, const AttributeSet& a);
    friend ifstream& operator>>(ifstream& stream, AttributeSet& a);

protected:
int attributes[ATTRNUM];
static vector<string> attrname;
};













#endif