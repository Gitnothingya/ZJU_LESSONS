#ifndef _ITEM_H_
#define _ITEM_H_
#include"Entity.h"
#include"Attributes.h"

enum ItemType
{
    WEAPON,
    HAT,
    CLOTH,
    TROUSER,
    SHOE,
    POTION,  //ҩ��
    TOKEN    //����ύ���������
};

typedef unsigned long int money;
class Item : public Entity
{
public:
    Item();
    Item(string name, entityid id, string description, ItemType type, money price, AttributeSet bonus);
    ~Item();
    ItemType& Type();
    money& Price();
    int& GetAttr(int attr);
    AttributeSet& GetAttrSet();
    void ShowInf();

protected:
    ItemType type;
    int Proficiency;
    int Durability;
    money price;
    AttributeSet bonus;    //�����������
};

#endif
