#ifndef NPC_H_
#define NPC_H_
#include"Entity.h"

class Npc : public Entity
{
public:
    Npc();
    Npc(const string& name, const entityid& id, const string& description, int& exp, list<pair<entityid, int>>& dropitems);

    int GetExp();
    list<pair<entityid, int>>& GetBooty();

protected:
    int exp;            //����ֵ
    list<pair<entityid, int>> dropitems; //������Ʒ��int��ʾ�������
};






#endif