#ifndef _ENEMYDATABASE_H_
#define _ENEMYDATABASE_H_

#include"EntityDatabase.h"
#include"Enemy.h"
class EnemyDatabase;

class EnemyDatabase : public EntityDatabase<Enemy*>
{
public:
    ~EnemyDatabase();
    bool Load(const char* filename);
    bool Store(const char* filename);
};

#endif