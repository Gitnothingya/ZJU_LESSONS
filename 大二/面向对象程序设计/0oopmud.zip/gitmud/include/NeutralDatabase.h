#ifndef NEUTRALDATABASE_H_
#define NEUTRALDATABASE_H_
#include"EntityDatabase.h"
#include"Neutral.h"

class NeutralDatabase;

class NeutralDatabase : public EntityDatabase<Neutral*>
{
public:
    ~NeutralDatabase();
    bool Load(const char* filename);
    bool Store(const char* filename);
};




#endif