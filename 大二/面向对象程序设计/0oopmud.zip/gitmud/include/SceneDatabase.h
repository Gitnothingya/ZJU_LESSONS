#ifndef _SCENEDATABASE_H_
#define _SCENEDATABASE_H_
#include"EntityDatabase.h"
#include"Scene.h"
class SceneDatabase : public EntityDatabase<Scene*>
{
public:
    ~SceneDatabase();
    bool Load(const char* filename);
    bool Store(const char* filename);
};

#endif