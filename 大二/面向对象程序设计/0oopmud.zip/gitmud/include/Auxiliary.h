//����������
#ifndef _AUXILIARY_H_
#define _AUXILIARY_H_
#include<string>
#include<iostream>
#include<algorithm>
#include <cassert>
#include <random>
#include <ctime>

#define ASSERT(expr, message) assert((expr) && (message))

using namespace std;

class Auxiliary
{
public:
    static char to_lower(char c);
    static string LowerCase(const string& str);
    static string ParseWord(const string& string, int index);
    static bool PartMatch(const string& partname, const string& fullname);

    //��̬�ֲ�
    static int NormalDis(int init_value);



private:
    static const string WHITESPACE;

};






#endif