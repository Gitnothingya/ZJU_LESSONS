1. Data of test
The “Data of test”has the picture of the test value, 
due to personal reason the screen shot can not be shown,
but data is the real,which can test by data in "Sample".

2. Sample
The Samples I used are is this file.

3. Code version 1
This is the code version 1.

4. Code version 2
This is the code version 2.

5. My report 
This is my own report. 