Ttrav.c即所写程序

sample内存放了一些测试样例

程序使用dev-cpp编译运行即可