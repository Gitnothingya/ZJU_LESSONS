#include "precomp.h"

#include "PopupState.h"

int PopupState::Process(unsigned int uEvent, const std::any& param)
{
	//command

	return STATE_POPUP;
}
