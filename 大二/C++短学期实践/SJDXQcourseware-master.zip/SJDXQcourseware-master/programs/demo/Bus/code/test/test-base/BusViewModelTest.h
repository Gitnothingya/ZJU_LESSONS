#pragma once

bool BusViewModel_Test() throw();
