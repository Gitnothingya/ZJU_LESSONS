
#pragma once

#define EVT_LEFT_MOUSE    101
#define EVT_RIGHT_MOUSE   102

#define STATE_START    10
#define STATE_CAPTURE  11
#define STATE_POPUP    12
