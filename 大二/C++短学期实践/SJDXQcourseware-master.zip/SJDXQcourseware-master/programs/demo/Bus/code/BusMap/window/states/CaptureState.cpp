#include "precomp.h"

#include "CaptureState.h"

int CaptureState::Process(unsigned int uEvent, const std::any& param)
{
	//command

	return STATE_CAPTURE;
}
