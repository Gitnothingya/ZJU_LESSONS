1. 由于比较庞大，所有数据文件被删除，只留下了文件夹data1~5
2. list.cpp 中是单链表的实现代码，用于与跳表比较
3. skiplist.h 与 skiplist.cpp 中分别是跳表的定义和实现
4. RandNum.cpp用于产生随机数
5. test1为测试主函数文件