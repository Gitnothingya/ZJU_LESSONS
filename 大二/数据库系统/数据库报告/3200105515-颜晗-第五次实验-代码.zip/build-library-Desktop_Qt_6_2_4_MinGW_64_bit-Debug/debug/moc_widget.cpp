/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../library/widget.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Widget_t {
    const uint offsetsAndSize[58];
    char stringdata0[323];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 6), // "Widget"
QT_MOC_LITERAL(7, 14), // "setWindowLogin"
QT_MOC_LITERAL(22, 0), // ""
QT_MOC_LITERAL(23, 17), // "setWindowRegister"
QT_MOC_LITERAL(41, 12), // "managerLogin"
QT_MOC_LITERAL(54, 11), // "deleteLogin"
QT_MOC_LITERAL(66, 10), // "Borrowfuct"
QT_MOC_LITERAL(77, 8), // "Backfuct"
QT_MOC_LITERAL(86, 10), // "borrowBook"
QT_MOC_LITERAL(97, 8), // "backBook"
QT_MOC_LITERAL(106, 11), // "updateTitle"
QT_MOC_LITERAL(118, 9), // "quitLogin"
QT_MOC_LITERAL(128, 10), // "searchBook"
QT_MOC_LITERAL(139, 11), // "searchclear"
QT_MOC_LITERAL(151, 11), // "displayBook"
QT_MOC_LITERAL(163, 3), // "row"
QT_MOC_LITERAL(167, 12), // "addSingleWin"
QT_MOC_LITERAL(180, 11), // "addMultiWin"
QT_MOC_LITERAL(192, 8), // "addMulti"
QT_MOC_LITERAL(201, 10), // "addOneBook"
QT_MOC_LITERAL(212, 8), // "showCard"
QT_MOC_LITERAL(221, 15), // "RegisterCardWin"
QT_MOC_LITERAL(237, 13), // "DeleteCardWin"
QT_MOC_LITERAL(251, 13), // "UpdateCardWin"
QT_MOC_LITERAL(265, 12), // "RegisterCard"
QT_MOC_LITERAL(278, 10), // "DeleteCard"
QT_MOC_LITERAL(289, 10), // "UpdateCard"
QT_MOC_LITERAL(300, 10), // "infoSearch"
QT_MOC_LITERAL(311, 11) // "displayInfo"

    },
    "Widget\0setWindowLogin\0\0setWindowRegister\0"
    "managerLogin\0deleteLogin\0Borrowfuct\0"
    "Backfuct\0borrowBook\0backBook\0updateTitle\0"
    "quitLogin\0searchBook\0searchclear\0"
    "displayBook\0row\0addSingleWin\0addMultiWin\0"
    "addMulti\0addOneBook\0showCard\0"
    "RegisterCardWin\0DeleteCardWin\0"
    "UpdateCardWin\0RegisterCard\0DeleteCard\0"
    "UpdateCard\0infoSearch\0displayInfo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  170,    2, 0x08,    1 /* Private */,
       3,    0,  171,    2, 0x08,    2 /* Private */,
       4,    0,  172,    2, 0x08,    3 /* Private */,
       5,    0,  173,    2, 0x08,    4 /* Private */,
       6,    0,  174,    2, 0x08,    5 /* Private */,
       7,    0,  175,    2, 0x08,    6 /* Private */,
       8,    0,  176,    2, 0x08,    7 /* Private */,
       9,    0,  177,    2, 0x08,    8 /* Private */,
      10,    0,  178,    2, 0x08,    9 /* Private */,
      11,    0,  179,    2, 0x08,   10 /* Private */,
      12,    0,  180,    2, 0x08,   11 /* Private */,
      13,    0,  181,    2, 0x08,   12 /* Private */,
      14,    1,  182,    2, 0x08,   13 /* Private */,
      16,    0,  185,    2, 0x08,   15 /* Private */,
      17,    0,  186,    2, 0x08,   16 /* Private */,
      18,    0,  187,    2, 0x08,   17 /* Private */,
      19,    0,  188,    2, 0x08,   18 /* Private */,
      20,    1,  189,    2, 0x08,   19 /* Private */,
      21,    0,  192,    2, 0x08,   21 /* Private */,
      22,    0,  193,    2, 0x08,   22 /* Private */,
      23,    0,  194,    2, 0x08,   23 /* Private */,
      24,    0,  195,    2, 0x08,   24 /* Private */,
      25,    0,  196,    2, 0x08,   25 /* Private */,
      26,    0,  197,    2, 0x08,   26 /* Private */,
      27,    0,  198,    2, 0x08,   27 /* Private */,
      28,    1,  199,    2, 0x08,   28 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Widget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->setWindowLogin(); break;
        case 1: _t->setWindowRegister(); break;
        case 2: _t->managerLogin(); break;
        case 3: _t->deleteLogin(); break;
        case 4: _t->Borrowfuct(); break;
        case 5: _t->Backfuct(); break;
        case 6: _t->borrowBook(); break;
        case 7: _t->backBook(); break;
        case 8: _t->updateTitle(); break;
        case 9: _t->quitLogin(); break;
        case 10: _t->searchBook(); break;
        case 11: _t->searchclear(); break;
        case 12: _t->displayBook((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->addSingleWin(); break;
        case 14: _t->addMultiWin(); break;
        case 15: _t->addMulti(); break;
        case 16: _t->addOneBook(); break;
        case 17: _t->showCard((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 18: _t->RegisterCardWin(); break;
        case 19: _t->DeleteCardWin(); break;
        case 20: _t->UpdateCardWin(); break;
        case 21: _t->RegisterCard(); break;
        case 22: _t->DeleteCard(); break;
        case 23: _t->UpdateCard(); break;
        case 24: _t->infoSearch(); break;
        case 25: _t->displayInfo((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject Widget::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_Widget.offsetsAndSize,
    qt_meta_data_Widget,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Widget_t
, QtPrivate::TypeAndForceComplete<Widget, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 26;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
