/*

ZigZagging on a Tree

Sample Input:
8
12 11 20 17 1 15 8 5
12 20 17 11 15 8 5 1

Sample Output:
1 11 5 8 17 12 20 15

*/

int printf(const char *format, ...);
int scanf(const char *format, ...);
void* malloc(long);
void free(void*);

const int MaxSize = 31;

typedef struct {
    int Data;
    TreeNode* Left;
    TreeNode* Right;
} TreeNode;
typedef TreeNode* Tree;

typedef struct{
    int front;
    int rear;
    Tree point[31];
} DouQueue;
typedef DouQueue *Queue;

Tree BuildTree(int N,int inorder[],int postorder[],int left1,int right1,int left2,int right2);
void ZigOrderTraversal(int N,Tree BT);
void InQueue(int mode,Queue Q,Tree BT);
Tree DelQueue(int mode,Queue Q);
int IsEmptyQ(Queue Q);

int main()
{   
    int N;
    scanf("%d",&N);
    int* inorder = malloc(N * sizeof(int));
    int* postorder = malloc(N * sizeof(int));
    for(int i=0;i<N;i++) scanf("%d",&inorder[i]);
    for(int i=0;i<N;i++) scanf("%d",&postorder[i]);
    Tree T1;
    T1 = BuildTree(N,inorder,postorder,0,N-1,0,N-1);
    ZigOrderTraversal(N,T1);
    return 0;
}

Tree BuildTree(int N,int inorder[],int postorder[],int left1,int right1,int left2,int right2){//利用中序和后序结果建立树
    if(N==0) return 0;
    Tree T=malloc(sizeof(TreeNode));
    T->Data=postorder[right2];
    int i;
    for(i=left1;i<=right1;i++){
        if(inorder[i]==postorder[right2]) break;
    }
    if(i==left1) T->Left=0;
    else T->Left=BuildTree(N,inorder,postorder,left1,i-1,left2,left2+i-left1-1);
    if(i==right1) T->Right=0;
    else T->Right=BuildTree(N,inorder,postorder,i+1,right1,right2-right1+i,right2-1);
    return T;
}

void InQueue(int mode,Queue Q,Tree BT){
    if(mode==1){//从队尾入队
    (Q->point)[(Q->rear++)%MaxSize]=BT;
    }
    else{//从队头入队
    if(Q->front==0){
        Q->front=MaxSize-1;
        (Q->point)[Q->front]=BT;
    } 
    else {
        Q->front--;
        (Q->point)[Q->front]=BT;
    }
}}

Tree DelQueue(int mode,Queue Q){
    if(mode==1){//从队头出队
    Tree temp=(Q->point)[Q->front];
    Q->front++;
    Q->front=(Q->front)%MaxSize;
    return temp;
    }
    else{//从队尾出队
    if(Q->rear==0){
        Q->rear=MaxSize-1;
        return (Q->point)[Q->rear];
    }
    else{
        Q->rear--;
        return (Q->point)[Q->rear];
    }
    }
}

int IsEmptyQ(Queue Q){
    if(Q->front==Q->rear) return 1;
    return 0;
}

void ZigOrderTraversal(int N,Tree BT){
    if(!BT) return;	
    Tree T;
    int cnt=0;
    int ifprint=0;
    int layer=1;//循环层数
    int null=0;//记录空结点影响因子
    int times=1;
    Queue Q=malloc(sizeof(DouQueue));
    Q->front=Q->rear=0;
    if(N==1) {printf("%d",BT->Data);
    return;}
    else {printf("%d ",BT->Data);
    cnt++;}
    if(BT->Left) InQueue(1,Q,BT->Left);
    else null++;
    if(BT->Right) InQueue(1,Q,BT->Right);
    else null++;
    while(!IsEmptyQ(Q)){
        while(1){
            times=1;
            for(int i=0;i<layer;i++) times*=2;
            times-=null;
            null*=2;
            for(int i=0;i<times;i++){
                if(layer%2){
                    T=DelQueue(1,Q);
                    if(++cnt<N) printf("%d ",T->Data);
                    else {printf("%d",T->Data);
                    return;}
                    if(T->Left) InQueue(1,Q,T->Left);
                    else null++;
                    if(T->Right) InQueue(1,Q,T->Right);
                    else null++;
                }
                else{
                    T=DelQueue(2,Q);
                    if(++cnt<N) printf("%d ",T->Data);
                    else {printf("%d",T->Data);
                    return;}
                    if(T->Right) InQueue(2,Q,T->Right);
                    else null++;
                    if(T->Left) InQueue(2,Q,T->Left);
                    else null++;
                }
            }
            layer++;
        }
    }
    printf("\n");
}