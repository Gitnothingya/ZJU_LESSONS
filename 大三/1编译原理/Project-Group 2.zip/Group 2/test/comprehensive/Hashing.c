/*
Given a hash table of size N, we can define a hash function H(x)=x%N. 
Suppose that the linear probing is used to solve collisions, we can easily obtain the status of the hash table with a given sequence of input numbers.

However, now you are asked to solve the reversed problem: reconstruct the input sequence from the given status of the hash table. 
Whenever there are multiple choices, the smallest number is always taken.

Sample Input:
11
33 1 13 12 34 38 27 22 32 -1 21

Sample Output:
1 13 12 21 33 34 38 27 22 32
*/

int printf(const char *format, ...);
int scanf(const char *format, ...);
void* malloc(long);
void free(void*);

// 将相对关系转变为绝对关系，用拓扑排序
int main() {
    int N;
    scanf("%d",&N);
    int *table = malloc(N*sizeof(int));
    for (int i=0;i<N;i++) {
        scanf("%d",&table[i]);
    }
    int *G = malloc(N*N*sizeof(int)); // G[N][N]
    for (int i=0;i<N;i++) {
        for (int j=0;j<N;j++) {
            G[i*N+j]=0;
        }
    }
    // 计算相对依赖关系
    for (int i=0;i<N;i++) {
        if (table[i]>=0) {
        int index=table[i]%N;
        if (i>index) {
            for (int j=index;j<i;j++) {
                G[j*N+i]=1;
            }
        }
        else if (i<index) {
            for (int j=0;j<i;j++) {
                G[j*N+i]=1;
            }
            for (int j=index;j<N;j++) {
                if (table[j]>=0) G[j*N+i]=1;
            }
        }
    }}
    int *indegree = malloc(N*sizeof(int));
    for (int i=0;i<N;i++) indegree[i]=0;
    // 要输出的个数
    int cnt=0;
    for (int i=0;i<N;i++) {
        if (table[i]>=0) {
            cnt++;
        }
        else indegree[i]=-1;
    } 
    // 算入度
    for (int i=0;i<N;i++) {
        for (int j=0;j<N;j++) {
            if (G[j*N+i]==1) indegree[i]++;
        }
    }
    // 找出序列
    int *ENABLE = malloc(cnt*sizeof(int));
    int EN_number=0;
    for (int j=0;j<N;j++) {
        if (indegree[j]==0) ENABLE[EN_number++]=j;
    }
    for (int i=0;i<cnt;i++) {
        // 找出最小的
        int mindex=-1;
        int min=100000000;
        int indice;
        for (int k=0;k<EN_number;k++) {
            if (ENABLE[k]>=0) {
            if (table[ENABLE[k]]<min) {
                min=table[ENABLE[k]];
                mindex=ENABLE[k];
                indice=k;
            } 
        }}
        for (int i=0;i<N;i++) {
            if (indegree[i]>0) {
                if (G[mindex*N+i]) {
                    if (--indegree[i]==0) ENABLE[EN_number++]=i;
                }
            }
        }
        printf("%d",min);
        if (i!=cnt-1) printf(" ");
        ENABLE[indice]=-1;
    }
    printf("\n");
    return 0;
}