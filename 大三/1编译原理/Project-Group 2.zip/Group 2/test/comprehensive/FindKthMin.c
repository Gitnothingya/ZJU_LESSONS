/*
平均时间为O(n)的算法，在n(1<=n<=1000)个无序的整数中找出第k小的数

input: n k n个整数
output: 第k小的数

Sample Input:
10 4
2 8 9 0 1 3 6 7 8 2

Sample Output:
2

*/

int printf(const char *format, ...);
int scanf(const char *format, ...);
void* malloc(long);
void free(void*);

int partition(int a[], int left, int right);
int find(int a[], int left, int right, int k);

int partition(int a[], int left, int right) {
    int pivot = a[left];
    while (left < right) {
        while (left < right && a[right] >= pivot) right--;
        if (left < right) a[left++] = a[right];
        while (left < right && a[left] <= pivot) left++;
        if (left < right) a[right--] = a[left];
        a[left] = pivot;
    }
    return left;
}

int find(int a[], int left, int right, int k) {
    int index = partition(a, left, right);
    if (index == k-1) return a[index];
    else if (index > k-1) return find(a, left, index-1, k);
    else return find(a, index+1, right, k);
}

int main() {
    int n, k;
    scanf("%d %d", &n, &k);
    int* a = malloc(n * sizeof(int));
    for (int i = 0; i < n; i++) scanf("%d",&a[i]);
    int result = find(a, 0, n-1, k);
    printf("%d\n", result);
    free(a);
}