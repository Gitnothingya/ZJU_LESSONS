int printf(const char *format, ...);

int main(void) {
    int a[5] = { 1, 2, 3 };
    int* p = a;
    p[4] = 8;    
    double b[3][5];

    for (int i = 0; i < 5; i++) {
        printf("a[%d]: %d\n", i, a[i]);
        printf("p[%d]: %d\n", i, p[i]);
    }

    b[2][0] = 2.0;
    printf("b[1][5] = %lf == b[2][0] = %lf\n", b[1][5], b[2][0]);
    return 0;
}