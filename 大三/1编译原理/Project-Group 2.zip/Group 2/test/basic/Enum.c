int printf(const char *format, ...);

enum DAY {
    MON=1, TUE, WED, THU=4, FRI, SAT, SUN
} day;

int main() {
    for (day = MON; day <= SUN; day++) {
        printf("Value of enumerator: %d \n", day);
    }
    enum DAY crazyThursday = THU;
    printf("Have you been crazy on %dth day of the week?\n", crazyThursday);
    return 0;
}