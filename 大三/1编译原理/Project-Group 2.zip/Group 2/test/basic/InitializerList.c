int printf(char *, ...);

const int MONTHS = 12;

int main()
{
    int days[MONTHS] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    int index;

    for (index = 0; index < MONTHS; index++) {
        printf("Month %2d has %2d days.\n", index + 1, days[index]);
    }

    int a[] = { 3, 9, 3, 6 };
    int size = sizeofvar(a) / sizeof(int);
    for (int i = 0; i < size; i++) {
        printf("a[%d]: %d\n", i, a[i]);
    }
    
    return 0;
}