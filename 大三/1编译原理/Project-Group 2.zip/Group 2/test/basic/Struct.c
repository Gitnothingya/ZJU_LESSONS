int printf(const char *format, ...);

struct test {
    int i;
    char c;
    double d;
} t1;

int main(void) {
    t1.i = 1;
    t1.c = 'a';
    t1.d = 1.5;
    printf("%d\n", t1.i);
    printf("%c\n", t1.c);
    printf("%lf\n", t1.d);

    struct test t2;
    t2.i = 2;
    t2.c = 'b';
    t2.d = 2.5;    
    printf("%d\n", t2.i);
    printf("%c\n", t2.c);
    printf("%lf\n", t2.d);

    return 0;
}