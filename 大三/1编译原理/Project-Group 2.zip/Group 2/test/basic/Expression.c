/*
Sample Output:
======= test1 =======
a + b = 30
c - a = 20
b * c = 600
c / a = 3
c % a = 0
-b = -20
++a = 11
--b = 19
(a > b) && (b > c) = 0
(a > b) || (b > c) = 0
!(a > b) = 1
a & b = 3
a | b = 27
a ^ b = 24
~a = -12
b << 2 = 76
c >> 1 = 15
a > b ? a : b = 19
c > b ? c : b = 30
ch == 'A' ? 'B' : 'C' = B
x > y ? x : y = 3.140000
str[0] == 'h' ? str : 'world' = hello
======= test2 =======
sizeof(struct Person) = 24
sizeofvar(p) = 24
Person's age: 25, name: John
arr[2] = 3
p.name[3] = n
&arr[3] = 0x7ffe29f39ba8
&p.age = 0x7ffe29f39b78
*p_arr = 1
*(&p.age) = 25
add(1, 2) = 3
x = 2, y = 3, z = 4, result  = 9
(float)i / j = 3.333333
(int)f = 3
*/

int printf(const char *format, ...);
int scanf(const char *format, ...);
char *strcpy(char *dest, const char *src);

int add(int a, int b) {
    return a + b;
}

struct Person {
    int age;
    char name[20];
};

typedef struct Person* pPerson;

void test1() {
    printf("======= test1 =======\n");
    int a = 10, b = 20, c = 30;
    float x = 3.14, y = 2.71;
    char ch = 'A', str[] = {'h', 'e', 'l', 'l', 'o', 0};
    
    // 算术运算
    printf("a + b = %d\n", a + b);
    printf("c - a = %d\n", c - a);
    printf("b * c = %d\n", b * c);
    printf("c / a = %d\n", c / a);
    printf("c %% a = %d\n", c % a);
    printf("-b = %d\n", -b);
    printf("++a = %d\n", ++a);
    printf("--b = %d\n", --b);
    
    // 逻辑运算
    printf("(a > b) && (b > c) = %d\n", (a > b) && (b > c));
    printf("(a > b) || (b > c) = %d\n", (a > b) || (b > c));
    printf("!(a > b) = %d\n", !(a > b));
    
    // 位运算
    printf("a & b = %d\n", a & b);
    printf("a | b = %d\n", a | b);
    printf("a ^ b = %d\n", a ^ b);
    printf("~a = %d\n", ~a);
    printf("b << 2 = %d\n", b << 2);
    printf("c >> 1 = %d\n", c >> 1);
    
    // 条件运算
    printf("a > b ? a : b = %d\n", a > b ? a : b);
    printf("c > b ? c : b = %d\n", c > b ? c : b);
    printf("ch == 'A' ? 'B' : 'C' = %c\n", ch == 'A' ? 'B' : 'C');
    printf("x > y ? x : y = %f\n", x > y ? x : y);
    printf("str[0] == 'h' ? str : 'world' = %s\n", str[0] == 'h' ? str : "world");
}

void test2() {
    printf("======= test2 =======\n");
    int arr[5] = {1, 2, 3, 4, 5};
    struct Person p;
    pPerson pp = &p;
    p.age = 25;
    strcpy(pp->name, "John");
    int *p_arr = arr;

    // Sizeof
    printf("sizeof(struct Person) = %d\n", sizeof(struct Person));
    printf("sizeofvar(p) = %d\n", sizeofvar(p));
    
    // 取结构体成员
    printf("Person's age: %d, name: %s\n", p.age, p.name);
    
    // 数组下标
    printf("arr[2] = %d\n", arr[2]);
    printf("p.name[3] = %c\n", p.name[3]);
    
    // 取地址
    printf("&arr[3] = %p\n", &arr[3]);
    printf("&p.age = %p\n", &p.age);
    
    // 解析地址
    printf("*p_arr = %d\n", *p_arr);
    printf("*(&p.age) = %d\n", *(&p.age));

    // 函数调用
    printf("add(1, 2) = %d\n", add(1, 2));

    // 逗号表达式
    int x = 1, y = 2, z = 3;
    int result = (x++, y++, z++, x + y + z);
    printf("x = %d, y = %d, z = %d, result  = %d\n", x, y, z, result);
    
    // 强制类型转换
    int i = 10, j = 3;
    float f = 3.14;
    printf("(float)i / j = %f\n", (cast float)i / j);
    printf("(int)f = %d\n", (cast int)f);
}

int main() {
    test1();
    test2();
    return 0;
}