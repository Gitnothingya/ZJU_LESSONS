/*
将一个百分制成绩转换为五分制成绩
Sample Input: 90
Sample Output: A
*/

int printf(const char *format, ...);
int scanf(const char *format, ...);

int main()
{
    int g;
    scanf("%d", &g);
    if (g >= 90)
        printf("A\n");
    else if (80 <= g && g < 90)
        printf("B\n");
    else if (70 <= g && g < 80)
        printf("C\n");
    else if (60 <= g && g < 70)
        printf("D\n");
    else
        printf("E\n");

    return 0;
}