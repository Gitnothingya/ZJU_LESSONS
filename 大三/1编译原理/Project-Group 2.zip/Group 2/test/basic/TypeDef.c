int printf(const char *format, ...);
void* malloc(long);
void free(void*);

typedef struct {
    int value;
	Node* left;
    Node* right;    
} Node;

typedef Node* pNode;
typedef int arr[5];

int main(void) {
    pNode root;    
    root = (cast pNode)malloc(sizeof(Node));
    root->value = 3936;
    printf("root->value: %d\n", root->value);
    free(root);

    arr a = { 4, 5, 6 };
    for (int i = 0; i < 5; i++) {
        printf("a[%d]: %d\n", i, a[i]);
    }

    return 0;
}