/*
两个整数的简单计算器
Sample Input: -7 / 2
Sample Output: -3
*/

int printf(const char *format, ...);
int scanf(const char *format, ...);

int main()
{
	int a, b;
	char c;
	scanf("%d %c %d", &a, &c, &b);
	switch (c) { 
        case '+': a += b; break; 
        case '-': a -= b; break; 
        case '*': a *= b; break; 
        case '/': a /= b; break; 
        case '%': a %= b; break; 
        default: printf("ERROR\n"); return 0;
    }
    printf("%d\n",a);	
    return 0;	
}