int printf(const char *format, ...);

int main()  {
    int i = 0;
    while (1) {
        i++;
        if (i % 2 == 0) {
            continue;
        }
        if (i > 10) {
            break;
        }
        printf("%d ", i);
    }
    printf("\n");
    return 0;
}