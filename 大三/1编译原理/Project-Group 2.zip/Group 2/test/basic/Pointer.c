int printf(const char *format, ...);

int* ptr; // 指针变量
char* c[10]; // 指针数组

typedef int arr[5];
typedef arr* arrptr; // 数组指针
arrptr b;  

struct test {
    char a;
} t;
typedef struct test* structptr; // 结构体指针
structptr y = &t;

void main(void)
{
    int x = 1;
    ptr = &x;

    c[0] = "Hello";

    int a[3][5];
    b = a;
    a[0][0] = 1278;
    a[1][0] = 3936;

    t.a = '$';

    printf("%d\n", *ptr);
    printf("%s\n", c[0]);
    printf("%d\n", *b[0]);
    printf("%d\n", b[1][0]);
    printf("%c\n", y->a);
}