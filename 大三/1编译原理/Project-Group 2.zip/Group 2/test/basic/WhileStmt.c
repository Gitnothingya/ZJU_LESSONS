int printf(const char *format, ...);
int scanf(const char *format, ...);

int main() {
    int n, i = 1, sum = 0;
    printf("Please input an integer: ");
    scanf("%d", &n);
    while (i <= n) {
        sum += i * i;
        i++;
    }
    printf("The sum of the squares of all integers from 1 to %d is: %d\n", n, sum);
    return 0;
}