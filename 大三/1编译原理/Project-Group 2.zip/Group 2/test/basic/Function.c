int printf(const char *format, ...);

// pass value
int add(int a, int b) {
    return a + b;
}
// pass array(address)
int sum(int a[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += a[i];
    }
    return sum;
}
// pass pointer(address)
void swap(int *a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

int main(void){
    int i = 2;
    int j = 5;
    int a[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    printf("add: %d\n", add(i, j));
    printf("sum: %d\n", sum(a, 10));
    printf("before swap, i = %d, j = %d\n", i, j);
    swap(&i, &j);
    printf("after swap, i = %d, j = %d\n", i, j);
	return 0;
}