int printf(const char *format, ...);

int main(void) {
    int sum = 17, count = 5;
    double mean;
    mean = (cast double)sum / count; //强制类型转换
    printf("Value of mean: %lf\n", mean);

    int i = 17;
    char c = 'c'; /* ascii 值是 99 */
    int sum1;
    sum1 = i + c; // 类型升级
    printf("Value of sum1: %d\n", sum1);
    
    return 0;
}