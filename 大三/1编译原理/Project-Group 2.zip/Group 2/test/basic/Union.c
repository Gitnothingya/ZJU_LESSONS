int printf(const char *format, ...);
char *strcpy(char *dest, const char *src);
 
union Data {
   int i;
   float f;
   char str[20];
};
 
int main( ) {
   union Data data;        
 
   data.i = 10;
   printf( "data.i : %d\n", data.i);
   
   data.f = 220.5;
   printf( "data.f : %f\n", data.f);
   
   strcpy( data.str, "C Programming");
   printf( "data.str : %s\n", data.str);

   printf("Memory size occupied by data : %d\n", sizeofvar(data));
 
   return 0;
}