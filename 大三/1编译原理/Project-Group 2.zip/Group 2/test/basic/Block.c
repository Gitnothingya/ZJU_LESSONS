/*
Block b = 5
b = 10
*/

int printf(const char *format, ...);
int scanf(const char *format, ...);
void* malloc(long);
void free(void*);

int a = 0;
int b = 8;
const int c = 9;

int main(void) {
    const int a = 5;
    enum {
        c = 10
    };
    {
        int b = a;
        printf("Block b = %d\n",b);
    }
    int b = c;
    printf("b = %d\n",b);
    return 0;
}