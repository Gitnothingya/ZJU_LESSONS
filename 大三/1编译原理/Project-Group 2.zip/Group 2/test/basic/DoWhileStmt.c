int printf(const char *format, ...);

int main () {
   /* 局部变量定义 */
   int a = 10;

   /* do 循环执行，在条件被测试之前至少执行一次 */
   do {
       printf("current value of a: %d\n", a);
       a = a + 1;
   } while( a < 20 );
 
   return 0;
}