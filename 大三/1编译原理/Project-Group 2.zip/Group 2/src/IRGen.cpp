#include "SemanticCtx.hpp"
#include "utils.hpp"
#include "ast.hpp"
#include <string>
#include <iostream>
#include <unordered_set>

namespace ast {
	// ast树的根节点Program
	llvm::Value* Program::IRGen(SemanticCtx& __Ctx){
		// 对其所有子结点分别生成IR即可
		if (this->_ExternalDecls) {
			for (auto Decl : *(this->_ExternalDecls)) {
				if (Decl) {
					Decl->IRGen(__Ctx);
				}
			}
		}
		return NULL;
	}
	
	// 函数定义(包含函数体)
	llvm::Value* FuncDef::IRGen(SemanticCtx& __Ctx){
		// 先检查参数表信息，包括类型合法性，void，是否有变量名等

		// 获取参数类型表
		std::vector<llvm::Type*> ArgTypes;
		// 参数中是否包含void类型的标志
		bool VoidFlag = false;
		for (auto ArgType : *(this->_ParameterList)) {
			// 检查类型是否合法
			
			llvm::Type* PaType = ArgType->MyType->GetLLVMType(__Ctx);
			
			if (!PaType) {
				// 非法类型
				throw std::logic_error("Function '" + this->_FuncName + "' using unknown type name");
				return NULL;
			} else if (PaType->isVoidTy()) {
				// 检查是否有void类型，方便后面和参数个数进行比较
				VoidFlag = true;
				continue;
			} else if (PaType->isArrayTy()) {
				// 参数如果有数组类型，我们应该传递指针，而不是整个数组，需修改类型
				
				// 需要判断多维数组，除了最高维以外其余必须有数值
				if (ArgType->MyType->_AbstractDeclarator->_ArrayDimensions && ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->size() > 1) {
					for (auto iter = ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->begin()+1; iter != ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->end(); ++iter){
						auto DimInfo = *iter;
						if (!DimInfo) {
							throw std::logic_error("Declaration of multidimensional array must have bounds for all dimensions except the first in function '" + this->_FuncName + "'.");
							return NULL;
						}
					}
				}
				
				// 下面的API是在获取数组元素类型的指针类型
				PaType = PaType->getArrayElementType()->getPointerTo();
			}
			
			// 检查是否有标识符
			if (ArgType->_VarName == "") {
				throw std::logic_error("Parameter name of the function \"" + this->_FuncName + "\" defining omitted.");
				return NULL;
			}
			// 检查无误后，push进类型表中
			ArgTypes.push_back(PaType);
		}
		// 参数列表有void并且参数个数不为0(不包括void)需要抛出异常
		if (ArgTypes.size() > 0 && VoidFlag) {
			throw std::logic_error("'void' msut be the only parameter in the function '" + this->_FuncName + "'.");
			return NULL;
		}
		
		// 获取函数返回类型，如果是数组要报错
		llvm::Type* RetType = this->_RetType->GetLLVMType(__Ctx);
		if (RetType->isArrayTy()) {
			throw std::logic_error("Defining Function " + this->_FuncName + " return type can't be an array.");
			return NULL;
		}
		// 根据返回类型和参数类型表构造函数类型(其中,第三个为函数参数是否可变长)
		llvm::FunctionType* FuncType;
		FuncType = llvm::FunctionType::get(RetType, ArgTypes, this->_ParameterList->_isVariable);
		
		// 根据函数类型、链接方式、函数名和编译单元module来构造llvm类型的function，并加入符号表中
		llvm::Function* Function = llvm::Function::Create(FuncType, llvm::GlobalValue::ExternalLinkage, this->_FuncName, __Ctx.module);
		__Ctx.addFunction(this->_FuncName, Function);
		
		// LLVM内部会自动处理重名，如果函数重名，新定义的函数名字会被修改
		// 函数定义不允许重名，因而我们先检查函数名，但需要进一步的判断，因为可能是前面的声明
		if (Function->getName() != this->_FuncName) {
			// 移除重名函数，获取之前的函数（可能是之前的声明，这是正确的；也可能是重复定义，这个要报错）
			Function->eraseFromParent();
			Function = __Ctx.module->getFunction(this->_FuncName);
			// 重复定义函数抛出异常
			if (!Function->empty()) {
				throw std::logic_error("Redefinition of '" + this->_FuncName + "'.");
				return NULL;
			}
			// 同名函数的声明，但函数类型不同，即c语言不支持函数重载，也要抛出异常
			if (Function->getFunctionType() != FuncType) {
				throw std::logic_error("Defining function " + this->_FuncName + " and its declaration have different parameter or return types.");
				return NULL;
			}
		}

		// 检查无误后，为函数体构造基本块
		llvm::BasicBlock* FuncBlock = llvm::BasicBlock::Create(Context, "entry", Function);
		// 使用IRBuilder设置当前插入点到刚才创建的基本块FuncBlock，使之后可以在该函数基本块中插入指令。
		IRBuilder.SetInsertPoint(FuncBlock);

		// 给参数分配空间并创建新的符号表，这个新的符号表仅仅用来存储函数参数
		__Ctx.pushSymbolTable();
		size_t Index = 0;
		for (auto ArgEle = Function->arg_begin(); ArgEle < Function->arg_end(); ArgEle++) {
			// stack中分配空间
			auto Alloc = CreateEntryBlockAlloca(Function, this->_ParameterList->at(Index)->_VarName, ArgTypes[Index]);
			// 通过store指令进行存储
			IRBuilder.CreateStore(ArgEle, Alloc);
			// 将临时变量加入符号表,判断在当前块中是否有重名
			if (!__Ctx.addVariable(this->_ParameterList->at(Index)->_VarName, Alloc)) {
				throw std::logic_error("Redefining variable " + this->_ParameterList->at(Index)->_VarName + ".");
				return NULL;
			}
			Index++;
		}
		
		// 设置当前函数，方便语义分析
		__Ctx.enterFunction(Function);

		// 产生函数体的代码，符号表的push和pop在funcbody的代码生成函数
		this->_FuncBody->IRGen(__Ctx);

		// 如果函数没有return语句，需要有默认返回值undefined
		if (!IRBuilder.GetInsertBlock()->getTerminator()) {
			llvm::Type* RetTy = __Ctx.getCurrentFunction()->getReturnType();
			if (RetTy->isVoidTy()) {
				// 函数返回类型为void
				IRBuilder.CreateRetVoid();
			} else {
				// 函数返回类型不为void，需要有未定义值返回
				IRBuilder.CreateRet(llvm::UndefValue::get(RetTy));
			}
		}

		// 离开当前函数，与前面对应
		__Ctx.leaveFunction();

		// pop参数符号表
		__Ctx.popSymbolTable();

		return NULL;
	}

	// 函数声明(没有函数体)，建一个空壳即可
	llvm::Value* FuncDecl::IRGen(SemanticCtx& __Ctx){
		// 先检查参数表信息，包括类型合法性，void等，注：不需要检查参数变量名，因为函数声明不care这个

		// 获取参数类型表
		std::vector<llvm::Type*> ArgTypes;
		// 参数中是否包含void类型的标志
		bool VoidFlag = false;
		for (auto ArgType : *(this->_ParameterList)) {
			// 检查类型是否合法
			llvm::Type* PaType = ArgType->MyType->GetLLVMType(__Ctx);
			if (!PaType) {
				// 非法类型
				throw std::logic_error("Function '" + this->_FuncName + "' using unknown type name");
				return NULL;
			} else if (PaType->isVoidTy()) {
				// 检查是否有void类型，方便后面和参数个数进行比较
				VoidFlag = true;
				continue;
			} else if (PaType->isArrayTy()) {
				// 参数如果有数组类型，我们应该传递指针，而不是整个数组，需修改类型

				// 需要判断多维数组，除了最高维以外其余必须有数值
				if (ArgType->MyType->_AbstractDeclarator->_ArrayDimensions && ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->size() > 1) {
					for (auto iter = ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->begin()+1; iter != ArgType->MyType->_AbstractDeclarator->_ArrayDimensions->end(); ++iter){
						auto DimInfo = *iter;
						if (!DimInfo) {
							throw std::logic_error("Declaration of multidimensional array must have bounds for all dimensions except the first in function '" + this->_FuncName + "'.");
							return NULL;
						}
					}
				}

				// 下面的API是在获取数组元素类型的指针类型
				PaType = PaType->getArrayElementType()->getPointerTo();
			}
			// 检查无误后，push进类型表中
			ArgTypes.push_back(PaType);
		}
		// 参数列表有void并且参数个数不为0(不包括void)需要抛出异常
		if (ArgTypes.size() > 0 && VoidFlag) {
			throw std::logic_error("'void' msut be the only parameter in the function '" + this->_FuncName + "'.");
			return NULL;
		}

		// 获取函数返回类型，如果是数组要报错
		llvm::Type* RetType = this->_RetType->GetLLVMType(__Ctx);
		if (RetType->isArrayTy()) {
			throw std::logic_error("Declaring Function " + this->_FuncName + " return type can't be an array.");
			return NULL;
		}

		// 根据返回类型和参数类型表构造函数类型(其中,第三个为函数参数是否可变长)
		llvm::FunctionType* FuncType = llvm::FunctionType::get(RetType, ArgTypes, this->_ParameterList->_isVariable);

		// 根据函数类型、链接方式、函数名和编译单元module来构造函数，并加入符号表中
		llvm::Function* Function = llvm::Function::Create(FuncType, llvm::GlobalValue::ExternalLinkage, this->_FuncName, __Ctx.module);
		__Ctx.addFunction(this->_FuncName, Function);

		// 函数声明允许重名，但需要检查参数表的类型
		if (Function->getName() != this->_FuncName) {
			// 移除重名函数，获取之前的函数
			Function->eraseFromParent();
			Function = __Ctx.module->getFunction(this->_FuncName);
			// 同名函数的声明，但函数类型不同，即c语言不支持函数重载，要抛出异常
			if (Function->getFunctionType() != FuncType) {
				throw std::logic_error("Declaration function " + this->_FuncName + " and its previous declaration or defining have different arg or return types.");
				return NULL;
			}
		}
		
		return NULL;
	}

	// 变量声明和定义
	llvm::Value* VarDecl::IRGen(SemanticCtx& __Ctx){
		// 先获取BaseType的LLVMType

		// 检查类型，判断是否存在以及是否为void类型
		llvm::Type* BaseType = this->_TypeSpec->GetLLVMType(__Ctx);
		if (BaseType == NULL) {
			// 类型不存在
			throw std::logic_error("Can't define variables of unknown type.");
			return NULL;
		} else if (BaseType->isVoidTy()) {
			// void类型
			throw std::logic_error("Can't define 'void' variables.");
			return NULL;
		}
		
		// 每个变量结合BaseType和声明子组成重组类型加入符号表，有初始化的还得生成对应的Store代码
		if (this->_VarInitList) {
			for (auto& VarEle : *(this->_VarInitList)) {
				// 结合BaseType和声明子组成重组类型
				llvm::Type* VarType = GenerateTypename(this->_TypeSpec,VarEle->_VarDeclarator->_Pointers,
										VarEle->_VarDeclarator->_ArrayDimensions,__Ctx);
				// 判断当前声明或定义是否在某个函数内部，与全局变量区分开
				if (__Ctx.getCurrentFunction()) {
					// 在函数内部

					// 数组比较特殊，体现在初始化列表上
					// 如：int a[] = {1,2,3};刚开始类型分配时大小为0,需根据初始化列表进行修改
					if (VarType->isArrayTy() && !VarType->getArrayElementType()->isArrayTy() 
						&& VarEle->_Initializer && VarEle->_Initializer->_InitializerList
						&& VarType->getArrayNumElements() == 0) {
							VarType = llvm::ArrayType::get(VarType->getArrayElementType(),VarEle->_Initializer->_InitializerList->size());
					}

					// 给变量在函数stack中分配临时空间
					auto Alloc = CreateEntryBlockAlloca(__Ctx.getCurrentFunction(), VarEle->_VarDeclarator->_VarName, VarType);
					
					// 将变量添加到当前符号表中并作判断是否有重名变量或常量
					if (!__Ctx.addVariable(VarEle->_VarDeclarator->_VarName, Alloc) || __Ctx.getCurConstant(VarEle->_VarDeclarator->_VarName)) {
						throw std::logic_error("Redefining or redeclaring local variable '" + VarEle->_VarDeclarator->_VarName + "'.");
						Alloc->eraseFromParent();
						return NULL;
					}

					// 常量的添加
					if (this->_TypeSpec->_isConst) {
						if (!__Ctx.addConstantVar(VarEle->_VarDeclarator->_VarName, Alloc)) {
							throw std::logic_error("Redefining const variable '" + VarEle->_VarDeclarator->_VarName + "'.");
							return NULL;
						}
					}

					// 初始化变量，即变量定义
					if (VarEle->_Initializer) {
						if (VarEle->_Initializer->_InitialExpr) {
							// 单值初始化
							llvm::Value* InitVal = TypeCasting(VarEle->_Initializer->_InitialExpr->IRGen(__Ctx), VarType);
							if (!InitVal) {
								// 初始化值无法转化成声明的类型
								throw std::logic_error("Initializing variable '" + VarEle->_VarDeclarator->_VarName + "' has a value of different type.");
								return NULL;
							}
							
							// 完成存储指令store
							IRBuilder.CreateStore(InitVal, Alloc);
						} else if (VarEle->_Initializer->_InitializerList) {
							// 初始化列表，暂时只实现一维数组的初始化
							if (VarType->isArrayTy() && !VarType->getArrayElementType()->isArrayTy()) {
								// 数组下标
								uint64_t index = 0;
								for (auto ArrayVal : *(VarEle->_Initializer->_InitializerList)) {
									llvm::Value* InitVal = TypeCasting(ArrayVal->_Initializer->_InitialExpr->IRGen(__Ctx), VarType->getArrayElementType());
									if (!InitVal) {
										// 初始化值无法转化成数组的基类型
										throw std::logic_error("Initializing variable '" + VarEle->_VarDeclarator->_VarName + "' has a member value of different type.");
										return NULL;
									}
									// 将index转成llvm::Value*类型，方便创建数组类型
									llvm::Value* valueInt = Uint2LLVMVal(index);
									// 获取第index个元素的指针
									llvm::Value *elementPtr = CreateAdd(CreateLoad(Alloc,__Ctx), valueInt, __Ctx);
									// 完成存储指令store
									IRBuilder.CreateStore(InitVal, elementPtr);
									index++;
								}
								while (index < VarType->getArrayNumElements()){
									// 给其余所有元素赋值为0
									llvm::Value* valueInt = Uint2LLVMVal(index);
									llvm::Value* ZeroVal = Uint2LLVMVal(0);
									// 获取第index个元素的指针
									llvm::Value *elementPtr = CreateAdd(CreateLoad(Alloc,__Ctx), valueInt, __Ctx);
									IRBuilder.CreateStore(ZeroVal, elementPtr);
									index++;
								}
							} else {
								throw std::logic_error("Initializerlist only used to one-dimension array type.");
								return NULL;
							}
						}
					}
				} else {
					// 在函数外，需要进行全局变量的构建

					// 创建常量初始化器，用于表示全局变量的初始值
					llvm::Constant* Initializer = NULL;
					if (VarEle->_Initializer) {
						// 切换到临时基本块，用于常量的判断
						llvm::Function* TmpFunc = llvm::Function::Create(llvm::FunctionType::get(IRBuilder.getVoidTy(), false), llvm::GlobalValue::InternalLinkage, "0Tmp", __Ctx.module);
						llvm::BasicBlock* TmpBB = llvm::BasicBlock::Create(Context, "Temp", TmpFunc);
						auto Tmp = IRBuilder.GetInsertBlock();
						IRBuilder.SetInsertPoint(TmpBB);
						TmpBB = Tmp;

						// 临时基本块大小存储
						auto TmpBBSize = IRBuilder.GetInsertBlock()->size();

						// 初始值的类型转换
						llvm::Value* InitialVal = TypeCasting(VarEle->_Initializer->_InitialExpr->IRGen(__Ctx), VarType);
						
						// 首先判断是否为常数表达式，通过块大小来判断（由于前面有IRGen）
						if (IRBuilder.GetInsertBlock()->size() != TmpBBSize) {
							throw std::logic_error("Initializing global variable '" + VarEle->_VarDeclarator->_VarName + "' can't be non-constant value.");
							return NULL;
						}

						// 类型有误，无法实现强制类型转换
						if (InitialVal == NULL) {
							throw std::logic_error("Initializing variable '" + VarEle->_VarDeclarator->_VarName + "' has a value of different type.");
							return NULL;
						}

						// 切换回原来的全局基本块
						Tmp = IRBuilder.GetInsertBlock();
						IRBuilder.SetInsertPoint(TmpBB);
						Tmp->eraseFromParent();
						TmpFunc->eraseFromParent();

						Initializer = (llvm::Constant*)InitialVal;
					} else {
						// 未定义的值表示一个没有指定初始值的变量或全局变量
						Initializer = llvm::UndefValue::get(VarType);
					}
					
					// 创建全局变量，llvm有相应的接口，因而和函数内变量区分开
					auto Alloc = new llvm::GlobalVariable(*(__Ctx.module),VarType,this->_TypeSpec->_isConst,llvm::Function::ExternalLinkage,Initializer,VarEle->_VarDeclarator->_VarName);

					// 判断全局变量是否重复定义
					if (!__Ctx.addVariable(VarEle->_VarDeclarator->_VarName, Alloc) || __Ctx.getCurConstant(VarEle->_VarDeclarator->_VarName)) {
						throw std::logic_error("Redefining global variable '" + VarEle->_VarDeclarator->_VarName + "'.");
						Alloc->eraseFromParent();
						return NULL;
					}
					if (this->_TypeSpec->_isConst) {
						if (!__Ctx.addConstantVar(VarEle->_VarDeclarator->_VarName, Alloc)) {
							throw std::logic_error("Redefining global variable '" + VarEle->_VarDeclarator->_VarName + "'.");
							return NULL;
						}
					}
				}
			}
		}
		return NULL;
	}

	// typedef
	llvm::Value* TypeDef::IRGen(SemanticCtx& __Ctx){
		// 将新的类型别名加入到当前符号表
		llvm::Type* LLVMType;
		// struct和union比较特殊，先处理
		if (this->_TypeSpec->isStructType()) {
			LLVMType = ((StructType*)this->_TypeSpec)->GenerateLLVMTypeHead(__Ctx, this->_VarDeclarator->_VarName);
			if (this->_VarDeclarator->_Pointers || this->_VarDeclarator->_ArrayDimensions) {
				// 针对数组和指针
				LLVMType = GenerateTypename(this->_TypeSpec,this->_VarDeclarator->_Pointers,this->_VarDeclarator->_ArrayDimensions,__Ctx);
			}
		} else if (this->_TypeSpec->isUnionType()) {
			LLVMType = ((UnionType*)this->_TypeSpec)->GenerateLLVMTypeHead(__Ctx, this->_VarDeclarator->_VarName);
			if (this->_VarDeclarator->_Pointers || this->_VarDeclarator->_ArrayDimensions) {
				// 针对数组和指针
				LLVMType = GenerateTypename(this->_TypeSpec,this->_VarDeclarator->_Pointers,this->_VarDeclarator->_ArrayDimensions,__Ctx);
			}
		} else {
			// 根据BaseType和声明子组装类型
			LLVMType = GenerateTypename(this->_TypeSpec,this->_VarDeclarator->_Pointers,this->_VarDeclarator->_ArrayDimensions,__Ctx);
		}

		if (!LLVMType) {
			// 类型违法
			throw std::logic_error("Typedef " + this->_VarDeclarator->_VarName + " using undefined types.");
			return NULL;
		}
		if (!__Ctx.addType(this->_VarDeclarator->_VarName, LLVMType)) {
			// 类型名重复
			throw std::logic_error("Redefinition of typename " + this->_VarDeclarator->_VarName);
			return NULL;
		}
		// struct和union另行处理,生成结构体
		if (this->_TypeSpec->isStructType()) {
			((StructType*)this->_TypeSpec)->GenerateLLVMTypeBody(__Ctx);
		} else if (this->_TypeSpec->isUnionType()) {
			((UnionType*)this->_TypeSpec)->GenerateLLVMTypeBody(__Ctx);
		}
		return NULL;
	}

	// 基本类型
	llvm::Type* BuiltInType::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		if (this->_Type == VOID) {
			this->_LLVMType = IRBuilder.getVoidTy();
		} else if (this->_Type == BOOL) {
			this->_LLVMType = IRBuilder.getInt1Ty();
		} else if (this->_Type == CHAR) {
			this->_LLVMType = IRBuilder.getInt8Ty();
		} else if (this->_Type == SHORT) {
			this->_LLVMType = IRBuilder.getInt16Ty();
		} else if (this->_Type == INT) {
			this->_LLVMType = IRBuilder.getInt32Ty();
		} else if (this->_Type == LONG) {
			this->_LLVMType = IRBuilder.getInt64Ty();
		} else if (this->_Type == FLOAT) {
			this->_LLVMType = IRBuilder.getFloatTy();
		} else if (this->_Type == DOUBLE){
			this->_LLVMType = IRBuilder.getDoubleTy();
		} else {
			this->_LLVMType = NULL;
		}
		return this->_LLVMType;
	}

	// struct type
	llvm::Type* StructType::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		if(this->_StructName == ""){ 
			// 无结构体名
			this->GenerateLLVMTypeHead(__Ctx);
		}else{
			// 有结构体名
			this->GenerateLLVMTypeHead(__Ctx,this->_StructName);
		}
		return this->GenerateLLVMTypeBody(__Ctx);
	}
	llvm::Type* StructType::GenerateLLVMTypeHead(SemanticCtx& __Ctx, const std::string& __Name){
		if (this->_StructBody) {
			// 无结构体
			auto LLVMType = llvm::StructType::create(Context, "struct." + __Name);
			// 加入到结构表中
			if (!__Ctx.addStructType(LLVMType, this)) {
				throw std::logic_error("Redefining struct name " + this->_StructName + " .");
				return NULL;
			}
			return this->_LLVMType = LLVMType;
		} else {
			// struct body如果为空则必有struct name
			// 找之前有没有定义过该结构体，有则返回类型，没有报错
			// 通过名字搜索
			llvm::StructType* myStructType = llvm::StructType::getTypeByName(Context, "struct." + this->_StructName);
			if (myStructType == nullptr) {
				// 如果返回值为 nullptr，则表示没有找到对应的结构体类型
				throw std::logic_error("Unknown struct name " + this->_StructName + " .");
				return NULL;
			} else {
				return this->_LLVMType = myStructType;
			}
		}
	}
	llvm::Type* StructType::GenerateLLVMTypeBody(SemanticCtx& __Ctx){
		// 结构体的映射关系建立
		if (this->_StructBody) {
			// 结构成员类型数组
			std::vector<llvm::Type*> Members;
			// 用于检查结构体中是否有重名变量
			std::unordered_set<std::string> MemberNames;
			for (auto FDecl : *(this->_StructBody)) {
				for (auto MDecl: *(FDecl->_MemberDeclaratorList)) {
					if (MemberNames.find(MDecl->_VarName) != MemberNames.end()) {
						// 有重名成员变量
						throw std::logic_error("duplicate member '" + MDecl->_VarName +"'");
						return NULL;
					}
					// 根据basetype和声明子组合类型
					llvm::Type* VarType = GenerateTypename(FDecl->_MemTypeSpec,MDecl->_Pointers,MDecl->_ArrayDimensions,__Ctx);
					// 成员类型不能是void
					if (VarType->isVoidTy()) {
						throw std::logic_error("The member type of struct cannot be void.");
						return NULL;
					} else {
						Members.insert(Members.end(), 1 , VarType);
						MemberNames.insert(MDecl->_VarName);
					}
				}
			}
			// 调用llvm接口完成结构体的存储
			((llvm::StructType*)this->_LLVMType)->setBody(Members);
			return this->_LLVMType;
		} else {
			// struct body如果为空则必有struct name
			// 找之前有没有定义过该结构体，有则返回类型，没有报错
			// 通过名字搜索
			llvm::StructType* myStructType = llvm::StructType::getTypeByName(Context, "struct." + this->_StructName);
			if (myStructType == nullptr) {
				// 如果返回值为nullptr，则表示没有找到对应的结构体类型
				throw std::logic_error("Unknown struct name " + this->_StructName + ".");
				return NULL;
			} else {
				return this->_LLVMType = myStructType;
			}
		}
	}
    // 结构体成员变量索引，返回下标，没有返回-1
	size_t StructType::GetElementIndex(const std::string& __MemName){
		size_t Index = 0;
		if (this->_StructBody) {
			for (auto FDecl : *(this->_StructBody)) {
				for (auto& MemName : *(FDecl->_MemberDeclaratorList)) {
					if (MemName->_VarName == __MemName) {
						return Index;
					} else {
						Index++;
					}
				}
			}
		}
		return -1;
	}

	// union type
	llvm::Type* UnionType::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		if(this->_UnionName == ""){ 
			// 无union体
			this->GenerateLLVMTypeHead(__Ctx);
		}else{
			this->GenerateLLVMTypeHead(__Ctx,this->_UnionName);
		}
		return this->GenerateLLVMTypeBody(__Ctx);
	}
    llvm::Type* UnionType::GenerateLLVMTypeHead(SemanticCtx& __Ctx, const std::string& __Name){
		if (this->_UnionBody) {
			auto LLVMType = llvm::StructType::create(Context, "union." + __Name);
			// 加入到联合表中
			if (!__Ctx.addUnionType(LLVMType, this)) {
				throw std::logic_error("Redefining union name " + this->_UnionName + " .");
				return NULL;
			}
			return this->_LLVMType = LLVMType;
		} else {
			// union body如果为空则必有union name
			// 找之前有没有定义过该联合体，有则返回类型，没有报错
			// 通过名字搜索
			llvm::StructType* myUnionType = llvm::StructType::getTypeByName(Context, "union." + this->_UnionName);
			if (myUnionType == nullptr) {
				// 如果返回值为nullptr，则表示没有找到对应的union类型
				throw std::logic_error("Unknown union name " + this->_UnionName + ".");
				return NULL;
			} else {
				return this->_LLVMType = myUnionType;
			}
		}
	}
    llvm::Type* UnionType::GenerateLLVMTypeBody(SemanticCtx& __Ctx){
		if(this->_UnionBody) {
			// 找到成员变量中最大的类型
			size_t MaxSize = 0;
			llvm::Type* MaxSizeType = NULL;
			// 用于检查union中是否有重名变量
			std::unordered_set<std::string> MemberNames;
			for (auto FDecl : *(this->_UnionBody)) {
				for (auto MDecl: *(FDecl->_MemberDeclaratorList)) {
					if (MemberNames.find(MDecl->_VarName) != MemberNames.end()) {
						// 有重名成员变量
						throw std::logic_error("duplicate member '" + MDecl->_VarName +"'");
						return NULL;
					}
					llvm::Type* VarType = GenerateTypename(FDecl->_MemTypeSpec,MDecl->_Pointers,MDecl->_ArrayDimensions,__Ctx);
					// 成员类型不能是void
					if (VarType->isVoidTy()) {
						throw std::logic_error("The member type of union cannot be void.");
						return NULL;
					} else if (__Ctx.getTypeSize(VarType) > MaxSize) {
						MaxSizeType = VarType;
						MaxSize = __Ctx.getTypeSize(MaxSizeType);
					}
				}
			}
			((llvm::StructType*)this->_LLVMType)->setBody(std::vector<llvm::Type*>{MaxSizeType});
			return this->_LLVMType;
		} else {
			// union body如果为空则必有union name
			// 找之前有没有定义过该union，有则返回类型，没有报错
			// 通过名字搜索
			llvm::StructType* myUnionType = llvm::StructType::getTypeByName(Context, "union." + this->_UnionName);
			if (myUnionType == nullptr) {
				// 如果返回值为nullptr，则表示没有找到对应的union类型
				throw std::logic_error("Unknown union name " + this->_UnionName + ".");
				return NULL;
			} else {
				return this->_LLVMType = myUnionType;
			}
		}
	}
    // 联合体的成员的类型索引，返回该成员所对应的类型
	llvm::Type* UnionType::GetElementType(const std::string& __MemName, SemanticCtx& __Ctx){
		if (this->_UnionBody) {
			for (auto FDecl : *(this->_UnionBody)) {
				for (auto& MemName : *(FDecl->_MemberDeclaratorList)) {
					if (MemName->_VarName == __MemName) {
						llvm::Type* VarType = GenerateTypename(FDecl->_MemTypeSpec,MemName->_Pointers,MemName->_ArrayDimensions,__Ctx);
						return VarType;
					}
				}
			}
		}
		return NULL;
	}

	// enum type枚举类型
	// 将enum a作为int的别名，类似于typedef，里面成员作为常量，且能相互覆盖，c11也是这样实现的
	llvm::Type* EnumType::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		if (this->_EnumeratorList) {
			int Last = -1;
			if (this->_EnumName != "") {
				// enum name不为空串时需要在符号表中注册该类型名，作为int32的别名
				llvm::Type* LLVMType = llvm::IntegerType::getInt32Ty(Context);
				if (!__Ctx.addType("enum." + this->_EnumName, LLVMType)) {
					// 重复类型声明
					throw std::logic_error("Redeclaration of enum " + this->_EnumName);
					return NULL;
				}
			}
			for (auto Mem : *(this->_EnumeratorList)) {
				if (Mem->_Value) {
					// 计算值并返回
					llvm::Value* number = Mem->_Value->IRGen(__Ctx);
					if (number->getType()->isIntegerTy()){
						// 转成uint类型
						uint64_t intValue = LLVMVal2Uint(number);
						Last = intValue;
						Mem->_IntValue = intValue;
					} else {
						// 非整型赋值
						throw std::logic_error("Enumerator value for" + Mem->_Name + "is not an integer constant");
						return NULL;
					}
				} else {
					Mem->_IntValue = ++Last;
				}
			}
			// 加常量到符号表
			for (auto Mem : *(this->_EnumeratorList)) {
				if (__Ctx.getCurVar(Mem->_Name) || !__Ctx.addConstant(Mem->_Name, IRBuilder.getInt32(Mem->_IntValue))) {
					throw std::logic_error("'" + Mem->_Name + "' redeclared as different kind of symbol");
					return NULL;
				}
			}
			// 枚举类型实际上是int32类型
			return this->_LLVMType = llvm::IntegerType::getInt32Ty(Context);
		} else{
			// 变量声明，需要看看前面有没有定义过
			// enumlist为空，enumname必有值
			if (__Ctx.getType("enum." + this->_EnumName)) {
				return this->_LLVMType = llvm::IntegerType::getInt32Ty(Context);
			} else {
				throw std::logic_error("Unknown enum type name '" + this->_EnumName + "'.");
				return NULL;
			}
		}
	}

	// IDENTIFIER a; IDENTIFIER一定是之前typedef过的类型名
	llvm::Type* DefinedType::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		// 查看该类型是否已经定义过，没有定义过要报错
		this->_LLVMType = __Ctx.getType(this->_Name);
		if (this->_LLVMType == NULL) {
			throw std::logic_error("\"" + this->_Name + "\" is an undefined type.");
			return NULL;
		}else{
			return this->_LLVMType;
		}
	}

	// 类型说明符+其指针、数组形式
	llvm::Type* TypeName::GetLLVMType(SemanticCtx& __Ctx){
		if (this->_LLVMType) {
			return this->_LLVMType;
		}
		if (this->_AbstractDeclarator){
			// 有抽象声明子的情况
			if(this->_AbstractDeclarator->_ArrayDimensions) {
				// 多维数组，至少是一维的
				llvm::Type* BaseType = this->_TypeSpec->GetLLVMType(__Ctx);

				// 指针的数组判断
				if(this->_AbstractDeclarator->_Pointers) {
					// 至少是一维指针
					BaseType = llvm::PointerType::get(BaseType, 0U);
					if (this->_AbstractDeclarator->_Pointers->size() > 1) {
						for (auto Decl : *(this->_AbstractDeclarator->_Pointers+1)){
							BaseType = llvm::PointerType::get(BaseType, 0U);
						}
					}
				}

				// 基类不能是void
				if (BaseType->isVoidTy()) {
					throw std::logic_error("The base type of array can't be void.");
					return NULL;
				}
				// 处理多维数组
				for (auto iter = this->_AbstractDeclarator->_ArrayDimensions->rbegin(); iter != this->_AbstractDeclarator->_ArrayDimensions->rend(); ++iter){
					// 生成多维数组时迭代的顺序是从右往左，与subscript操作刚好相反
					auto Decl = *iter;
					llvm::Value* length;
					// 数组的长度值
					uint64_t intValue;
					if (Decl) {
						length = Decl->IRGen(__Ctx);
						if (length->getType()->isIntegerTy()){
							llvm::ConstantInt* constInt = llvm::dyn_cast<llvm::ConstantInt>(length);
							if (!constInt) {
								// 非常量
								uint32_t bitwidth = length->getType()->getIntegerBitWidth();
								llvm::APInt apInt(bitwidth,0);
								constInt = llvm::cast<llvm::ConstantInt>(llvm::ConstantInt::get(length->getContext(),apInt));
							}
							intValue = constInt->getSExtValue();
						} else {
							throw std::logic_error("Size of array has non-integer type");
							return NULL;
						}
					} else {
						intValue = 0;
					}
					BaseType = llvm::ArrayType::get(BaseType, intValue);
				}
				return this->_LLVMType = BaseType;
			} else if(this->_AbstractDeclarator->_Pointers){
				// 多维指针
				llvm::Type* BaseType = this->_TypeSpec->GetLLVMType(__Ctx);
				// 至少是一维指针
				this->_LLVMType = llvm::PointerType::get(BaseType, 0U);
				if (this->_AbstractDeclarator->_Pointers->size() > 1) {
					for (auto Decl : *(this->_AbstractDeclarator->_Pointers+1)){
						// 指针迭代的过程
						this->_LLVMType = llvm::PointerType::get(this->_LLVMType, 0U);
					}
				}
				return this->_LLVMType;
			}
		}
		// 无抽象声明子的情况：直接将typespec的LLVMType返回即可
		return this->_LLVMType = this->_TypeSpec->GetLLVMType(__Ctx);
	}

	// 逗号表达式，既可以作左值也可以作右值
	llvm::Value* CommaExpr::IRGen(SemanticCtx& __Ctx){
		this->_LHS->IRGen(__Ctx);
		return this->_RHS->IRGen(__Ctx);
	}
	llvm::Value* CommaExpr::IRGenPtr(SemanticCtx& __Ctx){
		this->_LHS->IRGen(__Ctx);
		return this->_RHS->IRGenPtr(__Ctx);
	}

	// 变量Variable，既可以作左值也可以作右值
	llvm::Value* Variable::IRGen(SemanticCtx& __Ctx){
		// 既可能是变量也可能是常量，均合法
		std::pair <llvm::Value*, int> pair_var = __Ctx.getVar(this->_Name);
		if (pair_var.second == 3) {
			// 常量值
			return pair_var.first;
		}
		if (pair_var.second == 2 || pair_var.second == 1) {
			// 变量或常变量
			return CreateLoad(pair_var.first, __Ctx);
		}else{ // 0
			// 未定义
			throw std::logic_error("Identifier \"" + this->_Name + "\" is undeclared in this function.");
			return NULL;
		}
	}
	llvm::Value* Variable::IRGenPtr(SemanticCtx& __Ctx){
		// 注意：常量或常变量不能作为left-value
		std::pair <llvm::Value*, int> pair_var = __Ctx.getVar(this->_Name);
		if (pair_var.second == 3 || pair_var.second == 1) {
			// 常量值
			throw std::logic_error("\"" + this->_Name + "\" is a constant variable, not a left-value.");
			return NULL;
		}
		if (pair_var.second == 2) {
			// 变量
			return pair_var.first;
		} else {
			// 未定义
			throw std::logic_error("Identifier \"" + this->_Name + "\" is neither a variable nor a constant.");
			return NULL;
		}
	}

	// 常量constant,只能作右值，不能作左值
	llvm::Value* Constant::IRGen(SemanticCtx& __Ctx){
		switch (this->_Type) {
			case BuiltInType::TypeID::BOOL:
				return IRBuilder.getInt1(this->_Bool);
			case BuiltInType::TypeID::CHAR:
				return IRBuilder.getInt8(this->_Character);
			case BuiltInType::TypeID::INT:
				return IRBuilder.getInt32(this->_Integer);
			case BuiltInType::TypeID::DOUBLE:
				return llvm::ConstantFP::get(IRBuilder.getDoubleTy(), this->_Real);
			default:
				return NULL;
		}
	}
	llvm::Value* Constant::IRGenPtr(SemanticCtx& __Ctx){
		// 直接报错
		throw std::logic_error("Constant can't be left-value.");
		return NULL;
	}

	// string字面量,只能作右值，不能作左值
	llvm::Value* StringLiteral::IRGen(SemanticCtx& __Ctx){
		llvm::Value* StrContent = IRBuilder.CreateGlobalStringPtr(this->_Content.c_str());
		return StrContent;
	}
	llvm::Value* StringLiteral::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("String literal can't be left-value.");
		return NULL;
	}

	// 数组下标,[]可以作用在数组上，也可以作用在指针上
	llvm::Value* Subscript::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* Subscript::IRGenPtr(SemanticCtx& __Ctx){
		// 获取数组指针，里面函数已经load过一次，去除了一层指针
		llvm::Value* ArrayPtr = this->_Array->IRGen(__Ctx);
		if (!ArrayPtr->getType()->isPointerTy()) {
			throw std::logic_error("Operator \"[]\" must be applied to pointer or array.");
			return NULL;
		}
		// 获取下标值
		int ArrIndex = 0;
		for (auto Index: *(this->_Index)) {
			// 多维数组根据下标值一层层剖开
			llvm::Value* Subspt = Index->IRGen(__Ctx);
			if (!(Subspt->getType()->isIntegerTy())) {
				throw std::logic_error("Array index should be an integer.");
				return NULL;
			}
			ArrayPtr = CreateAdd(ArrayPtr, Subspt, __Ctx);
			if (ArrIndex < this->_Index->size() - 1) {
				ArrayPtr = CreateLoad(ArrayPtr, __Ctx);
			}
			ArrIndex++;
		}
		return ArrayPtr;
	}

	// 函数调用，只能作右值
	llvm::Value* FuncCall::IRGen(SemanticCtx& __Ctx){
		// 获取函数，如果函数不存在需要抛出异常
		llvm::Function* Func = __Ctx.getFunction(this->_Function);
		if (!Func) {
			throw std::domain_error(this->_Function + " is not a defined function.");
			return NULL;
		}

		// 检查参数个数，需考虑可变参数
		if (Func->isVarArg() && this->_ArgExprList->size() < Func->arg_size() ||
			!Func->isVarArg() && this->_ArgExprList->size() != Func->arg_size()) {
			throw std::invalid_argument("Args doesn't match when calling function " + this->_Function + ". Expected " + std::to_string(Func->arg_size()) + ", got " + std::to_string(this->_ArgExprList->size()));
			return NULL;
		}

		// 检查参数类型

		// 参数列表
		std::vector<llvm::Value*> ArgList;
		// 下标，方便访问
		size_t Index = 0;
		for (auto ArgEle = Func->arg_begin(); ArgEle < Func->arg_end(); ArgEle++, Index++) {
			llvm::Value* Arg = this->_ArgExprList->at(Index)->IRGen(__Ctx);
			// 将当前变量类型转成函数参数所需类型
			Arg = TypeCasting(Arg, ArgEle->getType()); 
			if (Arg == NULL) { 
				// 无法自动转换，抛出异常
				throw std::invalid_argument(std::to_string(Index) + "th arg type doesn't match when calling function " + this->_Function + ".");
				return NULL;
			}
			// 检查无误后push到变量表里
			ArgList.push_back(Arg);
		}

		// 有可变参数，我需要继续push参数；按照c标准，bool/char/short需转成int,float需转成double
		if (Func->isVarArg()) {
			for (; Index < this->_ArgExprList->size(); Index++) {
				llvm::Value* Arg = this->_ArgExprList->at(Index)->IRGen(__Ctx);
				// 类型转换
				if (Arg->getType()->isIntegerTy()) {
					Arg = TypeUpgrading(Arg, IRBuilder.getInt32Ty());
				}else if (Arg->getType()->isFloatingPointTy()) {
					Arg = TypeUpgrading(Arg, IRBuilder.getDoubleTy());
				}
				ArgList.push_back(Arg);
			}
		}
		// 调用函数，并生成代码
		return IRBuilder.CreateCall(Func, ArgList);
	}
	llvm::Value* FuncCall::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Function call can't be left-value.");
		return NULL;
	}

	// 结构的成员变量获取(.mem)
	llvm::Value* StructReference::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* StructReference::IRGenPtr(SemanticCtx& __Ctx){
		// 先从结构体映射表中找到对应的ast::StructType*,然后查询元素名对应的下标序号.最后调用IRBuilder.CreateGEP接口.
		// 获取结构体类型指针，必须是pointer且为struct
		llvm::Value* StructPtr = this->_Struct->IRGenPtr(__Ctx);
		if (!StructPtr->getType()->isPointerTy() || !StructPtr->getType()->getNonOpaquePointerElementType()->isStructTy()) {
			throw std::logic_error("Reference operator \".\" must be apply to structs or unions.");
			return NULL;
		}
		// 找结构体实例
		ast::StructType* StructType = __Ctx.getStructType((llvm::StructType*)StructPtr->getType()->getNonOpaquePointerElementType());
		ast::UnionType* UnionType = __Ctx.getUnionType((llvm::StructType*)StructPtr->getType()->getNonOpaquePointerElementType());
		if (StructType) {
			// 获取index
			int MemIndex = StructType->GetElementIndex(this->_MemName);
			if (MemIndex == -1) {
				throw std::logic_error("The struct doesn't have a member whose name is \"" + this->_MemName + "\".");
				return NULL;
			}
			std::vector<llvm::Value*> Indices; 
			// 由于结构体我们定义的是指针类型，因而实际上该结构体是两个维度，第一个下标索引必为0，第二个才是索引结构里面的成员
			Indices.push_back(IRBuilder.getInt32(0));
			Indices.push_back(IRBuilder.getInt32(MemIndex));
			return IRBuilder.CreateGEP(StructPtr->getType()->getNonOpaquePointerElementType(), StructPtr, Indices);
		} else if (UnionType) {
			// 获取某个成员变量的类型
			llvm::Type* MemType = UnionType->GetElementType(this->_MemName, __Ctx);
			if (MemType == NULL) {
				throw std::logic_error("The union doesn't have a member whose name is \"" + this->_MemName + "\".");
				return NULL;
			}
			// 做强制类型转换（指针）
			return IRBuilder.CreatePointerCast(StructPtr, MemType->getPointerTo());
		} else {
			throw std::logic_error("Unknown name " + StructPtr->getName().str());
			return NULL;
		}
	}

	// 结构的成员变量获取(->mem)，类似于上面
	llvm::Value* StructDereference::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* StructDereference::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* StructPtr = this->_StructPtr->IRGen(__Ctx);
		if (!StructPtr->getType()->isPointerTy() || !StructPtr->getType()->getNonOpaquePointerElementType()->isStructTy()) {
			throw std::logic_error("Dereference operator \"->\" must be apply to struct or union pointers.");
			return NULL;
		}
		ast::StructType* StructType = __Ctx.getStructType((llvm::StructType*)StructPtr->getType()->getNonOpaquePointerElementType());
		ast::UnionType* UnionType = __Ctx.getUnionType((llvm::StructType*)StructPtr->getType()->getNonOpaquePointerElementType());
		// 找结构体实例
		if (StructType) {
			int MemIndex = StructType->GetElementIndex(this->_MemName);
			if (MemIndex == -1) {
				throw std::logic_error("The struct doesn't have a member whose name is \"" + this->_MemName + "\".");
				return NULL;
			}
			std::vector<llvm::Value*> Indices;
			Indices.push_back(IRBuilder.getInt32(0));
			Indices.push_back(IRBuilder.getInt32(MemIndex));
			return IRBuilder.CreateGEP(StructPtr->getType()->getNonOpaquePointerElementType(), StructPtr, Indices);
		} else if (UnionType) {
			llvm::Type* MemType = UnionType->GetElementType(this->_MemName, __Ctx);
			if (MemType == NULL) {
				throw std::logic_error("The union doesn't have a member whose name is \"" + this->_MemName + "\".");
				return NULL;
			}
			return IRBuilder.CreatePointerCast(StructPtr, MemType->getPointerTo());
		} else {
			throw std::logic_error("Unknown name " + StructPtr->getName().str());
			return NULL;
		}
	}

	// a++,只能作right-value
	llvm::Value* PostfixInc::IRGen(SemanticCtx& __Ctx){
		// 后缀++的参数必须是可修改的左值，因此要递归调用IRGenPtr左值的代码生成
		llvm::Value* Operand = this->_Operand->IRGenPtr(__Ctx);
		if (!Operand) {
			throw std::logic_error("Postfix increment operand must be left-value.");
		}
		// load指令，load a的原始值
		llvm::Value* OpVal = IRBuilder.CreateLoad(Operand->getType()->getNonOpaquePointerElementType(), Operand);
		if (!(OpVal->getType()->isIntegerTy() || OpVal->getType()->isFloatingPointTy() || OpVal->getType()->isPointerTy())) {
			throw std::logic_error("Postfix increment must be applied to integers, floating-point numbers or pointers.");
		}
		// 创建加法指令
		llvm::Value* RetPlus = CreateAdd(OpVal, IRBuilder.getInt1(1), __Ctx);
		// store指令，把加一后的结果存回
		IRBuilder.CreateStore(RetPlus, Operand);
		return OpVal;
	}
	llvm::Value* PostfixInc::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Postfix increment can't be left-value.");
		return NULL;
	}

	// a--,只能作right-value
	llvm::Value* PostfixDec::IRGen(SemanticCtx& __Ctx){
		// 后缀--的参数必须是可修改的左值，因此要递归调用IRGenPtr
		llvm::Value* Operand = this->_Operand->IRGenPtr(__Ctx);
		if (!Operand) {
			throw std::logic_error("Postfix decrement operand must be left-value.");
		}
		llvm::Value* OpVal = IRBuilder.CreateLoad(Operand->getType()->getNonOpaquePointerElementType(), Operand);
		if (!(OpVal->getType()->isIntegerTy() || OpVal->getType()->isFloatingPointTy() || OpVal->getType()->isPointerTy())) {
			throw std::logic_error("Postfix decrement must be applied to integers, floating-point numbers or pointers.");
		}
		// 创建减法指令
		llvm::Value* RetMinus = CreateSub(OpVal, IRBuilder.getInt1(1), __Ctx);
		// store指令，把减一后的结果存回
		IRBuilder.CreateStore(RetMinus, Operand);
		return OpVal;
	}
	llvm::Value* PostfixDec::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Postfix decrement can't be left-value");
		return NULL;
	}

	// ++a，既可以作左值也可以作右值
	llvm::Value* PrefixInc::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* PrefixInc::IRGenPtr(SemanticCtx& __Ctx){
		// 前缀++返回左值,他们的参数必须是可修改的左值.对参数进行递增后，返回指向参数的指针
		llvm::Value* Operand = this->_Operand->IRGenPtr(__Ctx);
		if (!Operand) {
			throw std::logic_error("Prefix increment operand must be left-value.");
		}
		llvm::Value* OpVal = IRBuilder.CreateLoad(Operand->getType()->getNonOpaquePointerElementType(), Operand);
		if (!(OpVal->getType()->isIntegerTy() || OpVal->getType()->isFloatingPointTy() || OpVal->getType()->isPointerTy())) {
			throw std::logic_error("Prefix increment must be applied to integers, floating-point numbers or pointers.");
		}	
		llvm::Value* RetPlus = CreateAdd(OpVal, IRBuilder.getInt1(1), __Ctx);
		IRBuilder.CreateStore(RetPlus, Operand);
		return Operand;
	}

	// --a，既可以作左值也可以作右值
	llvm::Value* PrefixDec::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* PrefixDec::IRGenPtr(SemanticCtx& __Ctx){
		// 前缀--返回左值,他们的参数必须是可修改的左值.对参数进行递减后，返回指向参数的指针
		llvm::Value* Operand = this->_Operand->IRGenPtr(__Ctx);
		if (!Operand) {
			throw std::logic_error("Prefix decrement operand must be left-value.");
		}
		llvm::Value* OpVal = IRBuilder.CreateLoad(Operand->getType()->getNonOpaquePointerElementType(), Operand);
		if (!(OpVal->getType()->isIntegerTy() || OpVal->getType()->isFloatingPointTy() || OpVal->getType()->isPointerTy())) {
			throw std::logic_error("Prefix decrement must be applied to integers, floating-point numbers or pointers.");
		}
		llvm::Value* RetMinus = CreateSub(OpVal, IRBuilder.getInt1(1), __Ctx);
		IRBuilder.CreateStore(RetMinus, Operand);
		return Operand;
	}

	// sizeof
	llvm::Value* SizeOf::IRGen(SemanticCtx& __Ctx){
		if (this->_Arg2) { 
			// 获取类型大小，如int
			return IRBuilder.getInt64(__Ctx.getTypeSize(this->_Arg2->GetLLVMType(__Ctx)));
		}else {
			// 获取变量大小,如a或a[2][3]等
			return IRBuilder.getInt64(__Ctx.getTypeSize(this->_Arg1->IRGenPtr(__Ctx)->getType()->getNonOpaquePointerElementType()));
		}
	}
	llvm::Value* SizeOf::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Sizeof() can't be left-values.");
		return NULL;
	}

	// &取地址
	llvm::Value* AddressOf::IRGen(SemanticCtx& __Ctx){
		return this->_Operand->IRGenPtr(__Ctx);
	}
	llvm::Value* AddressOf::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("AddressOf \"&\" can't be left-value.");
		return NULL;
	}

	// *取指针里的值，既可left-value，也可right-value
	llvm::Value* Indirection::IRGen(SemanticCtx& __Ctx){
		// 与上面不同，需要load
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* Indirection::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* Ptr = this->_Operand->IRGen(__Ctx);
		// 操作数必须是指针或数组，否则没法取值
		if (!Ptr->getType()->isPointerTy() && !Ptr->getType()->isArrayTy()) {
			throw std::logic_error("Indirection operator \"*\" only used to pointer or array.");
			return NULL;
		}
		return Ptr;
	}

	// +正号，只能是right-alue，如:+a,+12
	llvm::Value* UnaryPlus::IRGen(SemanticCtx& __Ctx){
		llvm::Value* Operand = this->_Operand->IRGen(__Ctx);
		if (!(Operand->getType()->isIntegerTy() || Operand->getType()->isFloatingPointTy())) {
			throw std::logic_error("Unary plus must be applied to integers or floating-point numbers.");
		}
		return Operand;
	}
	llvm::Value* UnaryPlus::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Unary plus can't be left-value.");
		return NULL;
	}

	// -负号，只能是right-alue，如:-a,-12
	llvm::Value* UnaryMinus::IRGen(SemanticCtx& __Ctx){
		llvm::Value* Operand = this->_Operand->IRGen(__Ctx);
		if (!(Operand->getType()->isIntegerTy() || Operand->getType()->isFloatingPointTy())) {
			throw std::logic_error("Unary minus must be applied to integers or floating-point numbers.");
		}
		// 根据类型调用不同的API
		if (Operand->getType()->isIntegerTy()) {
			return IRBuilder.CreateNeg(Operand);
		} else {
			return IRBuilder.CreateFNeg(Operand);
		}
	}
	llvm::Value* UnaryMinus::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Unary minus can't be left-value.");
		return NULL;
	}

	// ~按位取反，只能是right-alue，如:~a
	llvm::Value* BitwiseNot::IRGen(SemanticCtx& __Ctx){
		llvm::Value* Operand = this->_Operand->IRGen(__Ctx);
		// 类型必须是整数
		if (!Operand->getType()->isIntegerTy()) {
			throw std::logic_error("Bitwise NOT operator \"~\" must be applied to integers.");
			return NULL;
		}
		return IRBuilder.CreateNot(Operand);
	}
	llvm::Value* BitwiseNot::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Bitwise NOT operator \"~\" can't be left-value.");
		return NULL;
	}

	// !逻辑取反，只能是right-alue，如:!a
	llvm::Value* LogicalNot::IRGen(SemanticCtx& __Ctx){
		// 先SemanticCtx，根据结果的逻辑值取反
		return IRBuilder.CreateICmpEQ(Cast2Bool(this->_Operand->IRGen(__Ctx)), IRBuilder.getInt1(false));
	}
	llvm::Value* LogicalNot::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Logic NOT operator \"!\" can't be left-value.");
		return NULL;
	}

	// 强制类型转换，只能是right-alue，如:(float)1,(int)1.0
	llvm::Value* TypeCast::IRGen(SemanticCtx& __Ctx){
		// 类型转换
		llvm::Value* Ret = TypeCasting(this->_Operand->IRGen(__Ctx), this->_Type->GetLLVMType(__Ctx));
		if (Ret == NULL) {
			throw std::logic_error("Type casting is a failure");
			return NULL;
		}
		return Ret;
	}
	llvm::Value* TypeCast::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Type casting can't be left-value.");
		return NULL;
	}

	// Multiplication,只能是right-alue，如:x*y
	llvm::Value* Multiplication::IRGen(SemanticCtx& __Ctx){
		// 分别生成代码
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateMul(LHS, RHS, __Ctx);
	}
	llvm::Value* Multiplication::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Multiplication operator \"*\" can't be left-value.");
		return NULL;
	}

	// Division,如:x/y
	llvm::Value* Division::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateDiv(LHS, RHS, __Ctx);
	}
	llvm::Value* Division::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Division operator \"/\" can't be left-value.");
		return NULL;
	}

	// 取模运算,如:x%y
	llvm::Value* Modulo::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateMod(LHS, RHS, __Ctx);
	}
	llvm::Value* Modulo::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Module operator \"%\" can't be left-value.");
		return NULL;
	}

	// +加,如:x+y
	llvm::Value* Addition::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateAdd(LHS, RHS, __Ctx);
	}
	llvm::Value* Addition::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Addition operator \"+\" can't be left-value.");
		return NULL;
	}

	// -减
	llvm::Value* Subtraction::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateSub(LHS, RHS, __Ctx);
	}
	llvm::Value* Subtraction::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Subtraction operator \"-\" can't be left-value.");
		return NULL;
	}

	// <<
	llvm::Value* LeftShift::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateShl(LHS, RHS, __Ctx);
	}
	llvm::Value* LeftShift::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Left shifting operator \"<<\" can't be left-value.");
		return NULL;
	}

	// >>
	llvm::Value* RightShift::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateShr(LHS, RHS, __Ctx);
	}
	llvm::Value* RightShift::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Right shifting operator \">>\" can't be left-value.");
		return NULL;
	}

	// <
	llvm::Value* LogicalLT::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// LHS和RHS均为整数或浮点
		if (TypeUpgrading(LHS, RHS)) {
			// TypeUpgrading会统一它们的类型，使能够比较
			if (LHS->getType()->isIntegerTy()) //int32
				return IRBuilder.CreateICmpSLT(LHS, RHS);
			else //float or double
				return IRBuilder.CreateFCmpOLT(LHS, RHS);
		}
		// 表达式中含有指针，统一转化为整数比较，与上面不同的是这里是无符号比较，且int64
		if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) { // 均为指针
			return IRBuilder.CreateICmpULT(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) { // RHS为整数
			return IRBuilder.CreateICmpULT(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				TypeUpgrading(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) { // LHS为整数
			return IRBuilder.CreateICmpULT(
				TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else {
			throw std::domain_error("LogicalLT \"<\" using unsupported type comparison.");
		}
	}
	llvm::Value* LogicalLT::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalLT \"<\" can't be left-value.");
		return NULL;
	}

	// >
	llvm::Value* LogicalGT::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// LHS和RHS均为整数或浮点
		if (TypeUpgrading(LHS, RHS)) {
			// TypeUpgrading会统一它们的类型，使能够比较
			if (LHS->getType()->isIntegerTy()) //int32
				return IRBuilder.CreateICmpSGT(LHS, RHS);
			else //float or double
				return IRBuilder.CreateFCmpOGT(LHS, RHS);
		}
		// 表达式中含有指针，统一转化为整数比较，与上面不同的是这里是无符号比较，且int64
		if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) { // 均为指针
			return IRBuilder.CreateICmpUGT(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) { // RHS为整数
			return IRBuilder.CreateICmpUGT(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				TypeUpgrading(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) { // LHS为整数
			return IRBuilder.CreateICmpUGT(
				TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else {
			throw std::domain_error("LogicalGT \">\" using unsupported type comparison.");
		}
	}
	llvm::Value* LogicalGT::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalGT \">\" can't be left-value.");
		return NULL;
	}

	// <=
	llvm::Value* LogicalLE::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// LHS和RHS均为整数或浮点
		if (TypeUpgrading(LHS, RHS)) {
			// TypeUpgrading会统一它们的类型，使能够比较
			if (LHS->getType()->isIntegerTy()) //int32
				return IRBuilder.CreateICmpSLE(LHS, RHS);
			else //float or double
				return IRBuilder.CreateFCmpOLE(LHS, RHS);
		}
		// 表达式中含有指针，统一转化为整数比较，与上面不同的是这里是无符号比较，且int64
		if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) { // 均为指针
			return IRBuilder.CreateICmpULE(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) { // RHS为整数
			return IRBuilder.CreateICmpULE(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				TypeUpgrading(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) { // LHS为整数
			return IRBuilder.CreateICmpULE(
				TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else {
			throw std::domain_error("LogicalLE \"<=\" using unsupported type comparison.");
		}
	}
	llvm::Value* LogicalLE::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalLE \"<=\" can't be left-value.");
		return NULL;
	}

	// >=
	llvm::Value* LogicalGE::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// LHS和RHS均为整数或浮点
		if (TypeUpgrading(LHS, RHS)) {
			// TypeUpgrading会统一它们的类型，使能够比较
			if (LHS->getType()->isIntegerTy()) //int32
				return IRBuilder.CreateICmpSGE(LHS, RHS);
			else //float or double
				return IRBuilder.CreateFCmpOGE(LHS, RHS);
		}
		// 表达式中含有指针，统一转化为整数比较，与上面不同的是这里是无符号比较，且int64
		if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) { // 均为指针
			return IRBuilder.CreateICmpUGE(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) { // RHS为整数
			return IRBuilder.CreateICmpUGE(
				IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
				TypeUpgrading(RHS, IRBuilder.getInt64Ty())
			);
		}else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) { // LHS为整数
			return IRBuilder.CreateICmpUGE(
				TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
				IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
			);
		}else {
			throw std::domain_error("LogicalGE \">=\" using unsupported type comparison.");
		}
	}
	llvm::Value* LogicalGE::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalGE \">=\" can't be left-value.");
		return NULL;
	}

	// ==
	llvm::Value* LogicalEQ::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateCmpEQ(LHS, RHS);
	}
	llvm::Value* LogicalEQ::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalEQ \"==\" can't be left-value.");
		return NULL;
	}

	// !=
	llvm::Value* LogicalNEQ::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateCmpNEQ(LHS, RHS);
	}
	llvm::Value* LogicalNEQ::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("LogicalNEQ \"!=\" can't be left-value.");
		return NULL;
	}

	// &
	llvm::Value* BitwiseAND::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateBitwiseAND(LHS, RHS, __Ctx);
	}
	llvm::Value* BitwiseAND::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Bitwise AND operator \"&\" can't be left-value.");
		return NULL;
	}

	// 异或
	llvm::Value* BitwiseXOR::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateBitwiseXOR(LHS, RHS, __Ctx);
	}
	llvm::Value* BitwiseXOR::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Bitwise XOR operator \"^\" can't be left-value.");
		return NULL;
	}

	// |
	llvm::Value* BitwiseOR::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateBitwiseOR(LHS, RHS, __Ctx);
	}
	llvm::Value* BitwiseOR::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Bitwise OR operator \"|\" can't be left-value.");
		return NULL;
	}

	// &&
	llvm::Value* LogicalAND::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// 需要判断LHS和RHS能否转成bool值
		LHS = Cast2Bool(LHS);
		if (LHS == NULL) {
			throw std::domain_error("LHS of logic AND operator \"&&\" can't be cast to boolean.");
			return NULL;
		}
		RHS = Cast2Bool(RHS);
		if (RHS == NULL) {
			throw std::domain_error("RHS OF logic AND operator \"&&\" can't be cast to boolean.");
			return NULL;
		}
		// 生成IR并返回结果
		return IRBuilder.CreateLogicalAnd(LHS, RHS);
	}
	llvm::Value* LogicalAND::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Logic AND operator \"&&\" can't be left-value.");
		return NULL;
	}

	// ||
	llvm::Value* LogicalOR::IRGen(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGen(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// 需要判断LHS和RHS能否转成bool值
		LHS = Cast2Bool(LHS);
		if (LHS == NULL) {
			throw std::domain_error("LHS of logic AND operator \"&&\" can't be cast to boolean.");
			return NULL;
		}
		RHS = Cast2Bool(RHS);
		if (RHS == NULL) {
			throw std::domain_error("RHS OF logic AND operator \"&&\" can't be cast to boolean.");
			return NULL;
		}
		// 生成IR并返回结果
		return IRBuilder.CreateLogicalOr(LHS, RHS);
	}
	llvm::Value* LogicalOR::IRGenPtr(SemanticCtx& __Ctx){
		throw std::logic_error("Logic OR operator \"||\" can't be left-value.");
		return NULL;
	}

	// ?条件运算.三元运算符?:的运算结果能作为左值，当且仅当其后两个操作数都是左值，且类型一致
	llvm::Value* TernaryCondition::IRGen(SemanticCtx& __Ctx){
		// 先判断条件_Condition的逻辑值
		llvm::Value* Condition = Cast2Bool(this->_Condition->IRGen(__Ctx));
		if (Condition == NULL) {
			throw std::logic_error("The TernaryCondition can't be cast to boolean.");
			return NULL;
		}
		llvm::Value* TrueVal = this->_Then->IRGen(__Ctx);
		llvm::Value* FalseVal = this->_Else->IRGen(__Ctx);
		// c语言的三元运算符作右值时需要做类型提升
		if (TrueVal->getType() == FalseVal->getType() || TypeUpgrading(TrueVal, FalseVal)) {
			return IRBuilder.CreateSelect(Condition, TrueVal, FalseVal);
		}else {
			throw std::domain_error("Thernary operand \" ? : \" using unsupported type.");
			return NULL;
		}
	}
	llvm::Value* TernaryCondition::IRGenPtr(SemanticCtx& __Ctx){
		// 先判断条件_Condition的逻辑值
		llvm::Value* Condition = Cast2Bool(this->_Condition->IRGen(__Ctx));
		if (Condition == NULL) {
			throw std::logic_error("The TernaryCondition can't be cast to boolean.");
			return NULL;
		}
		// 均为左值，三元运算符才能作左值
		llvm::Value* TrueVal = this->_Then->IRGenPtr(__Ctx);
		llvm::Value* FalseVal = this->_Else->IRGenPtr(__Ctx);
		if (!TrueVal || !FalseVal || TrueVal->getType() != FalseVal->getType()) {
			throw std::domain_error("When using thernary expressions \" ? : \" as left-values, the latter two operands must be left-value and the same type.");
			return NULL;
		}
		return IRBuilder.CreateSelect(Condition, TrueVal, FalseVal);
	}

	// =
	llvm::Value* Assignment::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* Assignment::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		return CreateAssignment(LHS, RHS, __Ctx);
	}

	// *=
	llvm::Value* MulAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* MulAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		// 先将LHS load下来，然后和RHS作乘法运算，将运算结果再作赋值，下同
		llvm::Value* Result = CreateMul(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result, __Ctx);
	}

	// /=
	llvm::Value* DivAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* DivAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateDiv(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result, __Ctx);
	}

	// %=
	llvm::Value* ModAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* ModAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateMod(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// +=
	llvm::Value* AddAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* AddAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateAdd(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// -=
	llvm::Value* SubAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* SubAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateSub(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// <<=
	llvm::Value* LSHAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* LSHAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateShl(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// >>=
	llvm::Value* RSHAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* RSHAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateShr(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// &=
	llvm::Value* BitANDAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* BitANDAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateBitwiseAND(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// ^=
	llvm::Value* BitXORAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* BitXORAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateBitwiseXOR(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// |=
	llvm::Value* BitORAssign::IRGen(SemanticCtx& __Ctx){
		return CreateLoad(this->IRGenPtr(__Ctx), __Ctx);
	}
	llvm::Value* BitORAssign::IRGenPtr(SemanticCtx& __Ctx){
		llvm::Value* LHS = this->_LHS->IRGenPtr(__Ctx);
		llvm::Value* RHS = this->_RHS->IRGen(__Ctx);
		llvm::Value* Result = CreateBitwiseOR(IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(),LHS),RHS,__Ctx);
		return CreateAssignment(LHS , Result , __Ctx);
	}

	// compound stmt，包括函数体和复合语句
	llvm::Value* CompoundStmt::IRGen(SemanticCtx& __Ctx){
		// 为该复合块push符号表
		__Ctx.pushSymbolTable();
		// 先判断复合语句块是否为空
		if (this->_BlockItems) {
			for (auto& Stmt : *(this->_BlockItems)) {
				// 除非到达return，否则分析每个stmt,并生成代码
				if (IRBuilder.GetInsertBlock()->getTerminator()) {
					break;
				} else {
					Stmt->IRGen(__Ctx);
				}
			}
		}
		__Ctx.popSymbolTable();
		return NULL;
	}

	// expr stmt，各种表达式
	llvm::Value* ExprStmt::IRGen(SemanticCtx& __Ctx){
		if (this->_Expression) {
			return this->_Expression->IRGen(__Ctx);
		}
		return NULL;
	}

	// if else
	llvm::Value* IfStmt::IRGen(SemanticCtx& __Ctx){
		llvm::Value* Condition = this->_Condition->IRGen(__Ctx);
		// 将条件转成bool型
		Condition = Cast2Bool(Condition);
		if (!Condition) {
			throw std::logic_error("The condition value of if-statement can't be cast to boolean.");
			return NULL;
		}
		// 创建if块、else块和最后的end块
		llvm::Function* CurrentFunc = __Ctx.getCurrentFunction();
		llvm::BasicBlock* IfBB = llvm::BasicBlock::Create(Context, "If");
		llvm::BasicBlock* ElseBB = llvm::BasicBlock::Create(Context, "Else");
		llvm::BasicBlock* EndBB = llvm::BasicBlock::Create(Context, "End");
		// 创建条件分支指令
		IRBuilder.CreateCondBr(Condition, IfBB, ElseBB);
		// 产生关于if块的代码
		CurrentFunc->getBasicBlockList().push_back(IfBB);
		IRBuilder.SetInsertPoint(IfBB);
		if (this->_Then) {
			// 第一个块内容不为空
			__Ctx.pushSymbolTable();
			this->_Then->IRGen(__Ctx);
			__Ctx.popSymbolTable();
		}
		// 执行结束后，跳转到分支语句的结束块
		// 需要注意的是我们得小心break、continue和return，不能无脑跳转到EndBB，这个通过CreateJump()处理，下同
		CreateJump(EndBB);
		// 产生关于else块的代码
		CurrentFunc->getBasicBlockList().push_back(ElseBB);
		IRBuilder.SetInsertPoint(ElseBB);
		if (this->_Else) {
			// 第二个块内容不为空
			__Ctx.pushSymbolTable();
			this->_Else->IRGen(__Ctx);
			__Ctx.popSymbolTable();
		}
		// 执行结束后，跳转到分支语句的结束块
		CreateJump(EndBB);

		// 完成控制流合并
		if (EndBB->hasNPredecessorsOrMore(1)) {
			// 如果end块有前驱基本块，则end块的插入是必要的，否则不必须，即if和else都有break、continue或return
			CurrentFunc->getBasicBlockList().push_back(EndBB);
			IRBuilder.SetInsertPoint(EndBB);
		}
		return NULL;
	}

	// switch
	llvm::Value* SwitchStmt::IRGen(SemanticCtx& __Ctx){
		llvm::Function* CurFunc = __Ctx.getCurrentFunction();
		// 匹配表达式的计算
		llvm::Value* Matcher = this->_Matcher->IRGen(__Ctx);

		// 给每一个case和default创建一个空的基本块
		std::vector<llvm::BasicBlock*> CaseBB;
		int i;
		for (i = 0; i < this->_CaseList->size(); i++) {
			CaseBB.push_back(llvm::BasicBlock::Create(Context, "Case" + std::to_string(i)));
		}
		if (this->_Default) {
			CaseBB.push_back(llvm::BasicBlock::Create(Context, "Case" + std::to_string(i)));
		}

		// 给switch创建额外的结束块作为结束标志
		CaseBB.push_back(llvm::BasicBlock::Create(Context, "SwitchEnd"));

		// 给每个匹配比较也创建基本块，除了第一个，因为那个是入口，没必要创建基本块
		std::vector<llvm::BasicBlock*> CompBB;
		CompBB.push_back(IRBuilder.GetInsertBlock());
		for (i = 1; i < this->_CaseList->size(); i++) {
			CompBB.push_back(llvm::BasicBlock::Create(Context, "Comparison" + std::to_string(i)));
		}
		if (this->_Default) {
			CompBB.push_back(llvm::BasicBlock::Create(Context, "Comparison" + std::to_string(i)));
		}
		CompBB.push_back(CaseBB.back());
		
		// 产生分支,设置匹配块的跳转IR
		for (i = 0; i < this->_CaseList->size(); i++) {
			if (i == 0 && this->_CaseList->at(0)->_Condition) {
				// 判断是否匹配，匹配则跳到该基本块，不匹配则跳到下一个匹配比较块
				llvm::Value* IsEqual = CreateCmpEQ(Matcher, this->_CaseList->at(i)->_Condition->IRGen(__Ctx));
				IRBuilder.CreateCondBr(IsEqual , CaseBB[0], CompBB[1]);
			}
			if (i != 0) {
				CurFunc->getBasicBlockList().push_back(CompBB[i]);
				IRBuilder.SetInsertPoint(CompBB[i]);
				if (this->_CaseList->at(i)->_Condition) {
					// 判断是否匹配，匹配则跳到该基本块，不匹配则跳到下一个匹配比较块
					llvm::Value* IsEqual = CreateCmpEQ(Matcher, this->_CaseList->at(i)->_Condition->IRGen(__Ctx));
					IRBuilder.CreateCondBr(IsEqual , CaseBB[i], CompBB[i+1]);
				}
			}
		}
		if (this->_Default) {
			CurFunc->getBasicBlockList().push_back(CompBB[i]);
			IRBuilder.SetInsertPoint(CompBB[i]);
			// default：无条件跳转
			IRBuilder.CreateBr(CaseBB[i]);
		}

		// 生成case块里的IR
		__Ctx.pushSymbolTable();
		for (i = 0; i < this->_CaseList->size(); i++) {
			CurFunc->getBasicBlockList().push_back(CaseBB[i]);
			IRBuilder.SetInsertPoint(CaseBB[i]);
			// 应对break，一旦遇到break，则跳转到刚刚设置的结束符，否则一直往下执行
			__Ctx.enterLoop(CaseBB[i+1], CaseBB.back());
			this->_CaseList->at(i)->IRGen(__Ctx);
			__Ctx.leaveLoop();
		}
		if (this->_Default) {
			CurFunc->getBasicBlockList().push_back(CaseBB[i]);
			IRBuilder.SetInsertPoint(CaseBB[i]);
			// 应对break，一旦遇到break，则跳转到刚刚设置的结束符，否则一直往下执行
			__Ctx.enterLoop(CaseBB.back(), CaseBB.back());
			this->_Default->IRGen(__Ctx);
			__Ctx.leaveLoop();
		}
		__Ctx.popSymbolTable();

		// 结束switch块
		if (CaseBB.back()->hasNPredecessorsOrMore(1)) {
			// 同理前面
			CurFunc->getBasicBlockList().push_back(CaseBB.back());
			IRBuilder.SetInsertPoint(CaseBB.back());
		}
		return NULL;
	}

	// case
	llvm::Value* CaseStmt::IRGen(SemanticCtx& __Ctx){
		// 与复合语句块类似
		for (auto& Stmt : *(this->_CaseBody)) {
			// 如果当前块有结束符，如break，则停止执行进行跳转,否则一直继续执行
			if (IRBuilder.GetInsertBlock()->getTerminator()) {
				break;
			}else if (Stmt) {
				Stmt->IRGen(__Ctx);
			}
		}
		// 如果该case没有break，则跳转到下一个case块中
		if (!IRBuilder.GetInsertBlock()->getTerminator()) {
			CreateJump(__Ctx.getContinueBlock());
		}
		return NULL;
	}

	// default
	llvm::Value* DefaultStmt::IRGen(SemanticCtx& __Ctx){
		// 与复合语句块类似
		for (auto& Stmt : *(this->_DefaultBody)) {
			// 如果当前块有结束符，如break，则停止执行进行跳转,否则一直继续执行
			if (IRBuilder.GetInsertBlock()->getTerminator()) {
				break;
			}else if (Stmt) {
				Stmt->IRGen(__Ctx);
			}
		}
		// 如果该default没有break，则跳转到结束块
		if (!IRBuilder.GetInsertBlock()->getTerminator()) {
			CreateJump(__Ctx.getContinueBlock());
		}
		return NULL;
	}

	// while
	llvm::Value* WhileStmt::IRGen(SemanticCtx& __Ctx){
		// 创建三个基本块：条件块、循环体块和结束块
		llvm::Function* CurrentFunc = __Ctx.getCurrentFunction();
		llvm::BasicBlock* WhileCondBB = llvm::BasicBlock::Create(Context, "WhileCondition");
		llvm::BasicBlock* WhileLoopBB = llvm::BasicBlock::Create(Context, "WhileLoop");
		llvm::BasicBlock* WhileEndBB = llvm::BasicBlock::Create(Context, "WhileEnd");

		// 先无条件跳转到while的条件块
		IRBuilder.CreateBr(WhileCondBB);
		CurrentFunc->getBasicBlockList().push_back(WhileCondBB);

		// 插入IR到条件块
		IRBuilder.SetInsertPoint(WhileCondBB);
		llvm::Value* Condition = this->_Condition->IRGen(__Ctx);
		Condition = Cast2Bool(Condition);
		if (!Condition) {
			throw std::logic_error("The condition value of while-statement can't be cast to boolean.");
			return NULL;
		}
		// 根据条件真假值判断如何跳转
		IRBuilder.CreateCondBr(Condition, WhileLoopBB, WhileEndBB);

		// 构建循环体块的IR
		CurrentFunc->getBasicBlockList().push_back(WhileLoopBB);
		IRBuilder.SetInsertPoint(WhileLoopBB);
		if (this->_LoopBody) {
			// 方便break和continue的使用
			__Ctx.enterLoop(WhileCondBB, WhileEndBB);
			__Ctx.pushSymbolTable();
			// 产生循环体的IR
			this->_LoopBody->IRGen(__Ctx);
			__Ctx.popSymbolTable();
			__Ctx.leaveLoop();
		}
		// 无条件到条件块进行判断是否继续循环
		CreateJump(WhileCondBB);

		// 结束块的设置
		CurrentFunc->getBasicBlockList().push_back(WhileEndBB);
		IRBuilder.SetInsertPoint(WhileEndBB);
		return NULL;
	}

	// do while，和while类似，只是关于条件块执行循序的差异
	llvm::Value* DoWhileStmt::IRGen(SemanticCtx& __Ctx){
		// 创建三个基本块：循环体块、条件块和结束块
		llvm::Function* CurrentFunc = __Ctx.getCurrentFunction();
		llvm::BasicBlock* DoLoopBB = llvm::BasicBlock::Create(Context, "DoLoop");
		llvm::BasicBlock* DoCondBB = llvm::BasicBlock::Create(Context, "DoCondition");
		llvm::BasicBlock* DoEndBB = llvm::BasicBlock::Create(Context, "DoEnd");

		// 先无条件跳转到do的循环体块
		IRBuilder.CreateBr(DoLoopBB);
		CurrentFunc->getBasicBlockList().push_back(DoLoopBB);
		// 产生关于循环体的IR
		IRBuilder.SetInsertPoint(DoLoopBB);
		if (this->_LoopBody) {
			// 方便break和continue的使用
			__Ctx.enterLoop(DoCondBB, DoEndBB);
			__Ctx.pushSymbolTable();
			// 产生循环体的IR
			this->_LoopBody->IRGen(__Ctx);
			__Ctx.popSymbolTable();
			__Ctx.leaveLoop();
		}
		// 先无条件跳转到do的条件块
		CreateJump(DoCondBB);

		// 插入IR到条件块
		CurrentFunc->getBasicBlockList().push_back(DoCondBB);
		IRBuilder.SetInsertPoint(DoCondBB);
		llvm::Value* Condition = this->_Condition->IRGen(__Ctx);
		Condition = Cast2Bool(Condition);
		if (!Condition) {
			throw std::logic_error("The condition value of dowhile-statement can't be cast to boolean.");
			return NULL;
		}
		// 根据条件真假值判断如何跳转
		IRBuilder.CreateCondBr(Condition, DoLoopBB, DoEndBB);

		// 结束块
		CurrentFunc->getBasicBlockList().push_back(DoEndBB);
		IRBuilder.SetInsertPoint(DoEndBB);
		return NULL;
	}

	// for，和while类似，只是需要多几个基本块
	llvm::Value* ForStmt::IRGen(SemanticCtx& __Ctx){
		// 创建四个基本块：条件块、循环体块、单层循环的tail块和循环结束块
		// 初始化可以在最前执行无需创建基本块
		llvm::Function* CurrentFunc = __Ctx.getCurrentFunction();
		llvm::BasicBlock* ForCondBB = llvm::BasicBlock::Create(Context, "ForCondition");
		llvm::BasicBlock* ForLoopBB = llvm::BasicBlock::Create(Context, "ForLoop");
		llvm::BasicBlock* ForTailEndBB = llvm::BasicBlock::Create(Context, "ForTailEnd");
		llvm::BasicBlock* ForEndBB = llvm::BasicBlock::Create(Context, "ForEnd");

		if (this->_VarDecl) {
			// 如果在for的初始化中有变量声明或定义，应该push一个新的符号表
			__Ctx.pushSymbolTable();
			this->_VarDecl->IRGen(__Ctx);
		} else if (this->_Initial) {
			// 没有声明，有语句的话直接生成IR即可
			this->_Initial->IRGen(__Ctx);
		}
		// 无条件跳转到条件块
		CreateJump(ForCondBB);

		// 为条件块生成IR
		CurrentFunc->getBasicBlockList().push_back(ForCondBB);
		IRBuilder.SetInsertPoint(ForCondBB);
		if (this->_Condition) {
			// 有条件
			llvm::Value* Condition = this->_Condition->IRGen(__Ctx);
			Condition = Cast2Bool(Condition);
			if (!Condition) {
				throw std::logic_error("The condition of for-statement can't be cast to boolean.");
				return NULL;
			}
			IRBuilder.CreateCondBr(Condition, ForLoopBB, ForEndBB);
		} else {
			// 无条件，直接跳转到循环体
			IRBuilder.CreateBr(ForLoopBB);
		}

		// 为循环体块生成IR
		CurrentFunc->getBasicBlockList().push_back(ForLoopBB);
		IRBuilder.SetInsertPoint(ForLoopBB);

		if (this->_LoopBody) {
			// 方便break和continue的使用
			__Ctx.enterLoop(ForTailEndBB, ForEndBB);
			__Ctx.pushSymbolTable();
			this->_LoopBody->IRGen(__Ctx);
			__Ctx.popSymbolTable();
			__Ctx.leaveLoop();
		}
		
		// 如果没有出现continue和break，则还需要执行tail块
		CreateJump(ForTailEndBB);
		// 生成tail块的IR
		CurrentFunc->getBasicBlockList().push_back(ForTailEndBB);
		IRBuilder.SetInsertPoint(ForTailEndBB);
		if (this->_Tail) {
			this->_Tail->IRGen(__Ctx);
		}
		// 无条件跳转到条件块
		IRBuilder.CreateBr(ForCondBB);

		// 对结束块进行设置，同前
		CurrentFunc->getBasicBlockList().push_back(ForEndBB);
		IRBuilder.SetInsertPoint(ForEndBB);
		if (this->_VarDecl) {
			__Ctx.popSymbolTable();
		}
		return NULL;
	}

	// continue
	llvm::Value* ContinueStmt::IRGen(SemanticCtx& __Ctx){
		llvm::BasicBlock* ContRet = __Ctx.getContinueBlock();
		if (ContRet) {
			IRBuilder.CreateBr(ContRet);
		} else {
			throw std::logic_error("Continue statement can't be out of loop statements.");
		}
		return NULL;
	}

	// break
	llvm::Value* BreakStmt::IRGen(SemanticCtx& __Ctx){
		llvm::BasicBlock* BreakRet = __Ctx.getBreakBlock();
		if (BreakRet) {
			IRBuilder.CreateBr(BreakRet);
		} else {
			throw std::logic_error("Break statement can't be out of loop or switch statements.");
		}
		return NULL;
	}

	// return语句
	llvm::Value* ReturnStmt::IRGen(SemanticCtx& __Ctx){
		// 先获取当前函数
		llvm::Function* CurFunc = __Ctx.getCurrentFunction();
		if (this->_RetVal) {
			// 判断类型，如果不同需作强制类型转换
			llvm::Value* RetVal = TypeCasting(this->_RetVal->IRGen(__Ctx), CurFunc->getReturnType());
			if (!RetVal) {
				// 无法匹配类型或无法强制类型转换
				throw std::logic_error("The type of return value isn't the return type or can't be cast to the return type.");
				return NULL;
			} else {
				// 创建return语句
				IRBuilder.CreateRet(RetVal);
				return NULL;
			}
		} else {
			// return内容为空（如return ;），需要判断函数返回类型
			if (CurFunc->getReturnType()->isVoidTy()) {
				// 函数返回类型为void
				IRBuilder.CreateRetVoid();
				return NULL;
			} else {
				// 函数需要有值返回
				throw std::logic_error("'return' with no value, in function returning non-void.");
				return NULL;
			}
		}
	}
}
