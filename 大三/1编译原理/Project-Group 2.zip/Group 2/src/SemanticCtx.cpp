#include "SemanticCtx.hpp"

// 记录了LLVM的核心数据结构，比如类型和常量表，提供用户创建变量等对象的上下文环境
llvm::LLVMContext Context;
// 用于创建llvm指令，帮助我们生成IR指令并将其插入到指定的指令块
llvm::IRBuilder<> IRBuilder(Context);

SemanticCtx::SemanticCtx() :
	module(new llvm::Module("main", Context)),
	dataLayout(new llvm::DataLayout(module)),
	curFunction(NULL),
	structTypeTable(new StructTypeTable),
	unionTypeTable(new UnionTypeTable),
	symbolTableStack(),
	continueBlocks(),
	breakBlocks()
{
	// Initialize symbol table
	this->pushSymbolTable();
}

SemanticCtx::~SemanticCtx() {
	// Delete symbol table
	this->popSymbolTable();
	delete this->structTypeTable; 
	this->structTypeTable = NULL;
	delete this->unionTypeTable; 
	this->unionTypeTable = NULL;
}

void SemanticCtx::pushSymbolTable() {
	this->symbolTableStack.push_back(new SymbolTable);
}

void SemanticCtx::popSymbolTable() {
	if (this->symbolTableStack.size() == 0) return;
	delete this->symbolTableStack.back();
	this->symbolTableStack.pop_back();
}

llvm::Function* SemanticCtx::getFunction(std::string funcName) {
    if (this->symbolTableStack.size() == 0) return NULL;
    // 遍历vector寻找函数是否存在
	for (auto tableiter = this->symbolTableStack.end() - 1; tableiter >= this->symbolTableStack.begin(); tableiter--) {
		auto pairiter = (**tableiter).FunctionSymbols.find(funcName);
        if (pairiter != (**tableiter).FunctionSymbols.end() ){
            return pairiter->second;
        }
	}
	return NULL;
}

llvm::Type* SemanticCtx::getType(std::string typeName)  {
	if (this->symbolTableStack.size() == 0) return NULL;

	for (auto tableiter = this->symbolTableStack.end() - 1; tableiter >= this->symbolTableStack.begin(); tableiter--) {
		auto pairiter = (**tableiter).TypeSymbols.find(typeName);
		if (pairiter != (**tableiter).TypeSymbols.end())
			return pairiter->second;
	}
	return NULL;
}

llvm::TypeSize SemanticCtx::getTypeSize(llvm::Type* type) {
	return this->dataLayout->getTypeAllocSize(type);
}

ast::StructType* SemanticCtx::getStructType(llvm::StructType* structType) {
	auto iter = this->structTypeTable->find(structType);
	if (iter != this->structTypeTable->end()) {
		return iter->second;
	}
	return NULL;
}

ast::UnionType* SemanticCtx::getUnionType(llvm::StructType* unionType) {
	auto iter = this->unionTypeTable->find(unionType);
	if (iter != this->unionTypeTable->end()) {
		return iter->second;
	}
	return NULL;
}

llvm::Function* SemanticCtx::getCurrentFunction() {
	return this->curFunction;
}

llvm::BasicBlock* SemanticCtx::getContinueBlock() {
	if (this->continueBlocks.size()) {
		return this->continueBlocks.back();
	} else {
		return NULL;
	}
}

llvm::BasicBlock* SemanticCtx::getBreakBlock() {
	if (this->breakBlocks.size()) {
		return this->breakBlocks.back();
	} else {
		return NULL;
	}
}

bool SemanticCtx::addFunction(std::string funcName, llvm::Function* function) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& funcSymbols = (this->symbolTableStack.back())->FunctionSymbols;
	auto iter = funcSymbols.find(funcName);
	if (iter != funcSymbols.end()) {
		return false;
	}	
	funcSymbols[funcName] = function;
	return true;
}

bool SemanticCtx::addType(std::string typeName, llvm::Type* type) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& typeSymbols = (this->symbolTableStack.back())->TypeSymbols;
	auto iter = typeSymbols.find(typeName);
	if (iter != typeSymbols.end()) {
		return false;
	}
	typeSymbols[typeName] = type;
	return true;
}

bool SemanticCtx::addVariable(std::string varName, llvm::Value* var) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& varSymbols = (this->symbolTableStack.back())->VariableSymbols;
	auto iter = varSymbols.find(varName);
	if (iter != varSymbols.end()) {
		return false;
	}
	varSymbols[varName] = var;
	return true;
}

bool SemanticCtx::addConstant(std::string constName, llvm::Value* constant) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& constSymbols = (this->symbolTableStack.back())->ConstantSymbols;
	auto iter = constSymbols.find(constName);
	if (iter != constSymbols.end()) {
		return false;
	}
	constSymbols[constName] = constant;
	return true;
}

bool SemanticCtx::addStructType(llvm::StructType* type1, ast::StructType* type2) {
	auto iter = this->structTypeTable->find(type1);
	if (iter != this->structTypeTable->end()) {
		return false;
	}
	(*this->structTypeTable)[type1] = type2;
	return true;
}

bool SemanticCtx::addUnionType(llvm::StructType* type1, ast::UnionType* type2) {
	auto iter = this->unionTypeTable->find(type1);
	if (iter != this->unionTypeTable->end()) {
		return false;
	}
	(*this->unionTypeTable)[type1] = type2;
	return true;
}

void SemanticCtx::enterFunction(llvm::Function* function) {
	this->curFunction = function;
}

void SemanticCtx::leaveFunction() {
	this->curFunction = NULL;
}

void SemanticCtx::enterLoop(llvm::BasicBlock* continueBB, llvm::BasicBlock* breakBB) {
	this->continueBlocks.push_back(continueBB);
	this->breakBlocks.push_back(breakBB);
}

void SemanticCtx::leaveLoop() {
	if (this->continueBlocks.size() == 0 || this->breakBlocks.size() == 0) return;
	this->continueBlocks.pop_back();
	this->breakBlocks.pop_back();
}

// 0代表错误，1代表常量变量，2代表非常量变量，3代表enum的常量值
std::pair<llvm::Value*,int> SemanticCtx::getVar(std::string Name) {
	if (this->symbolTableStack.size() == 0) return std::make_pair(nullptr,0);

	for (auto tableiter = this->symbolTableStack.end() - 1; tableiter >= this->symbolTableStack.begin(); tableiter--) {
		auto pairiter = (**tableiter).ConstantVarSymbols.find(Name);
		if (pairiter != (**tableiter).ConstantVarSymbols.end())
			return std::make_pair(pairiter->second,1);
		pairiter = (**tableiter).VariableSymbols.find(Name);
		if (pairiter != (**tableiter).VariableSymbols.end())
			return std::make_pair(pairiter->second,2);
		pairiter = (**tableiter).ConstantSymbols.find(Name);
		if (pairiter != (**tableiter).ConstantSymbols.end())
			return std::make_pair(pairiter->second,3);
	}
	return std::make_pair(nullptr,0);
}

bool SemanticCtx::addConstantVar(std::string constVarName, llvm::Value* var) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& constVarSymbols = (this->symbolTableStack.back())->ConstantVarSymbols;
	auto iter = constVarSymbols.find(constVarName);
	if (iter != constVarSymbols.end()) {
		return false;
	}
	constVarSymbols[constVarName] = var;
	return true;
}

bool SemanticCtx::getCurVar(std::string VarName) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& varSymbols = (this->symbolTableStack.back())->VariableSymbols;
	auto iter = varSymbols.find(VarName);
	if (iter != varSymbols.end()) {
		return true;
	} else {
		return false;
	}
}

bool SemanticCtx::getCurConstant(std::string ConstName) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& constSymbols = (this->symbolTableStack.back())->ConstantSymbols;
	auto iter = constSymbols.find(ConstName);
	if (iter != constSymbols.end()) {
		return true;
	} else {
		return false;
	}
}

bool SemanticCtx::getCurConstantVar(std::string ConstName) {
	if (this->symbolTableStack.size() == 0) return false;

	auto& ConstantVarSymbols = (this->symbolTableStack.back())->ConstantVarSymbols;
	auto iter = ConstantVarSymbols.find(ConstName);
	if (iter != ConstantVarSymbols.end()) {
		return true;
	} else {
		return false;
	}
}
