#include "CodeGen.hpp"

void CodeGen::GenIR(ast::Program& root) {
	// Generate IR
	root.IRGen(*_ctx);
	std::cout << "IR Generated Successfully" << std::endl;
}

void CodeGen::OutputIR(std::string fileName) {
	std::error_code ec;
	llvm::raw_fd_ostream out(fileName, ec);
	out << "==================== IR ====================\n";
	_ctx->module->print(out, NULL);
	out << "=============== Verification ===============\n";
	if (llvm::verifyModule(*_ctx->module, &out) == 0) {
		out << "No errors.\n";
	}
}

void CodeGen::GenObjectCode(std::string fileName) {
	auto TargetTriple = llvm::sys::getDefaultTargetTriple();
	llvm::InitializeAllTargetInfos();
	llvm::InitializeAllTargets();
	llvm::InitializeAllTargetMCs();
	llvm::InitializeAllAsmParsers();
	llvm::InitializeAllAsmPrinters();
	std::string error;
	auto Target = llvm::TargetRegistry::lookupTarget(TargetTriple, error);
	if (!Target) {
		throw std::runtime_error(error);
		return;
	}
	auto TargetMachine = Target->createTargetMachine(TargetTriple, "generic", "", {}, llvm::None);
	_ctx->module->setDataLayout(TargetMachine->createDataLayout());
	_ctx->module->setTargetTriple(TargetTriple);
	std::error_code EC;
	llvm::raw_fd_ostream Dest(fileName, EC, llvm::sys::fs::OF_None);
	if (EC) {
		throw std::runtime_error("Could not open file: " + EC.message());
		return;
	}
	auto FileType = llvm::CGFT_ObjectFile;
	llvm::legacy::PassManager PM;
	if (TargetMachine->addPassesToEmitFile(PM, Dest, nullptr, FileType)) {
		throw std::runtime_error("TargetMachine can't emit a file of this type");
		return;
	}
	PM.run(*_ctx->module);
	Dest.flush();
}