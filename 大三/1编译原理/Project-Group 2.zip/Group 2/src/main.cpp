#include <iostream>
#include <fstream>
#include <exception>
#include "ast.hpp"
#include "SemanticCtx.hpp"
#include "CodeGen.hpp"
#include "argparser.hpp"

extern int yyparse();
extern ast::Program* Root;

// visualize ast
void visualizeAST(std::string fileName, ast::Program& root) {
	extern const char* html;
	std::string htmlStr = html;
	std::string json = root.astJson();
	std::string target = "${ASTJson}";
	auto pos = htmlStr.find(target);
	htmlStr.replace(pos, target.length(), json.c_str());
	std::ofstream htmlFile(fileName);
	htmlFile << htmlStr;
}

int main(int argc, const char* argv[]) {
	// Check the usage
	if (argc < 2) {
		std::cout << "Usage:" << std::endl;
		std::cout << "\t[REQUIRED] -c: specify source file" << std::endl;
		std::cout << "\t[OPTIONAL] -o: specify object file, the default is a.o" << std::endl;
		return 1;
	}

	// Parse arguments
	ArgParser argParser(argc, argv);
	std::string srcFile; 	// -c
	std::string objectFile; // -o
	// Get source file
if (!argParser.getArg("c", srcFile)) {
#if defined(_WIN32) || defined(_WIN64)
	// Windows platform
	std::cout << "Fatal error: source file not specified" << std::endl;
#elif defined(__unix__)
	//Unix platform
	std::cout << "\033[31m" << "Fatal error: source file not specified" << std::endl;
#endif
	return 1;
}
	// Get object file
	if (!argParser.getArg("o", objectFile) || objectFile == "") {
		objectFile = "a.o";
	} else if (objectFile.length() <= 2 || objectFile.substr(objectFile.length() - 2) != ".o") {
		objectFile = objectFile + ".o";
	}

	// Remove the extension name of the source file
	std::string fileName_withoutext = srcFile;
	size_t dot_pos = srcFile.rfind('.');
    if (dot_pos != std::string::npos) {
        fileName_withoutext = fileName_withoutext.substr(0, dot_pos);
    }
	// Set names of output files
	std::string IRFile = fileName_withoutext + ".ir";
	std::string htmlFile = fileName_withoutext + ".html";

	// Read source file
	freopen(srcFile.c_str(), "r", stdin);
	// Start parsing
	yyparse();
	// Create semantic context and code generator
	SemanticCtx ctx;
	CodeGen codeGen(&ctx);
	// Iterate over the ast and generate IR
	try {
		codeGen.GenIR(*Root);
	}
	catch (std::exception& e) {
		std::cout << "\033[31m" << e.what() << std::endl;
	}
	// Generate object code
	codeGen.GenObjectCode(objectFile);

	// Output IR
	codeGen.OutputIR(IRFile);
	// Visualize ast
	visualizeAST(htmlFile, *Root);
}