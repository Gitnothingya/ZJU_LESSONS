#include <iostream>
#include <sstream>
#include "ast.hpp"

using namespace std;
using namespace ast;

// 去除转义字符
string getString(string name) {
	// s 为输出结果
	std::string s = "";
	// loop through all characters
	for (char c : name) {
        // 检查是否是可打印字符，对特殊字符处理。
		if (c == '\"' || c == '\'' || c == '\\')
			s = s + "\\" + c;
		else if (c == '\n')
			s += "\\n";
		else if (c == '\t')
			s += "\\t";
		else if (c == '\r')
			s += "\\r";
		else if (isprint((unsigned char)c))
			s += c;
		else {
			std::stringstream stream;
            // 如果是不可打印字符，将其转化成16进制输出到流，还需要将有符号字转成无符号字。
			stream << std::hex << (unsigned int)(unsigned char)(c);
			std::string code = stream.str();
			s += std::string("\\x") + (code.size() < 2 ? "0" : "") + code;
		}
	}
	return s;
}

string getJson(string name) { // 获得树的叶子节点json，只需要名字即可，无需children
	// Escape twice.
    // 注意反斜杠转义，区分字符串内引号和表示字符串的引号
	return "{ \"name\" : \"" + getString(name) + "\" }";
}

string getJson(string name, vector<string> children) { // 有多个子节点
	string result = "{ \"name\" : \"" + name + "\", \"children\" : [ ";
	int i = 0;
	for (auto& child : children) {
		if (i != children.size() - 1)
			result += child + ", ";
		else
			result += child + " ";
		i++;
	}
	return result + " ] }";
}

string getJson(string name, string value) { // 仅有一个子节点，实际上还是调用多个子节点的函数
	return getJson(name, vector<string>{value});
}

/************************* AST *************************/
string Program::astJson() {
	vector<string> declJson;
	if (_ExternalDecls != NULL)
		for (auto x : *_ExternalDecls)
			if (x != NULL)
				declJson.push_back(x->astJson()); // 对每个decl递归调用astJson()

	return getJson("Program", declJson); // 返回最终结果
}

string FuncDef::astJson() {
	vector<string> children;
	if (_RetType != NULL)
		children.push_back(getJson("Return Type", _RetType->astJson())); // 返回值

	children.push_back(getJson("Function Name", getJson(_FuncName)));// 函数名

	vector <string> parameterListJson;
	if (_ParameterList != NULL) {
		for (auto& x : *_ParameterList) // 遍历参数列表 
			if (x != NULL)
				parameterListJson.push_back(x->astJson());
		if (_ParameterList->_isVariable == true) // 可变参数，额外加入...
			parameterListJson.push_back(getJson("...",""));
		children.push_back(getJson("ParameterList", parameterListJson)); // 添加参数列表
	}
	if(_FuncBody !=NULL)
		children.push_back(_FuncBody->astJson()); // 添加函数体

	return getJson("FuncDef", children);
}

string AbstractDeclarator::astJson() { 
	vector <string> children;
	if (_Pointers != NULL) {
		for (auto& x: *_Pointers) {
			if (x != NULL)
			 	children.push_back(x->astJson());
		}
	}
	if (_ArrayDimensions != NULL) {
		for (auto& x: *_ArrayDimensions) {
			if (x != NULL)
				children.push_back(x->astJson());
		}
	}
	return getJson("AbstractDeclarator", children);
}

string VarDeclarator::astJson() {
	vector <string> children;

	children.push_back(getJson("Name", getJson(_VarName)));
	if (_Pointers != NULL) {
		for (auto& x: *_Pointers) {
			if (x != NULL)
				children.push_back(x->astJson());
		}
	}
	if (_ArrayDimensions != NULL) {
		for (auto& x: *_ArrayDimensions) {
			if (x != NULL)
				children.push_back(x->astJson());
		}
	}
	return getJson("VarDeclarator",children);
}

string TypeName::astJson() {
	vector <string> children;
	if (_TypeSpec != NULL)
		children.push_back(_TypeSpec->astJson());
	if (_AbstractDeclarator != NULL)	
		children.push_back( _AbstractDeclarator->astJson());

	return getJson("TypeName",children);
}

string FuncDecl::astJson() {
	vector <string> children;
	if (_RetType != NULL)
		children.push_back(getJson("ReturnType",_RetType->astJson()));

	children.push_back(getJson("Fuction Name",getJson(_FuncName)));

	vector <string> parameterListJson;
	if (_ParameterList != NULL) {
		for (auto& x : *_ParameterList){ // 遍历参数列表
			if (x != NULL)
				parameterListJson.push_back(x->astJson());
		}
		if (_ParameterList->_isVariable == true) // 可变参数，额外加入...
			parameterListJson.push_back(getJson("...",""));
		children.push_back(getJson("ParameterList", parameterListJson)); // 添加参数列表
	}
	
	return getJson("FuncDecl",children);
}

string Parameter::astJson() {
	vector <string> children;
	if (_TypeSpec != NULL)
		children.push_back(_TypeSpec->astJson());

	if (_AbstractDeclarator != NULL)
		children.push_back(_AbstractDeclarator->astJson());
		 
	if (MyType != NULL)
		children.push_back(MyType->astJson());
	children.push_back(getJson("VarName",getJson(_VarName)));

	return getJson("Parameter",children);
}

string ParameterList::astJson() {
	if (_isVariable == true)
		return getJson("..", getJson("True"));
	else if (_isVariable == false)
		return getJson("..", getJson("False"));
	else 
		return getJson("ERROR");
}

string VarDecl::astJson() {
	vector<string> children;
	if (_TypeSpec != NULL)
		children.push_back(_TypeSpec->astJson());

	vector<string> VarInitListJson;
	if (_VarInitList != NULL) {
		for ( auto & x : *_VarInitList) {
			if (x != NULL)
				VarInitListJson.push_back(x->astJson());
		}
	}
	children.push_back(getJson("VarInitList",VarInitListJson));

	return getJson("VarDecl",children);
}

string Pointer::astJson() {
	return getJson(to_string(_isConst));
}

string VarInit::astJson() {
	vector<string> children;

	if (_VarDeclarator != NULL) {
		children.push_back(_VarDeclarator->astJson());
	}
	if (_Initializer != NULL) {
		children.push_back(_Initializer->astJson());
	}
	return getJson("VarInit",children);
}

string Initializer::astJson() {
	vector<string> children;
	if (_InitialExpr != NULL) {
		children.push_back(_InitialExpr->astJson());
	}
		
	vector<string> InitializerListJson;
	if (_InitializerList != NULL) {
		for (auto & x: *_InitializerList) {
			if (x != NULL)
			InitializerListJson.push_back(x->astJson());
		}
	}
	children.push_back(getJson("InitializerList",InitializerListJson));
	return getJson("Initializer",children);
}

string DesignatorInit::astJson() {
	vector<string> children;
	if(_Designation != NULL)
		children.push_back(_Designation->astJson());
	if(_Initializer != NULL)
		children.push_back(_Initializer->astJson());
	return getJson("DesignatorInit",children);
}

string Designation::astJson() {
	vector<string> children;
	if(_DesignatorList !=NULL){
		for (auto & x: *_DesignatorList) {
			if(x !=NULL)
				children.push_back(x->astJson());
		}
	}
	
	return getJson("Designation",children);
}

string Designator::astJson() {
	vector<string> children;
	if(_ArraySubscript != NULL)
		children.push_back(_ArraySubscript->astJson());
	children.push_back(getJson("MemName",getJson(_MemName)));
	return getJson("Designator",children);
}

string TypeDef::astJson() {
	vector<string> children;
	if(_TypeSpec !=NULL)
		children.push_back(_TypeSpec->astJson());
	if(_VarDeclarator != NULL)
		children.push_back(_VarDeclarator->astJson());
	return getJson("TypeDef",children);
}

string BuiltInType::astJson() {
	switch (_Type)
 {
	case BOOL:
		return getJson("BuildInType", getJson("Bool"));
		break;
	case SHORT:
		return getJson("BuildInType", getJson("Short"));
		break;
	case INT:
		return getJson("BuildInType", getJson("Int"));
		break;
	case LONG:
		return getJson("BuildInType", getJson("Long"));
		break;
	case CHAR:
		return getJson("BuildInType", getJson("Char"));
		break;
	case FLOAT:
		return getJson("BuildInType", getJson("Float"));
		break;
	case DOUBLE:
		return getJson("BuildInType", getJson("Double"));
		break;
	case VOID:
		return getJson("BuildInType", getJson("Void"));
		break;
	default:
		return getJson("ERROR");
		break;
	}
}

string StructType::astJson() {
	vector<string> children;
	children.push_back(getJson("Struct Name",getJson(_StructName)));
	if (_StructBody != NULL)
		for (auto& x : *_StructBody)
			if(x != NULL)
				children.push_back(x->astJson());
	return getJson("StructType", children);
}

string UnionType::astJson() {
	vector<string> children;
	children.push_back(getJson("Union Name",getJson(_UnionName)));
	if (_UnionBody != NULL)
		for (auto& x : *_UnionBody)
			if(x != NULL)
				children.push_back(x->astJson());
	return getJson("UnionType", children);
}

string MemberDecl::astJson() {
	vector<string> children;
	if(_MemTypeSpec != NULL)
		children.push_back(getJson("Type",_MemTypeSpec->astJson()));

	if (_MemberDeclaratorList != NULL)
		for (auto& x: *_MemberDeclaratorList) {
			if(x != NULL)
				children.push_back(x->astJson());
		}
	return getJson("MemberDecl",children);
}

string EnumType::astJson() {
	vector<string> children;
	children.push_back(getJson("Enum Name",getJson(_EnumName)));
	if (_EnumeratorList != NULL)
		for (auto& x : *_EnumeratorList)
			if(x != NULL)
				children.push_back(x->astJson());
	return getJson("EnumType", children);
}

string Enumerator::astJson() {
	vector<string> children;	
	children.push_back(getJson("Name",getJson(_Name) ));
	if (_Value != NULL) {
		children.push_back(getJson("Value",_Value->astJson()));
	}
	return getJson("Enumerator", children);
}

string DefinedType::astJson() {
	return getJson("DefinedType",getJson(_Name));
}

string CommaExpr::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("CommaExpr", children);
}

string Assignment::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Assignment", children);
}

string MulAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("MulAssign", children);
}

string DivAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("DivAssign", children);
}

string ModAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("ModAssign", children);
}

string AddAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("AddAssign", children);
}

string SubAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("SubAssign", children);
}

string LSHAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LSHAssign", children);
}

string RSHAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("RSHAssign", children);
}

string BitANDAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitANDAssign", children);
}

string BitORAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitORAssign", children);

}

string BitXORAssign::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitXORAssign", children);
}

string TernaryCondition::astJson() {
	vector<string> children;	
	if(_Condition != NULL)
		children.push_back(_Condition->astJson());
	if(_Then != NULL)
		children.push_back(_Then->astJson());
	if(_Else != NULL)
		children.push_back(_Else->astJson());
	return getJson("TernaryCondition", children);
}

string LogicalOR::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalOR", children);
}

string LogicalAND::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalAND", children);
}

string BitwiseOR::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitwiseOR", children);
}

string BitwiseXOR::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitwiseXOR", children);
}

string BitwiseAND::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("BitwiseAND", children);
}

string LogicalEQ::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalEQ", children);
}

string LogicalNEQ::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalNEQ", children);
}

string LogicalLT::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalLT", children);
}

string LogicalGT::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalGT", children);
}

string LogicalLE::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalLE", children);
}

string LogicalGE::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LogicalGE", children);
}

string LeftShift::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("LeftShift", children);
}

string RightShift::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("RightShift", children);
}

string Addition::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Addition", children);
}

string Subtraction::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Subtraction", children);
}

string Multiplication::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Multiplication", children);
}

string Division::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Division", children);
}

string Modulo::astJson() {
	vector<string> children;	
	if(_LHS != NULL)
		children.push_back(_LHS->astJson());
	if(_RHS != NULL)
		children.push_back(_RHS->astJson());
	return getJson("Modulo", children);
}

string TypeCast::astJson() { 
	vector<string> children;	
	if(_Type != NULL)
		children.push_back(_Type->astJson());
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("TypeCast", children);
}

string PrefixInc::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("PrefixInc", children);
}

string PrefixDec::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("PrefixDec", children);
}

string SizeOf::astJson() {
	vector<string> children;	
	if (_Arg1 != NULL)
		children.push_back(_Arg1->astJson());
	if (_Arg2 != NULL)
		children.push_back(_Arg2->astJson());
	return getJson("Sizeof", children);
}

string AddressOf::astJson() { 
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("AddressOf", children);
}

string Indirection::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("Indirection", children);
}

string UnaryPlus::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("UnaryPlus", children);
}

string UnaryMinus::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("UnaryMinus", children);
}

string BitwiseNot::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("BitwiseNot", children);
}

string LogicalNot::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("LogicalNot", children);
}

string Subscript::astJson() {
	vector<string> children;	
	if(_Array != NULL)
		children.push_back(_Array->astJson()); 

    vector<string> IndexJson;
	if(_Index != NULL){
		for (auto &x: *_Index) {
			if(x != NULL)
        		IndexJson.push_back(x->astJson());
    	}
	}
    
	children.push_back(getJson("Index",children));
	return getJson("Subscript", children);
}

string FuncCall::astJson() {
	vector<string> children;	
	children.push_back(getJson("Function Name", getJson(_Function)));

	vector<string> argListJson;
	if (_ArgExprList != NULL)
		for (auto x : *_ArgExprList)
			if(x != NULL)
				argListJson.push_back(x->astJson());
	children.push_back(getJson("ArgExprList", argListJson));
	return getJson("FunctionCall", children);
}

string StructReference::astJson() {
	vector<string> children;	
	if(_Struct != NULL)
	 	children.push_back(_Struct->astJson());
	children.push_back(getJson(_MemName));
	return getJson("StructReference", children);
}

string StructDereference::astJson() {
	vector<string> children;	
	if(_StructPtr != NULL)
		children.push_back(_StructPtr->astJson());
	children.push_back(getJson(_MemName));
	return getJson("StructDereference", children);
}

string PostfixInc::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("PostfixInc", children);
}

string PostfixDec::astJson() {
	vector<string> children;	
	if(_Operand != NULL)
		children.push_back(_Operand->astJson());
	return getJson("PostfixDec", children);
}

string Variable::astJson() {
	vector<string> children;	
	children.push_back(getJson(_Name));
	return getJson("Variable", children);
}

string PrimaryExpr::astJson() {
	if (_expr != NULL)
		return getJson("PrimaryExpr", _expr->astJson());
	else return getJson("PrimaryExpr",getJson("  "));
}

string Constant::astJson() {
	vector<string> children;	
	switch (_Type)
 {
	case BuiltInType::TypeID::BOOL:
		return (_Bool == true) ? getJson("Constant", getJson("True")) : getJson("Constant", getJson("False"));
		break;
	case BuiltInType::TypeID::SHORT:
	case BuiltInType::TypeID::INT:
	case BuiltInType::TypeID::LONG:
		return getJson("Constant", getJson(to_string(_Integer)));
		break;
	case BuiltInType::TypeID::CHAR:
		return getJson("Constant", getJson("\'" + getString(string(1, _Character)) + "\'"));
		break;
	case BuiltInType::TypeID::FLOAT:
	case BuiltInType::TypeID::DOUBLE:
		return getJson("Constant", getJson(to_string(_Real)));
		break;
	default:
		return getJson("ERROR");
		break;
	}
}

string StringLiteral::astJson() {
	vector<string> children;	
	children.push_back(getJson("\"" + getString(_Content) + "\""));
	return getJson("StringLiteral", children);
}

string CompoundStmt::astJson() {
	vector<string> children;
	if (_BlockItems != NULL) {
		for (auto& x: *_BlockItems) {
			if(x != NULL)
				children.push_back(x->astJson());
		}
	}
	return getJson("CompoundStmt",children);
}

string ExprStmt::astJson() {
	if (_Expression != NULL) {
		return getJson("ExprStmt",_Expression->astJson());
	}
	return getJson("NULLStmt");
}

string IfStmt::astJson() {
	vector<string> children;	
	if(_Condition != NULL)
		children.push_back(_Condition->astJson());
	if(_Then != NULL)
		children.push_back(_Then->astJson());

	if (_Else != NULL)
		children.push_back(_Else->astJson());
	return getJson("IfStmt", children);
}

string SwitchStmt::astJson() {
	vector<string> children;	
	if(_Matcher != NULL)
		children.push_back(_Matcher->astJson());

	vector<string> caseListJson;
	if (_CaseList != NULL)
		for (auto x : *_CaseList)
			if(x != NULL)
				caseListJson.push_back(x->astJson());
	if (_Default != NULL )
		caseListJson.push_back(_Default->astJson());

	children.push_back(getJson("CaseList", caseListJson));
	return getJson("SwitchStmt", children);
}

string CaseStmt::astJson() {
	vector<string> children;	
	if(_Condition != NULL)
		children.push_back(_Condition->astJson());

	vector<string> stmtListJson;
	if (_CaseBody != NULL)
		for (auto x : *_CaseBody)
			if(x != NULL)
				stmtListJson.push_back(x->astJson());
	children.push_back(getJson("StatmentList", stmtListJson));
	return getJson("CaseStmt", children);
}

string DefaultStmt::astJson() {
	vector<string> children;	
	children.push_back(getJson("Default"));

	vector<string> stmtListJson;
	if (_DefaultBody != NULL)
		for (auto x : *_DefaultBody)
			if(x != NULL)
				stmtListJson.push_back(x->astJson());
	children.push_back(getJson("StatmentList", stmtListJson));
	return getJson("DefaultStmt", children);
}

string WhileStmt::astJson() {
	vector<string> children;	
	if(_Condition != NULL)
		children.push_back(_Condition->astJson());

	if (_LoopBody != NULL)
		children.push_back(_LoopBody->astJson());
	return getJson("WhileStmt", children);
}

string DoWhileStmt::astJson() {
	vector<string> children;	
	if (_LoopBody != NULL)
		children.push_back(_LoopBody->astJson());
	if(_Condition != NULL)
		children.push_back(_Condition->astJson());
	return getJson("DoWhileStmt", children);
}

string ForStmt::astJson() {
	vector<string> children;	
	if (_Initial != NULL)
		children.push_back(_Initial->astJson());
	if (_Condition != NULL)
		children.push_back(_Condition->astJson());
	if (_Tail != NULL)
		children.push_back(_Tail->astJson());
	if (_LoopBody != NULL)
		children.push_back(_LoopBody->astJson());
	return getJson("ForStmt", children);
}

string ContinueStmt::astJson() {
	return getJson("ContinueStmt");
}

string BreakStmt::astJson() {
	return getJson("BreakStmt");
}

string ReturnStmt::astJson() {
	vector<string> children;	
	if (_RetVal != NULL)
		children.push_back(_RetVal->astJson());
	return getJson("ReturnStmt", children);
}