#pragma once
#include <iostream>
#include <vector>
#include <string>
#include "SemanticCtx.hpp"

// 结合BaseType和声明子组成重组类型并返回
llvm::Type* GenerateTypename(ast::TypeSpec* _TypeSpec, ast::Pointers* _Pointers, ast::ArrayDimensions* _ArrayDimensions, SemanticCtx& __Ctx) {
	// 根据BaseType和声明子判断类型
	ast::AbstractDeclarator* Tmp = new ast::AbstractDeclarator(_Pointers, _ArrayDimensions);
	ast::TypeName *VarTy = new ast::TypeName(_TypeSpec,Tmp);
	// 组合后的类型
	llvm::Type* VarType = VarTy->GetLLVMType(__Ctx);
	delete Tmp;
	delete VarTy;
	return VarType;
}

// 将int类型转成llvm::Value类型
llvm::Value* Uint2LLVMVal(uint64_t IntVal) {
	llvm::Type* intType = llvm::Type::getInt32Ty(Context);
	llvm::Constant* constantInt = llvm::ConstantInt::get(intType, IntVal);
	llvm::Value* valueInt = constantInt;
	return valueInt;
}

// 将llvm::Value类型(Integer)转成uint64_t类型
uint64_t LLVMVal2Uint(llvm::Value* IntVal) {
	llvm::ConstantInt* constInt = llvm::dyn_cast<llvm::ConstantInt>(IntVal);
	uint64_t intValue = constInt->getValue().getSExtValue();
	return intValue;
}

// 强制类型转换，转成一位的布尔型，供条件分支和循环判断使用
// 只提供布尔、整数、浮点到布尔的转换，其余会抛出异常返回NULL
llvm::Value* Cast2Bool(llvm::Value* Value) {
	if (Value->getType() == IRBuilder.getInt1Ty()) {
		// Value为布尔型,直接返回
		return Value;
	} else if (Value->getType()->isIntegerTy()) {
		// Value为整数型,先调llvm的API实现转换再返回，这里需要构造0的整数常量，下同
		return IRBuilder.CreateICmpNE(Value, llvm::ConstantInt::get((llvm::IntegerType*)Value->getType(), 0, true));
	} else if (Value->getType()->isFloatingPointTy()) {
		// Value为浮点型
		return IRBuilder.CreateFCmpONE(Value, llvm::ConstantFP::get(Value->getType(), 0.0));
	} else if (Value->getType()->isPointerTy()) {
		// Value为指针，由于是表示地址因而当64位整数处理
		return IRBuilder.CreateICmpNE(IRBuilder.CreatePtrToInt(Value, IRBuilder.getInt64Ty()), IRBuilder.getInt64(0));
	} else { 
		// 抛出异常
		throw std::logic_error(Value->getName().str() + " can't be cast to bool type.");
		return NULL;
	}
}

// 强制类型转换(围绕Int、FP、Pointer和Bool类型)，主要服务于用户
// 参数：Value为要转换的值，Type为目标类型
llvm::Value* TypeCasting(llvm::Value* Value, llvm::Type* Type) {
	if (Value->getType() == Type) {
		// Value类型和Type一样
		return Value;
	} else if (Type == IRBuilder.getInt1Ty()) {	
		// Type为布尔型，需另行处理
		return Cast2Bool(Value);
	} else if (Value->getType()->isIntegerTy() && Type->isIntegerTy()) {
		// Int -> Int，注意：如果Value为一位则转化时需要进行的是零扩展，而不是符号扩展
		return IRBuilder.CreateIntCast(Value, Type, !Value->getType()->isIntegerTy(1));
	} else if (Value->getType()->isIntegerTy() && Type->isFloatingPointTy()) {
		// Int -> FP，注意：如果Value为一位则转化时需要进行的是零扩展，而不是符号扩展
		if (Value->getType()->isIntegerTy(1)) {
			return IRBuilder.CreateUIToFP(Value, Type);
		} else {
			return IRBuilder.CreateSIToFP(Value, Type);
		}
	} else if (Value->getType()->isIntegerTy() && Type->isPointerTy()) {
		// Int -> Pointer
		return IRBuilder.CreateIntToPtr(Value, Type);
	} else if (Value->getType()->isFloatingPointTy() && Type->isIntegerTy()) {
		// FP -> Int
		return IRBuilder.CreateFPToSI(Value, Type);
	} else if (Value->getType()->isFloatingPointTy() && Type->isFloatingPointTy()) {
		// FP -> FP
		return IRBuilder.CreateFPCast(Value, Type);
	} else if (Value->getType()->isPointerTy() && Type->isIntegerTy()) {
		// Pointer -> Int
		return IRBuilder.CreatePtrToInt(Value, Type);
	} else if (Value->getType()->isPointerTy() && Type->isPointerTy()) {
		// Pointer -> Pointer
		return IRBuilder.CreatePointerCast(Value, Type);
	} else {
		// 无效转换，交给上面的函数处理这个异常
		return NULL;
	}
}

// 类型提升，针对整数和浮点类型，主要服务于编译器的行为
// 参数：Value为要类型提升的值，Type为提升后的目标类型
llvm::Value* TypeUpgrading(llvm::Value* Value, llvm::Type* Type) {
	if (Value->getType()->isIntegerTy() && Type->isIntegerTy()) {
		// Value和Type均为整形，比较位数
		size_t Bit1 = ((llvm::IntegerType*)Value->getType())->getBitWidth();
		size_t Bit2 = ((llvm::IntegerType*)Type)->getBitWidth();
		if (Bit1 < Bit2) {
			return IRBuilder.CreateIntCast(Value, Type, Bit1 != 1);
		} else {
			return Value;
		}
	} else if (Value->getType()->isFloatingPointTy() && Type->isFloatingPointTy()) {
		// Value和Type均为浮点，看是float还是double，如果Value为float，Type为double，则需要作转换，其余只需返回Value
		if (Value->getType()->isFloatTy() && Type->isDoubleTy()) {
			return IRBuilder.CreateFPCast(Value, Type);
		} else {
			return Value;
		}
	} else if (Value->getType()->isIntegerTy() && Type->isFloatingPointTy()) {
		// Value为整数，Type为浮点，提升为浮点，同样要注意一位整数的符号扩展问题
		if (Value->getType()->isIntegerTy(1)) {
			return IRBuilder.CreateUIToFP(Value, Type);
		} else {
			return IRBuilder.CreateSIToFP(Value, Type);
		}
	} else if (Value->getType()->isFloatingPointTy() && Type->isIntegerTy()) {
		// Value为浮点，Type为整数，直接返回
		return Value;
	} else {
		// 无效提升，交给上面的函数处理这个异常
		return NULL;
	}
}

// 类型提升，与上面不同的是：该函数处理两个值，根据其类型判断如何类型提升，并通过bool值返回判断是否成功
// 参数：两个要提升的类型的引用，方便我们修改里面的内容
bool TypeUpgrading(llvm::Value*& Value1, llvm::Value*& Value2) {
	if (Value1->getType()->isIntegerTy() && Value2->getType()->isIntegerTy()) {
		// 均为整数，通过位数比较
		size_t Bit1 = ((llvm::IntegerType*)Value1->getType())->getBitWidth();
		size_t Bit2 = ((llvm::IntegerType*)Value2->getType())->getBitWidth();
		if (Bit1 < Bit2) {
			Value1 = IRBuilder.CreateIntCast(Value1, Value2->getType(), Bit1 != 1);
		} else if (Bit1 > Bit2) {
			Value2 = IRBuilder.CreateIntCast(Value2, Value1->getType(), Bit2 != 1);
		}
		return true;
	} else if (Value1->getType()->isFloatingPointTy() && Value2->getType()->isFloatingPointTy()) {
		// 均为浮点，判断两种情况
		if (Value1->getType()->isFloatTy() && Value2->getType()->isDoubleTy()) {
			Value1 = IRBuilder.CreateFPCast(Value1, IRBuilder.getDoubleTy());
		} else if (Value1->getType()->isDoubleTy() && Value2->getType()->isFloatTy()) {
			Value2 = IRBuilder.CreateFPCast(Value2, IRBuilder.getDoubleTy());
		}
		return true;
	} else if (Value1->getType()->isIntegerTy() && Value2->getType()->isFloatingPointTy()) {
		// Value1为整数，Value2为浮点，则转成浮点
		if (Value1->getType()->isIntegerTy(1)) {
			Value1 = IRBuilder.CreateUIToFP(Value1, Value2->getType());
		} else {
			Value1 = IRBuilder.CreateSIToFP(Value1, Value2->getType());
		}
		return true;
	} else if (Value1->getType()->isFloatingPointTy() && Value2->getType()->isIntegerTy()) {
		// Value2为整数，Value1为浮点，则转成浮点
		if (Value2->getType()->isIntegerTy(1)) {
			Value2 = IRBuilder.CreateUIToFP(Value2, Value1->getType());
		} else {
			Value2 = IRBuilder.CreateSIToFP(Value2, Value1->getType());
		}
		return true;
	} else {
		// 提升失败
		return false;
	}
}

// 在当前函数的入口块中创建一个alloca指令，帮助防止堆栈溢出
// alloca指令用于在当前函数的堆栈帧上分配内存，在函数的入口块中使用alloca指令分配内存空间是最常见的方式
// 但如果变量声明在入口块之外，我们可以使用该函数来在变量声明的位置插入alloca指令，以便在需要时为该变量分配内存空间
// 这样可以避免在循环等可能重复执行的代码块中反复分配内存而导致堆栈溢出的问题
// 参数：Func表示当前函数，VarName表示要创建的变量名称，VarType为类型
llvm::AllocaInst* CreateEntryBlockAlloca(llvm::Function* Func, std::string VarName, llvm::Type* VarType) {
	// 创建了临时IRBuilder对象TmpB，并使用当前函数的入口块作为其基本块
	llvm::IRBuilder<> TmpB(&Func->getEntryBlock(), Func->getEntryBlock().begin());
	// 在入口块的起始位置调用CreateAlloca函数创建一个alloca指令，并将其返回
	return TmpB.CreateAlloca(VarType, 0, VarName);
}

// 创建两个值是否想等的比较指令，会自动作类型提升，函数返回比较结果
// 参数：两个要比较的值
llvm::Value* CreateCmpEQ(llvm::Value* LHS, llvm::Value* RHS) {
	// LHS和RHS均为整数或浮点
	if (TypeUpgrading(LHS, RHS)) {
		// TypeUpgrading会统一它们的类型，使能够比较
		if (LHS->getType()->isIntegerTy()) {
			// int
			return IRBuilder.CreateICmpEQ(LHS, RHS);
		} else {
			// float or double
			return IRBuilder.CreateFCmpOEQ(LHS, RHS);
		}
	}
	// 表达式中含有指针，统一转化为整数类型int64比较
	if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) {
		// 均为指针
		return IRBuilder.CreateICmpEQ(
			IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
			IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
		);
	} else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) {
		// RHS为整数
		return IRBuilder.CreateICmpEQ(
			IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
			TypeUpgrading(RHS, IRBuilder.getInt64Ty())
		);
	} else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) {
		// LHS为整数
		return IRBuilder.CreateICmpEQ(
			TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
			IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
		);
	} else {
		throw std::domain_error("LogicalEQ \"==\" using unsupported type combination.");
		return NULL;
	}
}

// 创建两个值是否不等的比较指令，会自动作类型提升，函数返回比较结果
// 参数：两个要比较的值
llvm::Value* CreateCmpNEQ(llvm::Value* LHS, llvm::Value* RHS) {
	// LHS和RHS均为整数或浮点
	if (TypeUpgrading(LHS, RHS)) {
		// TypeUpgrading会统一它们的类型，使能够比较
		if (LHS->getType()->isIntegerTy()) {
			// int
			return IRBuilder.CreateICmpNE(LHS, RHS);
		} else {
			// float or double
			return IRBuilder.CreateFCmpONE(LHS, RHS);
		}
	}
	// 表达式中含有指针，统一转化为整数类型int64比较
	if (LHS->getType()->isPointerTy() && RHS->getType()->isPointerTy()) { 
		// 均为指针
		return IRBuilder.CreateICmpNE(
			IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
			IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
		);
	} else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) { 
		// RHS为整数
		return IRBuilder.CreateICmpNE(
			IRBuilder.CreatePtrToInt(LHS, IRBuilder.getInt64Ty()),
			TypeUpgrading(RHS, IRBuilder.getInt64Ty())
		);
	} else if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) { 
		// LHS为整数
		return IRBuilder.CreateICmpNE(
			TypeUpgrading(LHS, IRBuilder.getInt64Ty()),
			IRBuilder.CreatePtrToInt(RHS, IRBuilder.getInt64Ty())
		);
	} else {
		throw std::domain_error("LogicalNEQ \"!=\" using unsupported type comparison.");
		return NULL;
	}
}

// 创建加法指令，有必要时作类型转换
llvm::Value* CreateAdd(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先作类型提升判断
	if (TypeUpgrading(LHS, RHS)) {
		if (LHS->getType()->isIntegerTy()) {
			// Int + Int -> Int
			return IRBuilder.CreateAdd(LHS, RHS);
		} else {
			// Int + FP -> FP 和 FP + Int -> FP 和 FP + FP -> FP
			return IRBuilder.CreateFAdd(LHS, RHS);
		}
	}
	if (LHS->getType()->isIntegerTy() && RHS->getType()->isPointerTy()) {
		// Int + Pointer -> Pointer
		return IRBuilder.CreateGEP(RHS->getType()->getNonOpaquePointerElementType(), RHS, LHS);
	} else if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) {
		// Pointer + Int -> Pointer
		return IRBuilder.CreateGEP(LHS->getType()->getNonOpaquePointerElementType(), LHS, RHS);
	} else {
		// 加法指令两端的类型异常
		throw std::logic_error("Addition using unsupported type.");
		return NULL;
	}
}

// 创建减法指令，有必要时作类型转换
llvm::Value* CreateSub(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先作类型提升判断
	if (TypeUpgrading(LHS, RHS)) {
		if (LHS->getType()->isIntegerTy()) {
			// Int - Int -> Int
			return IRBuilder.CreateSub(LHS, RHS);
		} else {
			// Int - FP -> FP 和 FP - Int -> FP 和 FP - FP -> FP
			return IRBuilder.CreateFSub(LHS, RHS);
		}
	}
	if (LHS->getType()->isPointerTy() && RHS->getType()->isIntegerTy()) {
		// Pointer - Int -> Pointer
		RHS = IRBuilder.CreateNeg(RHS);
		return IRBuilder.CreateGEP(LHS->getType()->getNonOpaquePointerElementType(), LHS, RHS);
	} else if (LHS->getType()->isPointerTy() && LHS->getType() == RHS->getType()) {
		// Pointer - Pointer -> Int64,即两个指针的偏移量
		return IRBuilder.CreatePtrDiff(LHS->getType()->getNonOpaquePointerElementType(), LHS, RHS);
	} else {
		// 减法指令两端的类型异常
		throw std::logic_error("Subtraction using unsupported type.");
		return NULL;
	}
}

// 创建乘法指令，有必要时作类型转换
llvm::Value* CreateMul(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先作类型提升判断
	if (TypeUpgrading(LHS, RHS)) {
		if (LHS->getType()->isIntegerTy()) {
			// Int * Int -> Int
			return IRBuilder.CreateMul(LHS, RHS);
		} else {
			// Int * FP -> FP 和 FP * Int -> FP 和 FP * FP -> FP
			return IRBuilder.CreateFMul(LHS, RHS);
		}
	} else {
		// 乘法指令两端的类型异常
		throw std::logic_error("Multiplication using unsupported type.");
		return NULL;
	}
}

// 创建除法指令，有必要时作类型转换
llvm::Value* CreateDiv(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先作类型提升判断
	if (TypeUpgrading(LHS, RHS)) {
		if (LHS->getType()->isIntegerTy()) {
			// Int / Int -> Int
			return IRBuilder.CreateSDiv(LHS, RHS);
		} else {
			// Int / FP -> FP 和 FP / Int -> FP 和 FP / FP -> FP
			return IRBuilder.CreateFDiv(LHS, RHS);
		}
	} else {
		// 除法指令两端的类型异常
		throw std::logic_error("Division using unsupported type.");
		return NULL;
	}
}

// 创建取模指令，有必要时作类型转换
llvm::Value* CreateMod(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Modulo operator \"%\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateSRem(LHS, RHS);
	}
}

// 创建左移指令，有必要时作类型转换
llvm::Value* CreateShl(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Left shifting operator \"<<\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateShl(LHS, RHS);
	}
}

// 创建右移指令，有必要时作类型转换
llvm::Value* CreateShr(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Left shifting operator \"<<\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateAShr(LHS, RHS);
	}
}

// 创建AND指令，有必要时作类型转换
llvm::Value* CreateBitwiseAND(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Bitwise AND operator \"&\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateAnd(LHS, RHS);
	}
	
}

// 创建OR指令，有必要时作类型转换
llvm::Value* CreateBitwiseOR(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Bitwise OR operator \"|\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateOr(LHS, RHS);
	}
}

// 创建XOR指令，有必要时作类型转换
llvm::Value* CreateBitwiseXOR(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// 先判断是不是都是整数
	if (!(LHS->getType()->isIntegerTy()) || !(RHS->getType()->isIntegerTy())) {
		throw std::domain_error("Bitwise XOR operator \"^\" must be applied to int type.");
		return NULL;
	} else {
		// 都是整数，进行类型提升后再作运算
		TypeUpgrading(LHS, RHS);
		return IRBuilder.CreateXor(LHS, RHS);
	}
}

// 创建赋值指令，类型不同时要做强制类型转换
// 注：参数中的LHS是可修改的左值，因而实际上是一个指向那个变量存储位置的指针，所以才调用了getNonOpaquePointerElementType
llvm::Value* CreateAssignment(llvm::Value* LHS, llvm::Value* RHS, SemanticCtx& Generator) {
	// printf("%d %d\n",RHS->getType()->isIntegerTy(),LHS->getType()->isArrayTy());
	
	RHS = TypeCasting(RHS, LHS->getType()->getNonOpaquePointerElementType());
	if (RHS == NULL) {
		throw std::domain_error("In the assignment,the type of right-value can't be cast to type of the left-value.");
		return NULL;
	} else {
		// 赋值指令对应于store指令
		IRBuilder.CreateStore(RHS, LHS);
		return LHS;
	}
}

// 创建load指令，与IRBuilder.CreateLoad不同的是：
// 如果我传的是指向数组的指针，那么返回的不是整个数组，而是指向第一个元素的指针
llvm::Value* CreateLoad(llvm::Value* LHS, SemanticCtx& Generator) {
	if (LHS->getType()->getNonOpaquePointerElementType()->isArrayTy()) {
		// 针对数组的特殊处理
		return IRBuilder.CreatePointerCast(LHS, LHS->getType()->getNonOpaquePointerElementType()->getArrayElementType()->getPointerTo());
	} else {
		// 正常的load指令
		return IRBuilder.CreateLoad(LHS->getType()->getNonOpaquePointerElementType(), LHS);
	}
}

// 如果当前基本块中没有终止指令(break,continue,return等):
// 创建一条无条件跳转指令到当前基本块中(跳到BB基本块中)，否则返回NULL
llvm::BranchInst* CreateJump(llvm::BasicBlock* BB) {
	if (IRBuilder.GetInsertBlock()->getTerminator()) {
		return NULL;
	} else {
		return IRBuilder.CreateBr(BB);
	}
}