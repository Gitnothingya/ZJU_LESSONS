/**
 * @file SemanticCtx.hpp
 * @brief Semantic Context
 * @date 2023-05-26
 * 
 */

#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <exception>
#include <llvm/IR/Value.h>
#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/PassManager.h>
#include <llvm/IR/CallingConv.h>
#include <llvm/IR/IRPrintingPasses.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/GlobalVariable.h>
#include <llvm/IRReader/IRReader.h>
#include <llvm/IR/ValueSymbolTable.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Verifier.h>
#include <llvm/ExecutionEngine/MCJIT.h>
#include <llvm/ExecutionEngine/Interpreter.h>
#include <llvm/ExecutionEngine/GenericValue.h>
#include <llvm/ExecutionEngine/SectionMemoryManager.h>
#include <llvm/Support/SourceMgr.h>
#include <llvm/Support/ManagedStatic.h>
#include <llvm/Support/TargetSelect.h>
#include <llvm/Support/MemoryBuffer.h>
#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/DynamicLibrary.h>
#include <llvm/Target/TargetMachine.h>
#include <llvm/Passes/PassBuilder.h>
#include <llvm/Passes/PassPlugin.h>
#include <llvm/Transforms/InstCombine/InstCombine.h>
#include <llvm/Transforms/Scalar.h>
#include <llvm/Transforms/Scalar/GVN.h>
#include <llvm/MC/TargetRegistry.h>
#include <llvm/Support/FileSystem.h>
#include <llvm/Support/Host.h>
#include <llvm/Support/TargetSelect.h>
#include <llvm/Target/TargetMachine.h>
#include <llvm/Target/TargetOptions.h>

#include "ast.hpp"

extern llvm::LLVMContext Context;
extern llvm::IRBuilder<> IRBuilder;

class SemanticCtx {
private:
    using myFunction = std::map<std::string, llvm::Function*>;
    using myType     = std::map<std::string, llvm::Type*>;
    using myVariable = std::map<std::string, llvm::Value*>;
    using myConstant = std::map<std::string, llvm::Value*>;
	using myConstantVar = std::map<std::string, llvm::Value*>;
	using StructTypeTable = std::map<llvm::StructType*, ast::StructType*>;
	using UnionTypeTable = std::map<llvm::StructType*, ast::UnionType*>;

    class SymbolTable {
    public:
        myFunction  FunctionSymbols;
        myType      TypeSymbols;
        myVariable  VariableSymbols;
        myConstant  ConstantSymbols;
		myConstantVar ConstantVarSymbols;
    };
public:
	SemanticCtx();
	~SemanticCtx();

	/**
	 * @brief 新建一个符号表并将其压入栈中
	 */
	void pushSymbolTable();
	/**
	 * @brief 将栈顶的符号表删除并pop出来
	 */
	void popSymbolTable();
	/**
	 * @brief 获取函数名对应的llvm::Function类型
	 * 
	 * @param funcName 
	 * @return llvm::Function* 
	 */
	llvm::Function* getFunction(std::string funcName);
	/**
	 * @brief 获取类型名对应的llvm::Type类型
	 * 
	 * @param typeName 
	 * @return llvm::Type* 
	 */
	llvm::Type* getType(std::string typeName);
	/**
	 * @brief 根据变量（常量）名字获取llvm::Value，由符号表中三种类型组合查找
	 * 
	 * @param Name 
	 * @return std::pair<llvm::Value*,int> 前面为找到的值，由于是组合查找，后面用来标记类型
	 */
	std::pair<llvm::Value*,int> getVar(std::string Name);
	/**
	 * @brief 获取类型大小
	 * 
	 * @param type 
	 * @return llvm::TypeSize 
	 */
	llvm::TypeSize getTypeSize(llvm::Type* type);

	/**
	 * @brief 通过llvm类型寻找我们自定义的结构体类型，以查找内部元素。
	 * 
	 * @param structType 
	 * @return ast::StructType* 
	 */
	ast::StructType* getStructType(llvm::StructType* structType);
	/**
	 * @brief 获取共用体类型，同Struct
	 * 
	 * @param unionType 
	 * @return ast::UnionType* 
	 */
	ast::UnionType* getUnionType(llvm::StructType* unionType);
	/**
	 * @brief 获取当前正在定义的函数
	 * 
	 * @return llvm::Function* 
	 */
	llvm::Function* getCurrentFunction();
	/**
	 * @brief 获取Continue语句后跳转的基础块
	 * 
	 * @return llvm::BasicBlock* 
	 */
	llvm::BasicBlock* getContinueBlock();
	/**
	 * @brief 获取Break语句后跳转的基础块
	 * 
	 * @return llvm::BasicBlock* 
	 */
	llvm::BasicBlock* getBreakBlock();
	/**
	 * @brief 添加常量变量，即const变量
	 * 
	 * @param constVarName 
	 * @param var 
	 * @return true 添加成功
	 * @return false  添加失败，可能是栈中无符号表或者表中已有对应数据名
	 */
	bool addConstantVar(std::string constVarName, llvm::Value* var);
	/**
	 * @brief 获取栈顶符号表的当前变量名的对应变量，注意只查找栈顶符号表
	 * 
	 * @param VarName 
	 * @return true 
	 * @return false 
	 */
	bool getCurVar(std::string VarName);
	/**
	 * @brief 仅查找栈顶的Enum定义的常量
	 * 
	 * @param ConstName 
	 * @return true 
	 * @return false 
	 */
	bool getCurConstant(std::string ConstName);
	/**
	 * @brief 仅查找栈顶的Const定义常量
	 * 
	 * @param ConstName 
	 * @return true 
	 * @return false 
	 */
	bool getCurConstantVar(std::string ConstName);
	/**
	 * @brief 添加函数符号
	 * 
	 * @param funcName 
	 * @param function 
	 * @return true 
	 * @return false 
	 */
	bool addFunction(std::string funcName, llvm::Function* function);
	/**
	 * @brief 添加类型符号
	 * 
	 * @param typeName 
	 * @param type 
	 * @return true 
	 * @return false 
	 */
	bool addType(std::string typeName, llvm::Type* type);
	/**
	 * @brief 添加变量符号
	 * 
	 * @param varName 
	 * @param var 
	 * @return true 
	 * @return false 
	 */
	bool addVariable(std::string varName, llvm::Value* var) ;
	/**
	 * @brief 添加Enum常量符号
	 * 
	 * @param constName 
	 * @param constant 
	 * @return true 
	 * @return false 
	 */
	bool addConstant(std::string constName, llvm::Value* constant);
	/**
	 * @brief 将结构体映射加入对应map
	 * 
	 * @param type1 
	 * @param type2 
	 * @return true 
	 * @return false 
	 */
	bool addStructType(llvm::StructType* type1, ast::StructType* type2);
	/**
	 * @brief 将共用体映射加入对应map
	 * 
	 * @param type1 
	 * @param type2 
	 * @return true 
	 * @return false 
	 */
	bool addUnionType(llvm::StructType* type1, ast::UnionType* type2);
	/**
	 * @brief 将当前函数设置为参数
	 * 
	 * @param function 
	 */
	void enterFunction(llvm::Function* function);
	/**
	 * @brief 将当前定义函数设置为空
	 * 
	 */
	void leaveFunction();
	/**
	 * @brief 将break,continue语句对应的跳转块分别压栈。
	 * 
	 * @param continueBB 
	 * @param breakBB 
	 */
	void enterLoop(llvm::BasicBlock* continueBB, llvm::BasicBlock* breakBB);
	/**
	 * @brief 将break ， continue栈顶推出
	 * 
	 */
	void leaveLoop();

public:
    // 一个编译单元，即一个源代码文件或一个程序模块
	llvm::Module* module;

private:
	llvm::DataLayout* dataLayout;						// 数据布局信息，帮助我们确定变量的内存大小
	llvm::Function* curFunction;						
	StructTypeTable* structTypeTable;					
	UnionTypeTable* unionTypeTable;						
	std::vector<SymbolTable*> symbolTableStack;			
	std::vector<llvm::BasicBlock*> continueBlocks;		// Store blocks for continue statement
	std::vector<llvm::BasicBlock*> breakBlocks;			// Store blocks for break statement
};