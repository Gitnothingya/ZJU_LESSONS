#pragma once
#include "SemanticCtx.hpp"
#include "ast.hpp"

class CodeGen {
// private:
public:
    SemanticCtx* _ctx;
public:
    CodeGen(SemanticCtx* ctx) : _ctx(ctx) {}
    ~CodeGen() {}
    void GenIR(ast::Program& root);
    void OutputIR(std::string fileName);
    void GenObjectCode(std::string fileName);
};