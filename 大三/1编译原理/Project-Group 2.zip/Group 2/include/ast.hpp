#pragma once
#include <vector>
#include <string>
#include <llvm/IR/Value.h>
#include <llvm/IR/BasicBlock.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Function.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/LegacyPassManager.h>
#include <llvm/IR/CallingConv.h>
#include <llvm/IR/IRPrintingPasses.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/GlobalVariable.h>
#include <llvm/IRReader/IRReader.h>
#include <llvm/IR/ValueSymbolTable.h>
#include <llvm/IR/DerivedTypes.h>
#include <llvm/IR/Verifier.h>
#include <llvm/ExecutionEngine/MCJIT.h>
#include <llvm/ExecutionEngine/Interpreter.h>
#include <llvm/ExecutionEngine/GenericValue.h>
#include <llvm/ExecutionEngine/SectionMemoryManager.h>
#include <llvm/Support/SourceMgr.h>
#include <llvm/Support/ManagedStatic.h>
#include <llvm/Support/TargetSelect.h>
#include <llvm/Support/MemoryBuffer.h>
#include <llvm/Support/raw_ostream.h>
#include <llvm/Support/DynamicLibrary.h>
#include <llvm/Target/TargetMachine.h>

class SemanticCtx;

namespace ast {

    class Node;

    class Program; // the root of AST

    class AssignmentExpr;
        class Assignment; // =
        class MulAssign;  // *=
        class DivAssign; // /=
        class ModAssign; // %=
        class AddAssign; // +=
        class SubAssign; // -=
        class LSHAssign; // <<=
        class RSHAssign; // >>=
        class BitANDAssign; // &=
        class BitXORAssign; // ^=
        class BitORAssign;  // |=

    // External Declarations
    class ExternalDecl;
    using ExternalDecls = std::vector<ExternalDecl*>;
        class FuncDef;
        class Decl;
            class FuncDecl;
                // 形参, 原型声明时可以用抽象声明子
                class Parameter;
                    class AbstractDeclarator;
                class ParameterList;
            class VarDecl;
                // Variable Declarator
                class VarDeclarator;
                    using ArrayDimensions = std::vector<AssignmentExpr*>;
                    class Pointer;
                    using Pointers = std::vector<Pointer*>;
                // 初始化
                class VarInit;
                using VarInitList = std::vector<VarInit*>;
                    class Initializer;
                    class DesignatorInit;
                    using InitializerList = std::vector<DesignatorInit*>;
                    class Designation;
                    class Designator;
                    using DesignatorList = std::vector<Designator*>;
            class TypeDef;

    // Type Specifier
    class TypeSpec;
        class BuiltInType;
        class StructType;
        class UnionType;
            class MemberDecl;
            using MemberDeclList = std::vector<MemberDecl*>;
            using MemberDeclaratorList = std::vector<VarDeclarator*>;
        class EnumType;
            class Enumerator;
            using EnumeratorList = std::vector<Enumerator*>;
        class DefinedType; // typedef-name
    // 类型说明符+其指针、数组形式
    class TypeName;

    // Expression
    class Expr; 
    class CommaExpr;

    class PrimaryExpr;
        class Variable;
        class Constant;
        class StringLiteral;

    class PostfixExpr;
        class Subscript; 
        class FuncCall;
            using ArgumentExprList = std::vector<AssignmentExpr*>;
        class StructReference;
        class StructDereference;
        class PostfixInc;
        class PostfixDec;
    
    class UnaryExpr; 
        class PrefixInc;
        class PrefixDec;
        class SizeOf;
        class AddressOf;
        class Indirection;
        class UnaryPlus;
        class UnaryMinus;
        class BitwiseNot;
        class LogicalNot;

    class CastExpr; 
        class TypeCast;

    class MultiplicativeExpr; 
        class Multiplication; // *
        class Division; // /
        class Modulo; // %

    class AdditiveExpr;
        class Addition; // +
        class Subtraction; // -

    class ShiftExpr;
        class LeftShift; // <<
        class RightShift; // >>

    class RelationExpr;
        class LogicalLT; // <
        class LogicalGT; // >
        class LogicalLE; // <=
        class LogicalGE; // >=

    class EqualityExpr;
        class LogicalEQ; // ==
        class LogicalNEQ; // !=

    class ANDExpr;
        class BitwiseAND; // &
    
    class ExclusiveORExpr;
        class BitwiseXOR; // ^

    class InclusiveORExpr;
        class BitwiseOR; // | 

    class LogicalANDExpr;
        class LogicalAND; // &&
    
    class LogicalORExpr;
        class LogicalOR; // ||

    class ConditionalExpr;
        class TernaryCondition; // ? :

    // Statement
    class Stmt; 
    using Stmts = std::vector<Stmt*>;
        class CompoundStmt; // or Block
            class BlockItem; // Decl or Stmt
            using BlockItemList = std::vector<BlockItem*>;
        class ExprStmt;
        class SelectionStmt;
            class IfStmt;
            class SwitchStmt;
                class CaseStmt;
                using CaseStmts = std::vector<CaseStmt*>;
                class DefaultStmt;
        class IterationStmt;
            class WhileStmt;
            class DoWhileStmt;
            class ForStmt;
        class JumpStmt;
            class ContinueStmt;
            class BreakStmt;
            class ReturnStmt;
}

namespace ast {

	class Node {
	public:
		Node(void) {}
		~Node(void) {}
		virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
	};

    // The root of AST
    class Program : public Node { 
    public:
        ExternalDecls* _ExternalDecls;

        Program(ExternalDecls* ExternalDecls) :_ExternalDecls(ExternalDecls) {}
		~Program(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    // External Declaration(pure virtual class)
    class ExternalDecl : public Node { 
    public:
        ExternalDecl(void) {}
		~ExternalDecl(void) {}
		virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };

    class AbstractDeclarator : public Node {
    public:
        Pointers* _Pointers; // May be NULL
        ArrayDimensions* _ArrayDimensions; // May be NULL

        AbstractDeclarator(Pointers* Pointers, ArrayDimensions* ArrayDimensions) :
            _Pointers(Pointers), _ArrayDimensions(ArrayDimensions) {}
        ~AbstractDeclarator(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };

    class VarDeclarator : public Node {
    public:
        Pointers* _Pointers; // May be NULL
        std::string _VarName;
        ArrayDimensions* _ArrayDimensions; // May be NULL

        VarDeclarator(Pointers* Pointers, const std::string& VarName, ArrayDimensions* ArrayDimensions) :
            _Pointers(Pointers), _VarName(VarName), _ArrayDimensions(ArrayDimensions) {}
        ~VarDeclarator(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };

    class BlockItem : public Node {
    public:
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };

    // 类型说明符+其指针、数组形式
    class TypeName : public Node {
    public:
        TypeSpec* _TypeSpec;
        AbstractDeclarator* _AbstractDeclarator; // May be NULL
        llvm::Type* _LLVMType = NULL; // 组合类型

        TypeName(TypeSpec* TypeSpec, AbstractDeclarator* AbstractDeclarator) :_TypeSpec(TypeSpec), _AbstractDeclarator(AbstractDeclarator) {}
        ~TypeName(void) {}
        llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
        std::string astJson();
    };

    // Function Definition(with Function Body)
    class FuncDef : public ExternalDecl {
    public:
        TypeName* _RetType;
        std::string _FuncName;
        ParameterList* _ParameterList;
        CompoundStmt* _FuncBody;

        FuncDef(TypeName* RetType, const std::string& FuncName, ParameterList* ParameterList, CompoundStmt* FuncBody) :
			_RetType(RetType), _FuncName(FuncName), _ParameterList(ParameterList), _FuncBody(FuncBody) {}
		~FuncDef(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    // Declaration(pure virtual class)
    class Decl : public ExternalDecl, public BlockItem {
    public:
        Decl(void) {}
		~Decl(void) {}
		virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };

    // Function Prototype Declaration(without Function Body), the implementation is similar to FuncDef's
    class FuncDecl : public Decl {
    public:
        TypeName* _RetType;
        std::string _FuncName;
        ParameterList* _ParameterList;

        FuncDecl(TypeName* RetType, const std::string& FuncName, ParameterList* ParameterList) :
			_RetType(RetType), _FuncName(FuncName), _ParameterList(ParameterList) {}
		~FuncDecl(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    class Parameter : public Node {
    public:
		TypeSpec* _TypeSpec;
        // 函数原型声明时形参可以二选其一, 函数定义时形参一定是带标识符的
		VarDeclarator* _VarDeclarator; // 带标识符的形参
        AbstractDeclarator* _AbstractDeclarator; // 不带标识符的形参
        TypeName* MyType; //组合类型
        std::string _VarName; //可能为"",不带标识符的形参

		Parameter(TypeSpec* TypeSpec, VarDeclarator* VarDeclarator) :
			_TypeSpec(TypeSpec), _VarDeclarator(VarDeclarator), _AbstractDeclarator(NULL), _VarName(VarDeclarator->_VarName) {
                AbstractDeclarator* Tmp = new AbstractDeclarator(VarDeclarator->_Pointers,VarDeclarator->_ArrayDimensions);
                MyType = new TypeName(_TypeSpec,Tmp);
            }
        Parameter(TypeSpec* TypeSpec, AbstractDeclarator* AbstractDeclarator) :
			_TypeSpec(TypeSpec), _VarDeclarator(NULL), _AbstractDeclarator(AbstractDeclarator), _VarName("") {
                MyType = new TypeName(_TypeSpec,AbstractDeclarator);
            }
		~Parameter(void) {
            if (!_AbstractDeclarator) {
                delete MyType->_AbstractDeclarator;
            }
            delete MyType;
        }
        //Arg class don't need an actual IRGen function
		llvm::Value* IRGen(SemanticCtx& __Ctx) { return NULL; }
		std::string astJson();
    };

    class ParameterList : public std::vector<Parameter*>, public Node {
    public:
        //Set true if the argument list contains "..."
		bool _isVariable;

		void setVariable(void) { this->_isVariable = true; }
		ParameterList(void) : _isVariable(false) {}
		~ParameterList(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx) { return NULL; }
		std::string astJson();
    };

    class VarDecl : public Decl {
    public:
		TypeSpec* _TypeSpec;
		VarInitList* _VarInitList; // May be NULL

		VarDecl(TypeSpec* TypeSpec, VarInitList* VarInitList) :
			_TypeSpec(TypeSpec), _VarInitList(VarInitList) {}
		~VarDecl(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    class Pointer : public Node {
    public:
        bool _isConst;

        Pointer(bool isConst) : _isConst(isConst) {}
        ~Pointer(void) {} 
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };

    class VarInit : public Node {
    public:
		VarDeclarator* _VarDeclarator;
		Initializer* _Initializer; // May be NULL

		VarInit(VarDeclarator* VarDeclarator, Initializer* Initializer) :
			_VarDeclarator(VarDeclarator), _Initializer(Initializer) {}
		~VarInit(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    }; 

    class Initializer : public Node {
    public: 
        AssignmentExpr* _InitialExpr; // May be NULL
        InitializerList* _InitializerList; // May be NULL

        Initializer(AssignmentExpr* InitialExpr) :
            _InitialExpr(InitialExpr), _InitializerList(NULL) {}
        Initializer(InitializerList* InitializerList) :
            _InitialExpr(NULL), _InitializerList(InitializerList) {}
        ~Initializer(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };

    // 一个成员的初始化 or 初始化列表的一部分
    class DesignatorInit : public Node {
    public:
        Designation* _Designation; // May be NULL
        Initializer* _Initializer;

        DesignatorInit(Designation* Designation, Initializer* Initializer) : 
            _Designation(Designation), _Initializer(Initializer) {}
        ~DesignatorInit(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };
    class Designation : public Node {
    public:
        DesignatorList* _DesignatorList;

        Designation(DesignatorList* DesignatorList) : _DesignatorList(DesignatorList) {}
        ~Designation(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };
    class Designator : public Node {
    public:
        ConditionalExpr* _ArraySubscript;
        std::string _MemName;

        Designator(ConditionalExpr* ArraySubscript) :
            _ArraySubscript(ArraySubscript), _MemName("") {}
        Designator(const std::string& MemName) :
            _ArraySubscript(NULL), _MemName(MemName) {}
        ~Designator(void) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {return NULL;}
		std::string astJson();
    };

    class TypeDef : public Decl {
    public:
		TypeSpec* _TypeSpec;
		VarDeclarator* _VarDeclarator;

		TypeDef(TypeSpec* TypeSpec, VarDeclarator* VarDeclarator) :
			_TypeSpec(TypeSpec), _VarDeclarator(VarDeclarator) {}
		~TypeDef(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    // Type Specifier
    class TypeSpec : public Node {
    public:
        // Type Qualifier
        bool _isConst;
        bool _isSigned;
        bool _isUnsigned;
        // Its LLVM type. It is initialized as NULL, and generated by function GetLLVMType.
        llvm::Type* _LLVMType = NULL;

        TypeSpec(void) : _isConst(false), _isSigned(true), _isUnsigned(false), _LLVMType(NULL) {}
		~TypeSpec(void) {}
		
		void setConst(void) {
			this->_isConst = true;
		}
        void setSigned(void) {
            this->_isSigned = true;
        }
        void setUnsigned(void) {
            this->_isUnsigned = true;
        }

		virtual llvm::Type* GetLLVMType(SemanticCtx& __Ctx) = 0;
		llvm::Value* IRGen(SemanticCtx& __Ctx) { return NULL; }
		virtual bool isStructType(void) = 0;
		virtual bool isUnionType(void) = 0;
		virtual bool isEnumType(void) = 0;
		virtual std::string astJson() = 0;
    };
        class BuiltInType : public TypeSpec {
        public: 
            enum TypeID {
                VOID,
                BOOL,
                CHAR,
                SHORT,
                INT,
                LONG,
                FLOAT,
                DOUBLE,
            };
            TypeID _Type;

            BuiltInType(TypeID __Type) : _Type(__Type) {}
            ~BuiltInType(void) {}
            llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
            bool isStructType(void) { return false; }
            bool isUnionType(void) { return false; }
            bool isEnumType(void) { return false; }
            std::string astJson();
        };

        class StructType : public TypeSpec {
        public:
            std::string _StructName; // May be ""
		    MemberDeclList* _StructBody; // May be NULL, 如果是NULL, 说明是已定义的结构体类型, Union和Enum同理

            StructType(const std::string& StructName, MemberDeclList* StructBody) : _StructName(StructName) ,_StructBody(StructBody) {}
            ~StructType(void) {}
            llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
            llvm::Type* GenerateLLVMTypeHead(SemanticCtx& __Ctx, const std::string& __Name = "<unnamed>");
            llvm::Type* GenerateLLVMTypeBody(SemanticCtx& __Ctx);
            //Get the element index according to its name
            size_t GetElementIndex(const std::string& __MemName);
            bool isStructType(void) { return true; }
            bool isUnionType(void) { return false; }
            bool isEnumType(void) { return false; }
            std::string astJson();
        };

        // The implementation is similar to StructType
        class UnionType : public TypeSpec { 
        public:
            std::string _UnionName; // May be ""
		    MemberDeclList* _UnionBody; // May be NULL

            UnionType(const std::string& UnionName, MemberDeclList* UnionBody) : _UnionName(UnionName) ,_UnionBody(UnionBody) {}
            ~UnionType(void) {}
            llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
            llvm::Type* GenerateLLVMTypeHead(SemanticCtx& __Ctx, const std::string& __Name = "<unnamed>");
            llvm::Type* GenerateLLVMTypeBody(SemanticCtx& __Ctx);
            llvm::Type* GetElementType(const std::string& __MemName, SemanticCtx& __Ctx);
            bool isStructType(void) { return false; }
            bool isUnionType(void) { return true; }
            bool isEnumType(void) { return false; }
            std::string astJson();
        };

        // 单句成员声明(含标识符, 无初始化) int a; int a, *b, c[];
        class MemberDecl : public Node {
        public:
            TypeSpec* _MemTypeSpec;
            MemberDeclaratorList* _MemberDeclaratorList;

            MemberDecl(TypeSpec* MemTypeSpec, MemberDeclaratorList* MemberDeclaratorList) :_MemTypeSpec(MemTypeSpec), _MemberDeclaratorList(MemberDeclaratorList) {}
            ~MemberDecl(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx) { return NULL; }
            std::string astJson();
        };

        class EnumType : public TypeSpec {
        public:
            std::string _EnumName; // May be ""
            EnumeratorList* _EnumeratorList; // May be NULL

            EnumType(const std::string& EnumName, EnumeratorList* EnumeratorList) : _EnumName(EnumName), _EnumeratorList(EnumeratorList) {}
            ~EnumType(void) {}
            llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
            bool isStructType(void) { return false; }
            bool isUnionType(void) { return false; }
            bool isEnumType(void) { return true; }
            std::string astJson();
        };

        // 枚举声明子, 只能是标识符, 不用考虑*和[], 默认从0开始, 也可以显示指定值, 一旦指定, 其之后的递增
        class Enumerator : public Node {
        public:
            std::string _Name;
            ConditionalExpr* _Value; // May be NULL
            int _IntValue;

            Enumerator(const std::string& Name, ConditionalExpr* Value = 0) :
                _Name(Name), _Value(Value) {}
            ~Enumerator(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx) { return NULL; }
            std::string astJson();
        };

        // IDENTIFIER a; IDENTIFIER must be a defined type(by typedef)
        class DefinedType : public TypeSpec {
        public:
            std::string _Name;

            DefinedType(const std::string& Name) : _Name(Name) {}
            ~DefinedType(void) {}
            llvm::Type* GetLLVMType(SemanticCtx& __Ctx);
            bool isStructType(void) { return false; }
            bool isUnionType(void) { return false; }
            bool isEnumType(void) { return false; }
            std::string astJson();
        };

    /**
     * @brief Expression
     */
    class Expr : public Node {
    public:
		Expr(void) {}
		~Expr(void) {}
		// 右值
		virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
        // 左值
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0; 
    };
        class CommaExpr : public Expr {
        public:
            Expr* _LHS;
            AssignmentExpr* _RHS;
            CommaExpr(Expr* LHS, AssignmentExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
            ~CommaExpr(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();    
        };

    class AssignmentExpr : public Expr {
    public:
        UnaryExpr* _LHS;
        AssignmentExpr* _RHS;
        AssignmentExpr() {}
        AssignmentExpr(UnaryExpr* LHS, AssignmentExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~AssignmentExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class Assignment : public AssignmentExpr {
        public:
            Assignment(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~Assignment(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class MulAssign : public AssignmentExpr {
        public:
            MulAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~MulAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class DivAssign : public AssignmentExpr {
        public:
            DivAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~DivAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class ModAssign : public AssignmentExpr {
        public:
            ModAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~ModAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class AddAssign : public AssignmentExpr {
        public:
            AddAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~AddAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class SubAssign : public AssignmentExpr {
        public:
            SubAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~SubAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LSHAssign : public AssignmentExpr {
        public:
            LSHAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~LSHAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class RSHAssign : public AssignmentExpr {
            public:
            RSHAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~RSHAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class BitANDAssign : public AssignmentExpr {
        public:
            BitANDAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~BitANDAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class BitXORAssign : public AssignmentExpr {
        public:
            BitXORAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~BitXORAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class BitORAssign : public AssignmentExpr {
        public:
            BitORAssign(UnaryExpr* LHS, AssignmentExpr* RHS) : AssignmentExpr(LHS, RHS) {}
            ~BitORAssign(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class ConditionalExpr : public AssignmentExpr {
    public:
        ConditionalExpr() {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    }; 
        class TernaryCondition : public ConditionalExpr {
        public:
            LogicalORExpr* _Condition;
            Expr* _Then;
            ConditionalExpr* _Else;
            TernaryCondition(LogicalORExpr* Condition, Expr* Then, ConditionalExpr* Else) : _Condition(Condition), _Then(Then), _Else(Else) {}
            ~TernaryCondition(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class LogicalORExpr : public ConditionalExpr {
    public:
        LogicalORExpr* _LHS;
        LogicalANDExpr* _RHS;
        LogicalORExpr() {}
        LogicalORExpr(LogicalORExpr* LHS, LogicalANDExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~LogicalORExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class LogicalOR : public LogicalORExpr {
        public:
            LogicalOR(LogicalORExpr* LHS, LogicalANDExpr* RHS) : LogicalORExpr(LHS, RHS) {}
            ~LogicalOR(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class LogicalANDExpr : public LogicalORExpr {
    public:
        LogicalANDExpr* _LHS;
        InclusiveORExpr* _RHS;
        LogicalANDExpr() {}
        LogicalANDExpr(LogicalANDExpr* LHS, InclusiveORExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~LogicalANDExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class LogicalAND : public LogicalANDExpr {
        public:
            LogicalAND(LogicalANDExpr* LHS, InclusiveORExpr* RHS) : LogicalANDExpr(LHS, RHS) {}
            ~LogicalAND(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class InclusiveORExpr : public LogicalANDExpr {
    public:
        InclusiveORExpr* _LHS;
        ExclusiveORExpr* _RHS;
        InclusiveORExpr() {}
        InclusiveORExpr(InclusiveORExpr* LHS, ExclusiveORExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~InclusiveORExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class BitwiseOR : public InclusiveORExpr {
        public:
            BitwiseOR(InclusiveORExpr* LHS, ExclusiveORExpr* RHS) : InclusiveORExpr(LHS, RHS) {}
            ~BitwiseOR(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class ExclusiveORExpr : public InclusiveORExpr {
    public:
        ExclusiveORExpr* _LHS;
        ANDExpr* _RHS;
        ExclusiveORExpr() {}
        ExclusiveORExpr(ExclusiveORExpr* LHS, ANDExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~ExclusiveORExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class BitwiseXOR : public ExclusiveORExpr {
            public:
            BitwiseXOR(ExclusiveORExpr* LHS, ANDExpr* RHS) : ExclusiveORExpr(LHS, RHS) {}
            ~BitwiseXOR(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class ANDExpr : public ExclusiveORExpr {
    public:
        ANDExpr* _LHS;
        EqualityExpr* _RHS;
        ANDExpr() {}
        ANDExpr(ANDExpr* LHS, EqualityExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~ANDExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class BitwiseAND : public ANDExpr {
        public:
            BitwiseAND(ANDExpr* LHS, EqualityExpr* RHS) : ANDExpr(LHS, RHS) {}
            ~BitwiseAND(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class EqualityExpr : public ANDExpr {
    public:
        EqualityExpr* _LHS;
        RelationExpr* _RHS;
        EqualityExpr() {}
        EqualityExpr(EqualityExpr* LHS, RelationExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~EqualityExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class LogicalEQ : public EqualityExpr {
        public:
            LogicalEQ(EqualityExpr* LHS, RelationExpr* RHS) : EqualityExpr(LHS, RHS) {}
            ~LogicalEQ(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LogicalNEQ : public EqualityExpr {
        public:
            LogicalNEQ(EqualityExpr* LHS, RelationExpr* RHS) : EqualityExpr(LHS, RHS) {}
            ~LogicalNEQ(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class RelationExpr : public EqualityExpr {
    public:
        RelationExpr* _LHS;
        ShiftExpr* _RHS;
        RelationExpr() {}
        RelationExpr(RelationExpr* LHS, ShiftExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~RelationExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class LogicalLT : public RelationExpr {
        public:
            LogicalLT(RelationExpr* LHS, ShiftExpr* RHS) : RelationExpr(LHS, RHS) {}
            ~LogicalLT(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LogicalGT : public RelationExpr {
        public:
            LogicalGT(RelationExpr* LHS, ShiftExpr* RHS) : RelationExpr(LHS, RHS) {}
            ~LogicalGT(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LogicalLE : public RelationExpr {
        public:
            LogicalLE(RelationExpr* LHS, ShiftExpr* RHS) : RelationExpr(LHS, RHS) {}
            ~LogicalLE(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LogicalGE : public RelationExpr {
        public:
            LogicalGE(RelationExpr* LHS, ShiftExpr* RHS) : RelationExpr(LHS, RHS) {}
            ~LogicalGE(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class ShiftExpr : public RelationExpr {
    public:
        ShiftExpr* _LHS;
        AdditiveExpr* _RHS;
        ShiftExpr() {}
        ShiftExpr(ShiftExpr* LHS, AdditiveExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~ShiftExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class LeftShift : public ShiftExpr {
        public:
            LeftShift(ShiftExpr* LHS, AdditiveExpr* RHS) : ShiftExpr(LHS, RHS) {}
            ~LeftShift(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class RightShift : public ShiftExpr {
        public:
            RightShift(ShiftExpr* LHS, AdditiveExpr* RHS) : ShiftExpr(LHS, RHS) {}
            ~RightShift(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class AdditiveExpr : public ShiftExpr {
    public:
        AdditiveExpr* _LHS;
        MultiplicativeExpr* _RHS;
        AdditiveExpr() {}
        AdditiveExpr(AdditiveExpr* LHS, MultiplicativeExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~AdditiveExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class Addition : public AdditiveExpr {
        public:
            Addition(AdditiveExpr* LHS, MultiplicativeExpr* RHS) : AdditiveExpr(LHS, RHS) {}
            ~Addition(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class Subtraction : public AdditiveExpr {
        public:
            Subtraction(AdditiveExpr* LHS, MultiplicativeExpr* RHS) : AdditiveExpr(LHS, RHS) {}
            ~Subtraction(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class MultiplicativeExpr : public AdditiveExpr {
    public:
        MultiplicativeExpr* _LHS;
        CastExpr* _RHS;
        MultiplicativeExpr() {}
        MultiplicativeExpr(MultiplicativeExpr* LHS, CastExpr* RHS) : _LHS(LHS), _RHS(RHS) {}
        ~MultiplicativeExpr(void) {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class Multiplication : public MultiplicativeExpr {
        public:
            Multiplication(MultiplicativeExpr* LHS, CastExpr* RHS) : MultiplicativeExpr(LHS, RHS) {}
            ~Multiplication(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class Division : public MultiplicativeExpr {
        public:
            Division(MultiplicativeExpr* LHS, CastExpr* RHS) : MultiplicativeExpr(LHS, RHS) {}
            ~Division(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class Modulo : public MultiplicativeExpr {
        public:
            Modulo(MultiplicativeExpr* LHS, CastExpr* RHS) : MultiplicativeExpr(LHS, RHS) {}
            ~Modulo(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
		    llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class CastExpr : public MultiplicativeExpr {
    public: 
        CastExpr() {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class TypeCast : public CastExpr {
        public:
            TypeName* _Type;
            CastExpr* _Operand;
            TypeCast(TypeName* Type, CastExpr* Operand) : _Type(Type), _Operand(Operand) {}
            ~TypeCast(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class UnaryExpr : public CastExpr {
    public: 
        UnaryExpr() {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class PrefixInc : public UnaryExpr {
        public:
            UnaryExpr* _Operand;
            PrefixInc(UnaryExpr* Operand) : _Operand(Operand) {}
            ~PrefixInc(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class PrefixDec : public UnaryExpr {
        public:
            UnaryExpr* _Operand;
            PrefixDec(UnaryExpr* Operand) : _Operand(Operand) {}
            ~PrefixDec(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

        class SizeOf : public UnaryExpr { 
        public:
            UnaryExpr* _Arg1;
            TypeName* _Arg2;
            SizeOf(UnaryExpr* Arg1) : _Arg1(Arg1), _Arg2(NULL) {}
            SizeOf(TypeName* Arg2) : _Arg1(NULL), _Arg2(Arg2) {}
            ~SizeOf(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

        class AddressOf : public UnaryExpr {
        public:
            CastExpr* _Operand;
            AddressOf(CastExpr* Operand) : _Operand(Operand) {}
            ~AddressOf(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class Indirection : public UnaryExpr {
        public:
            CastExpr* _Operand;
            Indirection(CastExpr* Operand) : _Operand(Operand) {}
            ~Indirection(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class UnaryPlus : public UnaryExpr {
        public:
            CastExpr* _Operand;
            UnaryPlus(CastExpr* Operand) : _Operand(Operand) {}
            ~UnaryPlus(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class UnaryMinus : public UnaryExpr {
        public:
            CastExpr* _Operand;
            UnaryMinus(CastExpr* Operand) : _Operand(Operand) {}
            ~UnaryMinus(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class BitwiseNot : public UnaryExpr {
        public:
            CastExpr* _Operand;
            BitwiseNot(CastExpr* Operand) : _Operand(Operand) {}
            ~BitwiseNot(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class LogicalNot : public UnaryExpr {
        public:
            CastExpr* _Operand;
            LogicalNot(CastExpr* Operand) : _Operand(Operand) {}
            ~LogicalNot(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class PostfixExpr : public UnaryExpr {
    public:
        PostfixExpr() {}
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual llvm::Value* IRGenPtr(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class Subscript : public PostfixExpr {
        public:
            ast::PostfixExpr* _Array;
            ast::ArrayDimensions* _Index;
            Subscript(ast::PostfixExpr* Array, ast::ArrayDimensions* Index) : _Array(Array), _Index(Index) {}
            ~Subscript(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        }; 
        class FuncCall : public PostfixExpr {
        public:
            std::string _Function;
            ArgumentExprList* _ArgExprList;
            FuncCall(const std::string& Function, ArgumentExprList* ArgExprList) : _Function(Function), _ArgExprList(ArgExprList) {}
            ~FuncCall(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        // .mem
        class StructReference : public PostfixExpr {
        public:
            PostfixExpr* _Struct;
            std::string _MemName;
            StructReference(PostfixExpr* Struct, const std::string& MemName) : _Struct(Struct), _MemName(MemName) {}
            ~StructReference(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        // ->mem
        class StructDereference : public PostfixExpr {
        public:
            PostfixExpr* _StructPtr;
            std::string _MemName;
            StructDereference(PostfixExpr* StructPtr, const std::string& MemName) : _StructPtr(StructPtr), _MemName(MemName) {}
            ~StructDereference(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        // a++
        class PostfixInc : public PostfixExpr {
        public:
            PostfixExpr* _Operand;
            PostfixInc(PostfixExpr* Operand) : _Operand(Operand) {}
            ~PostfixInc(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        // a--
        class PostfixDec : public PostfixExpr {
        public:
            PostfixExpr* _Operand;
            PostfixDec(PostfixExpr* Operand) : _Operand(Operand) {}
            ~PostfixDec(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    class PrimaryExpr : public PostfixExpr {
    public:
        Expr* _expr;
        PrimaryExpr() {}
        PrimaryExpr(Expr* expr) : _expr(expr) {}
        llvm::Value* IRGen(SemanticCtx& __Ctx) {
            return _expr->IRGen(__Ctx);
        }
		llvm::Value* IRGenPtr(SemanticCtx& __Ctx) {
            return _expr->IRGenPtr(__Ctx);
        }
		std::string astJson();
    };
        class Variable : public PrimaryExpr {
        public:
            std::string _Name;
            
            Variable(const std::string& Name) : _Name(Name) {}
            ~Variable(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class Constant : public PrimaryExpr {
        public:
            BuiltInType::TypeID _Type;
            bool _Bool;
            char _Character;
            int _Integer;
            double _Real;
            Constant(bool Bool) :
                _Type(BuiltInType::TypeID::BOOL), _Bool(Bool), _Character('\0'), _Integer(0), _Real(0.0) {}
            Constant(char Character) :
                _Type(BuiltInType::TypeID::CHAR), _Bool(false), _Character(Character), _Integer(0), _Real(0.0) {}
            Constant(int Integer) :
                _Type(BuiltInType::TypeID::INT), _Bool(false), _Character('\0'), _Integer(Integer), _Real(0.0) {}
            Constant(double Real) :
                _Type(BuiltInType::TypeID::DOUBLE), _Bool(false), _Character('\0'), _Integer(0), _Real(Real) {}
            ~Constant(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class StringLiteral : public PrimaryExpr {
        public:
            std::string _Content;
            StringLiteral(const std::string& Content) : _Content(Content) {}
            ~StringLiteral(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            llvm::Value* IRGenPtr(SemanticCtx& __Ctx);
            std::string astJson();
        };

    /**
     * @brief Statement
     */
    class Stmt : public BlockItem {
    public:
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };

    // Block
    class CompoundStmt : public Stmt { 
    public:
        BlockItemList* _BlockItems; // May be NULL

        CompoundStmt(BlockItemList* BlockItems) : _BlockItems(BlockItems) {}
        ~CompoundStmt(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    class ExprStmt : public Stmt {
    public:
        /**
         * @brief Expr; or ;
         */
		Expr* _Expression;
		ExprStmt(Expr* Expression = NULL) : _Expression(Expression) {}
		~ExprStmt(void) {}
		llvm::Value* IRGen(SemanticCtx& __Ctx);
		std::string astJson();
    };

    // SelectionStmt
    class SelectionStmt : public Stmt {
    public:
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class IfStmt : public SelectionStmt {
        public:
            // Branch condition, then-clause and else-clause(may be NULL)
            Expr* _Condition;
            Stmt* _Then;
            Stmt* _Else;
            IfStmt(Expr* Condition, Stmt* Then, Stmt* Else = NULL) : _Condition(Condition), _Then(Then), _Else(Else) {}
            ~IfStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class SwitchStmt : public SelectionStmt {
        public:
            // Switch-matcher and case statements
            Expr* _Matcher;
            CaseStmts* _CaseList;
            DefaultStmt* _Default; // may be NULL
            SwitchStmt(Expr* Matcher, CaseStmts* CaseList, DefaultStmt* Default = NULL) : _Matcher(Matcher), _CaseList(CaseList), _Default(Default) {}
            ~SwitchStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
            class CaseStmt : public SelectionStmt {
            public:
                ConditionalExpr* _Condition;
                Stmts* _CaseBody;
                CaseStmt(ConditionalExpr* Condition, Stmts* CaseBody) : _Condition(Condition), _CaseBody(CaseBody) {}
                ~CaseStmt(void) {}
                llvm::Value* IRGen(SemanticCtx& __Ctx);
                std::string astJson();
            };
            class DefaultStmt : public SelectionStmt {
            public:
                Stmts* _DefaultBody;
                DefaultStmt(Stmts* DefaultBody) : _DefaultBody(DefaultBody) {}
                ~DefaultStmt(void) {}
                llvm::Value* IRGen(SemanticCtx& __Ctx);
                std::string astJson();
            };
        
    // IterationStmt
    class IterationStmt : public Stmt {
    public:
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class WhileStmt : public IterationStmt {
        public:
            // Loop condition and loop body
            Expr* _Condition;
            Stmt* _LoopBody;
            WhileStmt(Expr* Condition, Stmt* LoopBody) : _Condition(Condition), _LoopBody(LoopBody) {}
            ~WhileStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class DoWhileStmt : public IterationStmt {
        public:
            // Loop condition and loop body
            Expr* _Condition;
            Stmt* _LoopBody;
            DoWhileStmt(Expr* Condition, Stmt* LoopBody) : _Condition(Condition), _LoopBody(LoopBody) {}
            ~DoWhileStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class ForStmt : public IterationStmt { 
        public:
            Expr* _Initial; // May be NULL
            VarDecl* _VarDecl; // May be NULL
            Expr* _Condition; // May be NULL
            Expr* _Tail; // May be NULL
            Stmt* _LoopBody;
            // for (i = 0; i < 10; i++) {}
            ForStmt(Expr* Initial, Expr* Condition, Expr* Tail, Stmt* LoopBody) :
                _Initial(Initial), _VarDecl(NULL), _Condition(Condition), _Tail(Tail), _LoopBody(LoopBody) {}
            // for (int i = 0; i < 10; i++) {}
            ForStmt(VarDecl* VarDecl, Expr* Condition, Expr* Tail, Stmt* LoopBody) :
                _Initial(NULL), _VarDecl(VarDecl), _Condition(Condition), _Tail(Tail), _LoopBody(LoopBody) {}
            ~ForStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };

    // JumpStmt
    class JumpStmt : public Stmt {
    public:
        virtual llvm::Value* IRGen(SemanticCtx& __Ctx) = 0;
		virtual std::string astJson() = 0;
    };
        class ContinueStmt : public JumpStmt {
        public:
            ContinueStmt(void) {}
            ~ContinueStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class BreakStmt : public JumpStmt {
        public:
            BreakStmt(void) {}
            ~BreakStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
        class ReturnStmt : public JumpStmt {
        public:
            Expr* _RetVal;
            ReturnStmt(Expr* RetVal = NULL) : _RetVal(RetVal) {}
            ~ReturnStmt(void) {}
            llvm::Value* IRGen(SemanticCtx& __Ctx);
            std::string astJson();
        };
}