#pragma once
#include <vector>
#include <map>
#include <string>

class ArgParser{
private:
	std::vector<std::string> args;
	std::map<std::string, std::string> argMap; // (c, srcfile), (o, objectfile) ...

	void argParse() {
		for (int i = 0; i < args.size(); i++) {
			if (args[i][0] == '-') {
				std::string name(&args[i][1]);
				if (i + 1 < args.size() && args[i + 1][0] != '-') {
					argMap[name] = args[i + 1];
					i++;
				} else {
					argMap[name] = "";
				}
			}
		}
	}

public:
	ArgParser() {}
	ArgParser(int argnum, const char** args){
		for (int i = 0; i < argnum; i++)
			this->args.push_back(args[i]);
		argParse();
	}

	bool getArg(std::string option, std::string& arg) const{
		auto it = argMap.find(option);
		if (it == argMap.end())
			return false;

		arg = it->second;
		return true;
	}
};