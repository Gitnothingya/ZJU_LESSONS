#ifndef _stack_h
#define _stack_h

#include<stdio.h>
#include<stdlib.h>

typedef struct node{
	void *data;
	struct node *next;
}node;
typedef struct stack{
	node *top;
	node *bottom;
}stack;

stack *NewStack();


int IsemptyStack(stack *s);


void FreeStack(stack *s);


void PushStack(stack *s,void *obj);

void *PopStack(stack *s);


void *TopStack(stack *s);

#endif
