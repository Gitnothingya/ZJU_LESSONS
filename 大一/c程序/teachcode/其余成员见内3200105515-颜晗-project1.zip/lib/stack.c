#include<stdio.h>
#include "stack.h"


stack *NewStack()
{
	stack *s = (stack*)malloc(sizeof(stack));
//	s->top = (node*)malloc(sizeof(node));ɾ�� 
	s->bottom = (node*)malloc(sizeof(node));
	s->top = s->bottom;
	s->bottom->next = NULL;
	return s;
}

int IsemptyStack(stack *s)
{
	if(s->top==s->bottom)return 0;
	else return 1;
}

void FreeStack(stack *s)
{
	while(s->top!=s->bottom)
	{
		node *t = s->top;
		s->top = s->top->next;
		free(t);
	}
	free(s);
}

void PushStack(stack *s,void *obj)
{
    node *n = (node*)malloc(sizeof(node));
	n->data = obj;
	n->next = s->top;
	s->top = n;
	return ;
}

void *PopStack(stack *s)
{
	if(!IsemptyStack(s))return NULL;
	void *t = s->top->data;
	node *p = s->top;
	s->top = s->top->next;
	free(p);
	return t;
}

void *TopStack(stack *s)
{
	return s->top->data;
}
